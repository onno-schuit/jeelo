NOTICE:
/sso/ will be moved to /auth/ and deprecated; use user_authenticated_hook() instead
