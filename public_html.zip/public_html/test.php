/bin/bash: tidy: command not found
