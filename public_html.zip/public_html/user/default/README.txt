These images are not currently used in Moodle any more.

See /pix/u/f*.png or the pix directory within your theme.

However, they are retained in the distribution so that old
mailed-out posts that may refer to these images still work.

Eventually these will be deleted, so don't use them please.

Cheers,
Martin   28/7/2003
