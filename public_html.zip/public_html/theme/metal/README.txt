MOODLE THEME: METAL

This theme is designed by A. Chavan (chavan at users.sourceforge.net).

It is based on moodle's "standardwhite" theme. 
It uses the background image from, and is inspired by:
http://www.alexking.org/software/wordpress/styles/sample.php?wpstyle=metaldreams

It has been tested with Mozilla. The header appears slightly different
on Safari (MacOSX) and MSIE6(WindowsXP).

UPDATED for Moodle 1.5 by Martin Dougiamas

$Lastupdate: Wed May 19 13:05:59 2004 chavan$
