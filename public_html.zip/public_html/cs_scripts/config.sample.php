<?php

# set these to your own needs
$cs_dbhost = 'localhost';
$cs_dbuser = '';
$cs_dbpass = '';
$cs_dbname = '';

