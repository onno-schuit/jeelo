<?php 
   include('../config.php');
   redirect('http://en.wikipedia.org/wiki/Women%27s_liberation');
?>
