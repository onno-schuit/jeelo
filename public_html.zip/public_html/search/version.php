<?php // $Id: version.php,v 1.1.2.2 2009/07/22 21:52:08 diml Exp $

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the search version etc.
//  This fragment is called by /admin/index.php
//  
//  Consider it is not handled by Moodle core upgrade code. 
//  Just for identification
////////////////////////////////////////////////////////////////////////////////

$search->version  = 2009031000;
$search->requires = 2007101509;  // Requires this Moodle version

?>