-- phpMyAdmin SQL Dump
-- version 3.3.7deb5build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 22, 2012 at 01:48 PM
-- Server version: 5.1.61
-- PHP Version: 5.3.3-1ubuntu9.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jeelo_buffer`
--

-- --------------------------------------------------------

--
-- Table structure for table `client_categories`
--

CREATE TABLE IF NOT EXISTS `client_categories` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `parent` bigint(10) unsigned NOT NULL DEFAULT '0',
  `sortorder` bigint(10) unsigned NOT NULL DEFAULT '0',
  `coursecount` bigint(10) unsigned NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `depth` bigint(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `theme` varchar(50) DEFAULT NULL,
  `client_moodle_id` bigint(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_courcate_par_ix` (`parent`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Course categories' AUTO_INCREMENT=19 ;

--
-- Dumping data for table `client_categories`
--

INSERT INTO `client_categories` (`id`, `name`, `description`, `parent`, `sortorder`, `coursecount`, `visible`, `timemodified`, `depth`, `path`, `theme`, `client_moodle_id`) VALUES
(17, 'Project 1 - Omgaan met elkaar', 'Project 1 - Test project<br />', 0, 999, 4, 1, 1332253576, 1, '/2', NULL, 67),
(18, 'Project 1 - Omgaan met elkaar', ' Project 1 - Test project<br />', 0, 999, 4, 1, 1332418753, 1, '/2', '', 68);

-- --------------------------------------------------------

--
-- Table structure for table `client_courses`
--

CREATE TABLE IF NOT EXISTS `client_courses` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `course_fullname` varchar(255) NOT NULL,
  `course_shortname` varchar(255) NOT NULL,
  `course_groupyear` varchar(255) NOT NULL,
  `client_moodle_id` int(255) NOT NULL,
  `parent_category_id` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=89 ;

--
-- Dumping data for table `client_courses`
--

INSERT INTO `client_courses` (`id`, `backup_name`, `course_fullname`, `course_shortname`, `course_groupyear`, `client_moodle_id`, `parent_category_id`) VALUES
(83, 'backup-cf104-20120320-1526.zip', 'Jaar 5/6 - Vrienden in een groep', 'CF104', '5/6', 67, 17),
(84, 'backup-cf105-20120320-1526.zip', 'Jaar 7/8 - Waarderen van verschillen', 'CF105', '7/8', 67, 17),
(82, 'backup-cf103-20120320-1526.zip', 'Jaar 3/4 - Leven in een gezin', 'CF103', '3/4', 67, 17),
(81, 'backup-cf101-20120320-1526.zip', 'Jaar 1/2 - Samen spelen', 'CF101', '1/2', 67, 17),
(85, 'backup-cf101-20120322-1319.zip', 'Jaar 1/2 - Samen spelen', 'CF101', '1/2', 68, 18),
(86, 'backup-cf103-20120322-1319.zip', 'Jaar 3/4 - Leven in een gezin', 'CF103', '3/4', 68, 18),
(87, 'backup-cf104-20120322-1319.zip', 'Jaar 5/6 - Vrienden in een groep', 'CF104', '5/6', 68, 18),
(88, 'backup-cf105-20120322-1319.zip', 'Jaar 7/8 - Waarderen van verschillen', 'CF105', '7/8', 68, 18);

-- --------------------------------------------------------

--
-- Table structure for table `client_moodles`
--

CREATE TABLE IF NOT EXISTS `client_moodles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timecreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `domain` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `short_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `sql_filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `codebase_filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `csv_filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `courses_filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_for_client` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `exit_code` int(11) NOT NULL,
  `timemodified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `is_for_client` (`is_for_client`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=69 ;

--
-- Dumping data for table `client_moodles`
--

INSERT INTO `client_moodles` (`id`, `timecreated`, `domain`, `short_code`, `name`, `description`, `sql_filename`, `codebase_filename`, `csv_filename`, `courses_filename`, `is_for_client`, `status`, `exit_code`, `timemodified`) VALUES
(68, '2012-03-22 13:27:50', 'jeelotarget1.jeelo.nl', 'jeelotarget1', 'jeelotarget1', '', '/etc/moodle_clients/db/jeelotarget1.jeelo.nl_sql_20120322.gz', '/etc/moodle_clients/code/jeelotarget1.jeelo.nl_codebase_20120322.tgz', '/etc/moodle_clients/csv/jeelotarget1.jeelo.nl_csv_20120322.tgz', '/etc/moodle_clients/course_imports/jeelotarget1.jeelo.nl_course_imports_20120322.tgz', 'client', 'update', 0, '0000-00-00 00:00:00'),
(67, '2012-03-22 13:11:49', 'jeelotarget2.jeelo.nl', 'jeelotarget2', 'jeelotarget2', '', '/etc/moodle_clients/db/jeelotarget2.jeelo.nl_sql_20120319.gz', '/etc/moodle_clients/code/jeelotarget2.jeelo.nl_codebase_20120319.tgz', '/etc/moodle_clients/csv/jeelotarget2.jeelo.nl_csv_20120320.tgz', '/etc/moodle_clients/course_imports/jeelotarget2.jeelo.nl_course_imports_20120320.tgz', 'client', 'processed', 0, '0000-00-00 00:00:00');
