-- phpMyAdmin SQL Dump
-- version 3.3.7deb5build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 22, 2012 at 06:52 PM
-- Server version: 5.1.61
-- PHP Version: 5.3.3-1ubuntu9.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jeelo19`
--

-- --------------------------------------------------------

--
-- Table structure for table `adodb_logsql`
--

CREATE TABLE IF NOT EXISTS `adodb_logsql` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `sql0` varchar(250) NOT NULL DEFAULT '',
  `sql1` text,
  `params` text,
  `tracer` text,
  `timer` decimal(16,6) NOT NULL DEFAULT '0.000000',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to save some logs from ADOdb' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `adodb_logsql`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_assignment`
--

CREATE TABLE IF NOT EXISTS `mdl_assignment` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `format` smallint(4) unsigned NOT NULL DEFAULT '0',
  `assignmenttype` varchar(50) NOT NULL DEFAULT '',
  `resubmit` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `preventlate` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `emailteachers` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `var1` bigint(10) DEFAULT '0',
  `var2` bigint(10) DEFAULT '0',
  `var3` bigint(10) DEFAULT '0',
  `var4` bigint(10) DEFAULT '0',
  `var5` bigint(10) DEFAULT '0',
  `maxbytes` bigint(10) unsigned NOT NULL DEFAULT '100000',
  `timedue` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeavailable` bigint(10) unsigned NOT NULL DEFAULT '0',
  `grade` bigint(10) NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_assi_cou_ix` (`course`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Defines assignments' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mdl_assignment`
--

INSERT INTO `mdl_assignment` (`id`, `course`, `name`, `description`, `format`, `assignmenttype`, `resubmit`, `preventlate`, `emailteachers`, `var1`, `var2`, `var3`, `var4`, `var5`, `maxbytes`, `timedue`, `timeavailable`, `grade`, `timemodified`) VALUES
(1, 6, 'Test activity', ' Test description ', 0, 'offline', 0, 1, 0, 0, 0, 0, 0, 0, 100000, 0, 0, 100, 1331205183);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_assignment_submissions`
--

CREATE TABLE IF NOT EXISTS `mdl_assignment_submissions` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `assignment` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `numfiles` bigint(10) unsigned NOT NULL DEFAULT '0',
  `data1` text,
  `data2` text,
  `grade` bigint(11) NOT NULL DEFAULT '0',
  `submissioncomment` text NOT NULL,
  `format` smallint(4) unsigned NOT NULL DEFAULT '0',
  `teacher` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemarked` bigint(10) unsigned NOT NULL DEFAULT '0',
  `mailed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_assisubm_use_ix` (`userid`),
  KEY `mdl_assisubm_mai_ix` (`mailed`),
  KEY `mdl_assisubm_tim_ix` (`timemarked`),
  KEY `mdl_assisubm_ass_ix` (`assignment`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about submitted assignments' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_assignment_submissions`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_backup_config`
--

CREATE TABLE IF NOT EXISTS `mdl_backup_config` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_backconf_nam_uix` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='To store backup configuration variables' AUTO_INCREMENT=18 ;

--
-- Dumping data for table `mdl_backup_config`
--

INSERT INTO `mdl_backup_config` (`id`, `name`, `value`) VALUES
(1, 'backup_sche_modules', '1'),
(2, 'backup_sche_withuserdata', '0'),
(3, 'backup_sche_metacourse', '0'),
(4, 'backup_sche_users', '0'),
(5, 'backup_sche_logs', '0'),
(6, 'backup_sche_userfiles', '0'),
(7, 'backup_sche_coursefiles', '1'),
(8, 'backup_sche_sitefiles', '1'),
(9, 'backup_sche_gradebook_history', '0'),
(10, 'backup_sche_messages', '0'),
(11, 'backup_sche_blogs', '0'),
(12, 'backup_sche_keep', '1'),
(13, 'backup_sche_active', '0'),
(14, 'backup_sche_weekdays', '0000000'),
(15, 'backup_sche_hour', '0'),
(16, 'backup_sche_minute', '0'),
(17, 'backup_sche_destination', '');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_backup_courses`
--

CREATE TABLE IF NOT EXISTS `mdl_backup_courses` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `laststarttime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lastendtime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `laststatus` varchar(1) NOT NULL DEFAULT '0',
  `nextstarttime` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_backcour_cou_uix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To store every course backup status' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_backup_courses`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_backup_files`
--

CREATE TABLE IF NOT EXISTS `mdl_backup_files` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `backup_code` bigint(10) unsigned NOT NULL DEFAULT '0',
  `file_type` varchar(10) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `old_id` bigint(10) unsigned NOT NULL DEFAULT '0',
  `new_id` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_backfile_bacfilpat_uix` (`backup_code`,`file_type`,`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To store and recode ids to user and course files' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_backup_files`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_backup_ids`
--

CREATE TABLE IF NOT EXISTS `mdl_backup_ids` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `backup_code` bigint(12) unsigned NOT NULL DEFAULT '0',
  `table_name` varchar(30) NOT NULL DEFAULT '',
  `old_id` bigint(10) unsigned NOT NULL DEFAULT '0',
  `new_id` bigint(10) unsigned NOT NULL DEFAULT '0',
  `info` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_backids_bactabold_uix` (`backup_code`,`table_name`,`old_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='To store and convert ids in backup/restore' AUTO_INCREMENT=2223 ;

--
-- Dumping data for table `mdl_backup_ids`
--

INSERT INTO `mdl_backup_ids` (`id`, `backup_code`, `table_name`, `old_id`, `new_id`, `info`) VALUES
(112, 1328632453, 'user', 2, 0, ''),
(8, 1328624122, 'user', 2, 0, ''),
(7, 1328624122, 'user', 1, 0, ''),
(9, 1328624611, 'user', 1, 0, ''),
(10, 1328624611, 'user', 2, 0, ''),
(11, 1328624638, 'user', 1, 0, ''),
(12, 1328624638, 'user', 2, 0, ''),
(16, 1328625976, 'user', 2, 0, ''),
(15, 1328625976, 'user', 1, 0, ''),
(17, 1328626035, 'user', 1, 0, ''),
(18, 1328626035, 'user', 2, 0, ''),
(100, 1328631162, 'user', 2, 0, ''),
(99, 1328631162, 'user', 1, 0, ''),
(111, 1328632453, 'user', 1, 0, ''),
(113, 1328632523, 'user', 1, 0, ''),
(114, 1328632523, 'user', 2, 0, ''),
(2175, 1332433774, 'user', 1, 0, ''),
(2173, 1332433705, 'user', 1, 0, ''),
(2174, 1332433705, 'user', 2, 0, ''),
(1606, 1331128624, 'user', 2, 0, ''),
(1605, 1331128624, 'user', 1, 0, ''),
(1604, 1331128617, 'user', 2, 0, ''),
(1603, 1331128617, 'user', 1, 0, ''),
(1602, 1331128595, 'user', 2, 0, ''),
(1601, 1331128595, 'user', 1, 0, ''),
(1600, 1331128491, 'user', 2, 0, ''),
(1599, 1331128491, 'user', 1, 0, ''),
(1598, 1331128371, 'user', 2, 0, ''),
(1597, 1331128371, 'user', 1, 0, ''),
(1596, 1331128302, 'user', 2, 0, ''),
(1595, 1331128302, 'user', 1, 0, ''),
(1281, 1329318936, 'user', 1, 0, ''),
(1282, 1329318936, 'user', 2, 0, ''),
(1278, 1329317972, 'user', 2, 0, ''),
(1277, 1329317972, 'user', 1, 0, ''),
(235, 1328793002, 'user', 1, 0, ''),
(236, 1328793002, 'user', 2, 0, ''),
(1276, 1329317774, 'user', 2, 0, ''),
(1275, 1329317774, 'user', 1, 0, ''),
(1258, 1329316738, 'user', 2, 0, ''),
(1257, 1329316738, 'user', 1, 0, ''),
(1176, 1329221018, 'user', 2, 0, ''),
(1175, 1329221018, 'user', 1, 0, ''),
(950, 1328800721, 'user', 2, 0, ''),
(949, 1328800721, 'user', 1, 0, ''),
(948, 1328800640, 'user', 2, 0, ''),
(947, 1328800640, 'user', 1, 0, ''),
(913, 1328799829, 'user', 1, 0, ''),
(914, 1328799829, 'user', 2, 0, ''),
(196, 1328786116, 'user', 2, 0, ''),
(195, 1328786116, 'user', 1, 0, ''),
(2176, 1332433774, 'user', 2, 0, ''),
(2177, 1332433790, 'user', 1, 0, ''),
(2178, 1332433790, 'user', 2, 0, ''),
(2179, 1332434109, 'user', 1, 0, ''),
(2180, 1332434109, 'user', 2, 0, ''),
(2181, 1332434140, 'user', 1, 0, ''),
(2182, 1332434140, 'user', 2, 0, ''),
(2183, 1332434176, 'user', 1, 0, ''),
(2184, 1332434176, 'user', 2, 0, ''),
(2185, 1332434233, 'user', 1, 0, ''),
(2186, 1332434233, 'user', 2, 0, ''),
(2187, 1332434261, 'user', 1, 0, ''),
(2188, 1332434261, 'user', 2, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_backup_log`
--

CREATE TABLE IF NOT EXISTS `mdl_backup_log` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `time` bigint(10) unsigned NOT NULL DEFAULT '0',
  `laststarttime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `info` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_backlog_cou_ix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To store every course backup log info' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_backup_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_block`
--

CREATE TABLE IF NOT EXISTS `mdl_block` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `version` bigint(10) unsigned NOT NULL DEFAULT '0',
  `cron` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lastcron` bigint(10) unsigned NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `multiple` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='to store installed blocks' AUTO_INCREMENT=32 ;

--
-- Dumping data for table `mdl_block`
--

INSERT INTO `mdl_block` (`id`, `name`, `version`, `cron`, `lastcron`, `visible`, `multiple`) VALUES
(1, 'activity_modules', 2007101509, 0, 0, 1, 0),
(2, 'admin', 2007101509, 0, 0, 1, 0),
(3, 'admin_bookmarks', 2007101509, 0, 0, 1, 0),
(4, 'admin_tree', 2007101509, 0, 0, 1, 0),
(5, 'blog_menu', 2007101509, 0, 0, 1, 0),
(6, 'blog_tags', 2007101509, 0, 0, 1, 1),
(7, 'calendar_month', 2007101509, 0, 0, 1, 0),
(8, 'calendar_upcoming', 2007101509, 0, 0, 1, 0),
(9, 'course_list', 2007101509, 0, 0, 1, 0),
(10, 'course_summary', 2007101509, 0, 0, 1, 0),
(11, 'glossary_random', 2007101509, 0, 0, 1, 1),
(12, 'html', 2007101509, 0, 0, 1, 1),
(13, 'loancalc', 2007101509, 0, 0, 1, 0),
(14, 'login', 2007101509, 0, 0, 1, 0),
(15, 'mentees', 2007101509, 0, 0, 1, 1),
(16, 'messages', 2007101509, 0, 0, 1, 0),
(17, 'mnet_hosts', 2007101509, 0, 0, 1, 0),
(18, 'news_items', 2007101509, 0, 0, 1, 0),
(19, 'online_users', 2007101510, 0, 0, 1, 0),
(20, 'participants', 2007101509, 0, 0, 1, 0),
(21, 'quiz_results', 2007101509, 0, 0, 1, 1),
(22, 'recent_activity', 2007101509, 0, 0, 1, 0),
(23, 'rss_client', 2007101511, 300, 0, 1, 1),
(24, 'search', 2008031500, 1, 0, 1, 0),
(25, 'search_forums', 2007101509, 0, 0, 1, 0),
(26, 'section_links', 2007101511, 0, 0, 1, 0),
(27, 'site_main_menu', 2007101509, 0, 0, 1, 0),
(28, 'social_activities', 2007101509, 0, 0, 1, 0),
(29, 'tag_flickr', 2007101509, 0, 0, 1, 1),
(30, 'tag_youtube', 2007101509, 0, 0, 1, 1),
(31, 'tags', 2007101509, 0, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_block_instance`
--

CREATE TABLE IF NOT EXISTS `mdl_block_instance` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `blockid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `pageid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `pagetype` varchar(20) NOT NULL DEFAULT '',
  `position` varchar(10) NOT NULL DEFAULT '',
  `weight` smallint(3) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `configdata` text,
  PRIMARY KEY (`id`),
  KEY `mdl_blocinst_pag_ix` (`pageid`),
  KEY `mdl_blocinst_pag2_ix` (`pagetype`),
  KEY `mdl_blocinst_blo_ix` (`blockid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='to store block instances in pages' AUTO_INCREMENT=95 ;

--
-- Dumping data for table `mdl_block_instance`
--

INSERT INTO `mdl_block_instance` (`id`, `blockid`, `pageid`, `pagetype`, `position`, `weight`, `visible`, `configdata`) VALUES
(1, 27, 1, 'course-view', 'l', 0, 1, ''),
(2, 4, 1, 'course-view', 'l', 1, 1, ''),
(3, 10, 1, 'course-view', 'r', 0, 1, ''),
(4, 7, 1, 'course-view', 'r', 1, 1, ''),
(5, 4, 0, 'admin', 'l', 0, 1, ''),
(6, 3, 0, 'admin', 'l', 1, 1, ''),
(7, 20, 2, 'course-view', 'l', 0, 1, ''),
(8, 1, 2, 'course-view', 'l', 1, 1, ''),
(9, 25, 2, 'course-view', 'l', 2, 1, ''),
(10, 2, 2, 'course-view', 'l', 3, 1, ''),
(11, 9, 2, 'course-view', 'l', 4, 1, ''),
(12, 18, 2, 'course-view', 'r', 0, 1, ''),
(13, 8, 2, 'course-view', 'r', 1, 1, ''),
(14, 22, 2, 'course-view', 'r', 2, 1, ''),
(15, 20, 3, 'course-view', 'l', 0, 1, ''),
(16, 1, 3, 'course-view', 'l', 1, 1, ''),
(17, 25, 3, 'course-view', 'l', 2, 1, ''),
(18, 2, 3, 'course-view', 'l', 3, 1, ''),
(19, 9, 3, 'course-view', 'l', 4, 1, ''),
(20, 18, 3, 'course-view', 'r', 0, 1, ''),
(21, 8, 3, 'course-view', 'r', 1, 1, ''),
(22, 22, 3, 'course-view', 'r', 2, 1, ''),
(23, 20, 4, 'course-view', 'l', 0, 1, ''),
(24, 1, 4, 'course-view', 'l', 1, 1, ''),
(25, 25, 4, 'course-view', 'l', 2, 1, ''),
(26, 2, 4, 'course-view', 'l', 3, 1, ''),
(27, 9, 4, 'course-view', 'l', 4, 1, ''),
(28, 18, 4, 'course-view', 'r', 0, 1, ''),
(29, 8, 4, 'course-view', 'r', 1, 1, ''),
(30, 22, 4, 'course-view', 'r', 2, 1, ''),
(31, 20, 5, 'course-view', 'l', 0, 1, ''),
(32, 1, 5, 'course-view', 'l', 1, 1, ''),
(33, 25, 5, 'course-view', 'l', 2, 1, ''),
(34, 2, 5, 'course-view', 'l', 3, 1, ''),
(35, 9, 5, 'course-view', 'l', 4, 1, ''),
(36, 18, 5, 'course-view', 'r', 0, 1, ''),
(37, 8, 5, 'course-view', 'r', 1, 1, ''),
(38, 22, 5, 'course-view', 'r', 2, 1, ''),
(39, 20, 6, 'course-view', 'l', 0, 1, ''),
(40, 1, 6, 'course-view', 'l', 1, 1, ''),
(41, 25, 6, 'course-view', 'l', 2, 1, ''),
(42, 2, 6, 'course-view', 'l', 3, 1, ''),
(43, 9, 6, 'course-view', 'l', 4, 1, ''),
(44, 18, 6, 'course-view', 'r', 0, 1, ''),
(45, 8, 6, 'course-view', 'r', 1, 1, ''),
(46, 22, 6, 'course-view', 'r', 2, 1, ''),
(47, 20, 7, 'course-view', 'l', 0, 1, ''),
(48, 1, 7, 'course-view', 'l', 1, 1, ''),
(49, 25, 7, 'course-view', 'l', 2, 1, ''),
(50, 2, 7, 'course-view', 'l', 3, 1, ''),
(51, 9, 7, 'course-view', 'l', 4, 1, ''),
(52, 18, 7, 'course-view', 'r', 0, 1, ''),
(53, 8, 7, 'course-view', 'r', 1, 1, ''),
(54, 22, 7, 'course-view', 'r', 2, 1, ''),
(55, 20, 8, 'course-view', 'l', 0, 1, ''),
(56, 1, 8, 'course-view', 'l', 1, 1, ''),
(57, 25, 8, 'course-view', 'l', 2, 1, ''),
(58, 2, 8, 'course-view', 'l', 3, 1, ''),
(59, 9, 8, 'course-view', 'l', 4, 1, ''),
(60, 18, 8, 'course-view', 'r', 0, 1, ''),
(61, 8, 8, 'course-view', 'r', 1, 1, ''),
(62, 22, 8, 'course-view', 'r', 2, 1, ''),
(63, 20, 9, 'course-view', 'l', 0, 1, ''),
(64, 1, 9, 'course-view', 'l', 1, 1, ''),
(65, 25, 9, 'course-view', 'l', 2, 1, ''),
(66, 2, 9, 'course-view', 'l', 3, 1, ''),
(67, 9, 9, 'course-view', 'l', 4, 1, ''),
(68, 18, 9, 'course-view', 'r', 0, 1, ''),
(69, 8, 9, 'course-view', 'r', 1, 1, ''),
(70, 22, 9, 'course-view', 'r', 2, 1, ''),
(71, 20, 10, 'course-view', 'l', 0, 1, ''),
(72, 1, 10, 'course-view', 'l', 1, 1, ''),
(73, 25, 10, 'course-view', 'l', 2, 1, ''),
(74, 2, 10, 'course-view', 'l', 3, 1, ''),
(75, 9, 10, 'course-view', 'l', 4, 1, ''),
(76, 18, 10, 'course-view', 'r', 0, 1, ''),
(77, 8, 10, 'course-view', 'r', 1, 1, ''),
(78, 22, 10, 'course-view', 'r', 2, 1, ''),
(79, 20, 11, 'course-view', 'l', 0, 1, 'Tjs='),
(80, 1, 11, 'course-view', 'l', 1, 1, 'Tjs='),
(81, 25, 11, 'course-view', 'l', 2, 1, 'Tjs='),
(82, 2, 11, 'course-view', 'l', 3, 1, 'Tjs='),
(83, 9, 11, 'course-view', 'l', 4, 1, 'Tjs='),
(84, 18, 11, 'course-view', 'r', 0, 1, 'Tjs='),
(85, 8, 11, 'course-view', 'r', 1, 1, 'Tjs='),
(86, 22, 11, 'course-view', 'r', 2, 1, 'Tjs='),
(87, 20, 12, 'course-view', 'l', 0, 1, 'Tjs='),
(88, 1, 12, 'course-view', 'l', 1, 1, 'Tjs='),
(89, 25, 12, 'course-view', 'l', 2, 1, 'Tjs='),
(90, 2, 12, 'course-view', 'l', 3, 1, 'Tjs='),
(91, 9, 12, 'course-view', 'l', 4, 1, 'Tjs='),
(92, 18, 12, 'course-view', 'r', 0, 1, 'Tjs='),
(93, 8, 12, 'course-view', 'r', 1, 1, 'Tjs='),
(94, 22, 12, 'course-view', 'r', 2, 1, 'Tjs=');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_block_pinned`
--

CREATE TABLE IF NOT EXISTS `mdl_block_pinned` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `blockid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `pagetype` varchar(20) NOT NULL DEFAULT '',
  `position` varchar(10) NOT NULL DEFAULT '',
  `weight` smallint(3) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `configdata` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_blocpinn_pag_ix` (`pagetype`),
  KEY `mdl_blocpinn_blo_ix` (`blockid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to pin blocks' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_block_pinned`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_block_rss_client`
--

CREATE TABLE IF NOT EXISTS `mdl_block_rss_client` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `title` text NOT NULL,
  `preferredtitle` varchar(64) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `shared` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Remote news feed information. Contains the news feed id, the' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_block_rss_client`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_block_search_documents`
--

CREATE TABLE IF NOT EXISTS `mdl_block_search_documents` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `docid` varchar(32) NOT NULL DEFAULT '',
  `doctype` varchar(32) NOT NULL DEFAULT 'none',
  `itemtype` varchar(32) NOT NULL DEFAULT 'standard',
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `docdate` bigint(10) unsigned NOT NULL DEFAULT '0',
  `updated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `groupid` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_blocseardocu_doc_ix` (`docid`),
  KEY `mdl_blocseardocu_doc2_ix` (`doctype`),
  KEY `mdl_blocseardocu_ite_ix` (`itemtype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='table to store search index backups' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_block_search_documents`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_cache_filters`
--

CREATE TABLE IF NOT EXISTS `mdl_cache_filters` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `filter` varchar(32) NOT NULL DEFAULT '',
  `version` bigint(10) unsigned NOT NULL DEFAULT '0',
  `md5key` varchar(32) NOT NULL DEFAULT '',
  `rawtext` text NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_cachfilt_filmd5_ix` (`filter`,`md5key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='For keeping information about cached data' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_cache_filters`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_cache_flags`
--

CREATE TABLE IF NOT EXISTS `mdl_cache_flags` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `flagtype` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `value` mediumtext NOT NULL,
  `expiry` bigint(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_cachflag_fla_ix` (`flagtype`),
  KEY `mdl_cachflag_nam_ix` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Cache of time-sensitive flags' AUTO_INCREMENT=14 ;

--
-- Dumping data for table `mdl_cache_flags`
--

INSERT INTO `mdl_cache_flags` (`id`, `flagtype`, `name`, `timemodified`, `value`, `expiry`) VALUES
(1, 'accesslib/dirtycontexts', '/1', 1329389244, '1', 1329396444),
(2, 'accesslib/dirtycontexts', '/1/3/8', 1325602774, '1', 1325609974),
(3, 'accesslib/dirtycontexts', '/1/3/20', 1324980934, '1', 1324988134),
(4, 'accesslib/dirtycontexts', '/1/31', 1325602756, '1', 1325609956),
(5, 'accesslib/dirtycontexts', '/1/31/8', 1325602774, '1', 1325609974),
(6, 'accesslib/dirtycontexts', '/1/31/32', 1325605060, '1', 1325612260),
(7, 'accesslib/dirtycontexts', '/1/31/42', 1325605111, '1', 1325612311),
(8, 'accesslib/dirtycontexts', '/1/31/43', 1325605140, '1', 1325612340),
(9, 'accesslib/dirtycontexts', '/1/44', 1325605165, '1', 1325612365),
(10, 'accesslib/dirtycontexts', '/1/44/45', 1325605204, '1', 1325612404),
(11, 'accesslib/dirtycontexts', '/1/44/55', 1325605237, '1', 1325612437),
(12, 'accesslib/dirtycontexts', '/1/44/56', 1325605257, '1', 1325612457),
(13, 'accesslib/dirtycontexts', '/1/44/57', 1325605275, '1', 1325612475);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_cache_text`
--

CREATE TABLE IF NOT EXISTS `mdl_cache_text` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `md5key` varchar(32) NOT NULL DEFAULT '',
  `formattedtext` longtext NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_cachtext_md5_ix` (`md5key`),
  KEY `mdl_cachtext_tim_ix` (`timemodified`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='For storing temporary copies of processed texts' AUTO_INCREMENT=29 ;

--
-- Dumping data for table `mdl_cache_text`
--

INSERT INTO `mdl_cache_text` (`id`, `md5key`, `formattedtext`, `timemodified`) VALUES
(1, '235f991e403028b4364b1b9e509426ca', 'Test Course 1 ', 1325602347),
(2, '1921056d595c71da7195194a13d69002', 'Test Course 2 ', 1332437840),
(3, 'cb6e6938baac75d73d0778df5088372d', ' Test Course 1 ', 1325604800),
(4, 'ef09b90af81148ceb6f3f77d703ed474', 'Jaar 1/2 - Samen spelen', 1325682137),
(5, 'c468ac7a422a1a7b7edabb8fd82f3fbf', ' Jaar 1/2 - Samen spelen', 1332437840),
(6, '3f7fd3d401c9e47b79e4d3ad9f3be149', 'Administrators can usually do anything on the site, in all courses.', 1329398882),
(7, 'cc9b927920dce1c867c881f40cb51598', 'Course creators can create new courses.', 1329398882),
(8, '7862c21bfb2325c5c0b3d490248b86f3', 'Teachers can do anything within a course, including changing the activities and grading students.', 1329398882),
(9, 'dbc92f4d77130e3a05fee9d7f37cd128', 'Non-editing teachers can teach in courses and grade students, but may not alter activities.', 1329398882),
(10, '53ad46511f5b1356ab8eb29d3c1c4cbf', 'Students generally have fewer privileges within a course.', 1329398882),
(11, 'ac13edf81e3c31bb72118fb0931c03d0', 'Guests have minimal privileges and usually can not enter text anywhere.', 1329398882),
(12, '91c495815f6be4e394b5bfa412f003c5', 'All logged in users.', 1329398882),
(13, 'ede09bf4613bad2f6c11679e2b72d45d', ' Blabla ', 1326975810),
(14, 'db326b0753cd89ab85be0e4ae3d75d6c', '<p>blabla</p>', 1326975810),
(15, '69157a9106e1d4920ae6bcc909a82bd2', 'blabla ', 1326976869),
(16, '34971dab2144a67cd27d8bf1bf6d6c58', ' Test choice ', 1331205201),
(17, '605c02d1783db0137a703f4618f4a75e', '<p>Choice 1</p>', 1331205201),
(18, '85cefb63ddf6e639743766e9eb06cbba', '<p>Choice 2</p>', 1331205201),
(19, '2fc00aa7a4f29b47922c7ee74dd4ba75', 'A substitute is a copy of teacher and gets enrolled into all courses. ', 1329386928),
(20, '9be515476019fcb496af97a9d4987446', 'duplicate of Non-editing teacher', 1329389210),
(21, '9a1172e499b2be49591da0fc8c30ce10', ' Substitute is a duplicate of Non-editing teacher. Substitutes get enrolled in all courses.<br /> ', 1329398882),
(22, '1a4e110740bdfd1486ed492aa4a6c01b', 'duplicate of Administrator', 1329388011),
(23, '1afd0f592029be06464f8124e262cd4d', ' Manager is a duplicate of Administrator. This role gets all rights accept for the right to edit the admin user. This way we''ll always have 1 backup user. ', 1329388052),
(24, 'f14911f766a033fe0320af4ec9f8a33f', ' Manager is a duplicate of Administrator.<br />This role gets all rights accept for the right to edit the admin user.<br />This way we''ll always have 1 backup user. ', 1329388080),
(25, '293b6a97d6b6df68da37dd2b96338453', 'School leader is a duplicate of Non-editing teacher.<br />A school leader gets enrolled in all courses.<br /> ', 1329398882),
(26, 'b95f34b6bcbf171f4b4ba979c2146c5c', '<p> Test description </p>', 1331205186),
(27, 'a6e85e07bb3a8e545f94d8d04f5a80cf', 'General news and announcements', 1331205152),
(28, 'dd395f8d53048c16544c4e7ab76843a9', '<p>General news and announcements</p>', 1331205153);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_capabilities`
--

CREATE TABLE IF NOT EXISTS `mdl_capabilities` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `captype` varchar(50) NOT NULL DEFAULT '',
  `contextlevel` bigint(10) unsigned NOT NULL DEFAULT '0',
  `component` varchar(100) NOT NULL DEFAULT '',
  `riskbitmask` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_capa_nam_uix` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='this defines all capabilities' AUTO_INCREMENT=232 ;

--
-- Dumping data for table `mdl_capabilities`
--

INSERT INTO `mdl_capabilities` (`id`, `name`, `captype`, `contextlevel`, `component`, `riskbitmask`) VALUES
(1, 'moodle/site:doanything', 'admin', 10, 'moodle', 62),
(2, 'moodle/legacy:guest', 'legacy', 10, 'moodle', 0),
(3, 'moodle/legacy:user', 'legacy', 10, 'moodle', 0),
(4, 'moodle/legacy:student', 'legacy', 10, 'moodle', 16),
(5, 'moodle/legacy:teacher', 'legacy', 10, 'moodle', 24),
(6, 'moodle/legacy:editingteacher', 'legacy', 10, 'moodle', 28),
(7, 'moodle/legacy:coursecreator', 'legacy', 10, 'moodle', 28),
(8, 'moodle/legacy:admin', 'legacy', 10, 'moodle', 62),
(9, 'moodle/site:config', 'write', 10, 'moodle', 62),
(10, 'moodle/site:readallmessages', 'read', 10, 'moodle', 8),
(11, 'moodle/site:sendmessage', 'write', 10, 'moodle', 16),
(12, 'moodle/site:approvecourse', 'write', 10, 'moodle', 4),
(13, 'moodle/site:import', 'write', 50, 'moodle', 28),
(14, 'moodle/site:backup', 'write', 50, 'moodle', 28),
(15, 'moodle/backup:userinfo', 'read', 50, 'moodle', 8),
(16, 'moodle/site:restore', 'write', 50, 'moodle', 28),
(17, 'moodle/restore:createuser', 'write', 10, 'moodle', 24),
(18, 'moodle/restore:userinfo', 'write', 50, 'moodle', 30),
(19, 'moodle/restore:rolldates', 'write', 50, 'moodle', 0),
(20, 'moodle/site:manageblocks', 'write', 80, 'moodle', 20),
(21, 'moodle/site:accessallgroups', 'read', 50, 'moodle', 0),
(22, 'moodle/site:viewfullnames', 'read', 50, 'moodle', 0),
(23, 'moodle/site:viewreports', 'read', 50, 'moodle', 8),
(24, 'moodle/site:trustcontent', 'write', 50, 'moodle', 4),
(25, 'moodle/site:uploadusers', 'write', 10, 'moodle', 24),
(26, 'moodle/site:langeditmaster', 'write', 10, 'moodle', 6),
(27, 'moodle/site:langeditlocal', 'write', 10, 'moodle', 6),
(28, 'moodle/user:create', 'write', 10, 'moodle', 24),
(29, 'moodle/user:delete', 'write', 10, 'moodle', 8),
(30, 'moodle/user:update', 'write', 10, 'moodle', 24),
(31, 'moodle/user:viewdetails', 'read', 50, 'moodle', 0),
(32, 'moodle/user:viewhiddendetails', 'read', 50, 'moodle', 8),
(33, 'moodle/user:loginas', 'write', 50, 'moodle', 30),
(34, 'moodle/role:assign', 'write', 50, 'moodle', 28),
(35, 'moodle/role:override', 'write', 50, 'moodle', 28),
(36, 'moodle/role:safeoverride', 'write', 50, 'moodle', 16),
(37, 'moodle/role:manage', 'write', 10, 'moodle', 28),
(38, 'moodle/role:unassignself', 'write', 50, 'moodle', 0),
(39, 'moodle/role:viewhiddenassigns', 'read', 50, 'moodle', 0),
(40, 'moodle/role:switchroles', 'read', 50, 'moodle', 12),
(41, 'moodle/category:manage', 'write', 40, 'moodle', 4),
(42, 'moodle/category:viewhiddencategories', 'read', 40, 'moodle', 0),
(43, 'moodle/course:create', 'write', 40, 'moodle', 4),
(44, 'moodle/course:request', 'write', 10, 'moodle', 0),
(45, 'moodle/course:delete', 'write', 50, 'moodle', 32),
(46, 'moodle/course:update', 'write', 50, 'moodle', 4),
(47, 'moodle/course:view', 'read', 50, 'moodle', 0),
(48, 'moodle/course:bulkmessaging', 'write', 50, 'moodle', 16),
(49, 'moodle/course:viewhiddenuserfields', 'read', 50, 'moodle', 8),
(50, 'moodle/course:viewhiddencourses', 'read', 50, 'moodle', 0),
(51, 'moodle/course:visibility', 'write', 50, 'moodle', 0),
(52, 'moodle/course:managefiles', 'write', 50, 'moodle', 4),
(53, 'moodle/course:manageactivities', 'write', 50, 'moodle', 4),
(54, 'moodle/course:managemetacourse', 'write', 50, 'moodle', 12),
(55, 'moodle/course:activityvisibility', 'write', 50, 'moodle', 0),
(56, 'moodle/course:viewhiddenactivities', 'write', 50, 'moodle', 0),
(57, 'moodle/course:viewparticipants', 'read', 50, 'moodle', 0),
(58, 'moodle/course:changefullname', 'write', 50, 'moodle', 4),
(59, 'moodle/course:changeshortname', 'write', 50, 'moodle', 4),
(60, 'moodle/course:changeidnumber', 'write', 50, 'moodle', 4),
(61, 'moodle/course:changecategory', 'write', 50, 'moodle', 4),
(62, 'moodle/course:changesummary', 'write', 50, 'moodle', 4),
(63, 'moodle/site:viewparticipants', 'read', 10, 'moodle', 0),
(64, 'moodle/course:viewscales', 'read', 50, 'moodle', 0),
(65, 'moodle/course:managescales', 'write', 50, 'moodle', 0),
(66, 'moodle/course:managegroups', 'write', 50, 'moodle', 0),
(67, 'moodle/course:reset', 'write', 50, 'moodle', 32),
(68, 'moodle/blog:view', 'read', 50, 'moodle', 0),
(69, 'moodle/blog:create', 'write', 10, 'moodle', 16),
(70, 'moodle/blog:manageentries', 'write', 50, 'moodle', 16),
(71, 'moodle/calendar:manageownentries', 'write', 50, 'moodle', 16),
(72, 'moodle/calendar:managegroupentries', 'write', 50, 'moodle', 16),
(73, 'moodle/calendar:manageentries', 'write', 50, 'moodle', 16),
(74, 'moodle/user:editprofile', 'write', 30, 'moodle', 24),
(75, 'moodle/user:editownprofile', 'write', 10, 'moodle', 16),
(76, 'moodle/user:changeownpassword', 'write', 10, 'moodle', 0),
(77, 'moodle/user:readuserposts', 'read', 30, 'moodle', 0),
(78, 'moodle/user:readuserblogs', 'read', 30, 'moodle', 0),
(79, 'moodle/user:viewuseractivitiesreport', 'read', 30, 'moodle', 8),
(80, 'moodle/question:managecategory', 'write', 50, 'moodle', 20),
(81, 'moodle/question:add', 'write', 50, 'moodle', 20),
(82, 'moodle/question:editmine', 'write', 50, 'moodle', 20),
(83, 'moodle/question:editall', 'write', 50, 'moodle', 20),
(84, 'moodle/question:viewmine', 'read', 50, 'moodle', 0),
(85, 'moodle/question:viewall', 'read', 50, 'moodle', 0),
(86, 'moodle/question:usemine', 'read', 50, 'moodle', 0),
(87, 'moodle/question:useall', 'read', 50, 'moodle', 0),
(88, 'moodle/question:movemine', 'write', 50, 'moodle', 0),
(89, 'moodle/question:moveall', 'write', 50, 'moodle', 0),
(90, 'moodle/question:config', 'write', 10, 'moodle', 2),
(91, 'moodle/site:doclinks', 'read', 10, 'moodle', 0),
(92, 'moodle/course:sectionvisibility', 'write', 50, 'moodle', 0),
(93, 'moodle/course:useremail', 'write', 50, 'moodle', 0),
(94, 'moodle/course:viewhiddensections', 'write', 50, 'moodle', 0),
(95, 'moodle/course:setcurrentsection', 'write', 50, 'moodle', 0),
(96, 'moodle/site:mnetlogintoremote', 'read', 10, 'moodle', 0),
(97, 'moodle/grade:viewall', 'read', 50, 'moodle', 8),
(98, 'moodle/grade:view', 'read', 50, 'moodle', 0),
(99, 'moodle/grade:viewhidden', 'read', 50, 'moodle', 8),
(100, 'moodle/grade:import', 'write', 50, 'moodle', 12),
(101, 'moodle/grade:export', 'read', 50, 'moodle', 8),
(102, 'moodle/grade:manage', 'write', 50, 'moodle', 12),
(103, 'moodle/grade:edit', 'write', 50, 'moodle', 12),
(104, 'moodle/grade:manageoutcomes', 'write', 50, 'moodle', 0),
(105, 'moodle/grade:manageletters', 'write', 50, 'moodle', 0),
(106, 'moodle/grade:hide', 'write', 50, 'moodle', 0),
(107, 'moodle/grade:lock', 'write', 50, 'moodle', 0),
(108, 'moodle/grade:unlock', 'write', 50, 'moodle', 0),
(109, 'moodle/my:manageblocks', 'write', 10, 'moodle', 0),
(110, 'moodle/notes:view', 'read', 50, 'moodle', 0),
(111, 'moodle/notes:manage', 'write', 50, 'moodle', 16),
(112, 'moodle/tag:manage', 'write', 10, 'moodle', 16),
(113, 'moodle/tag:create', 'write', 10, 'moodle', 16),
(114, 'moodle/tag:edit', 'write', 10, 'moodle', 16),
(115, 'moodle/tag:editblocks', 'write', 10, 'moodle', 0),
(116, 'moodle/block:view', 'read', 80, 'moodle', 0),
(117, 'mod/assignment:view', 'read', 70, 'mod/assignment', 0),
(118, 'mod/assignment:submit', 'write', 70, 'mod/assignment', 0),
(119, 'mod/assignment:grade', 'write', 70, 'mod/assignment', 4),
(120, 'mod/chat:chat', 'write', 70, 'mod/chat', 16),
(121, 'mod/chat:readlog', 'read', 70, 'mod/chat', 0),
(122, 'mod/chat:deletelog', 'write', 70, 'mod/chat', 0),
(123, 'mod/choice:choose', 'write', 70, 'mod/choice', 0),
(124, 'mod/choice:readresponses', 'read', 70, 'mod/choice', 0),
(125, 'mod/choice:deleteresponses', 'write', 70, 'mod/choice', 0),
(126, 'mod/choice:downloadresponses', 'read', 70, 'mod/choice', 0),
(127, 'mod/data:viewentry', 'read', 70, 'mod/data', 0),
(128, 'mod/data:writeentry', 'write', 70, 'mod/data', 16),
(129, 'mod/data:comment', 'write', 70, 'mod/data', 16),
(130, 'mod/data:viewrating', 'read', 70, 'mod/data', 0),
(131, 'mod/data:rate', 'write', 70, 'mod/data', 0),
(132, 'mod/data:approve', 'write', 70, 'mod/data', 16),
(133, 'mod/data:manageentries', 'write', 70, 'mod/data', 16),
(134, 'mod/data:managecomments', 'write', 70, 'mod/data', 16),
(135, 'mod/data:managetemplates', 'write', 70, 'mod/data', 20),
(136, 'mod/data:viewalluserpresets', 'read', 70, 'mod/data', 0),
(137, 'mod/data:manageuserpresets', 'write', 70, 'mod/data', 20),
(138, 'mod/forum:viewdiscussion', 'read', 70, 'mod/forum', 0),
(139, 'mod/forum:viewhiddentimedposts', 'read', 70, 'mod/forum', 0),
(140, 'mod/forum:startdiscussion', 'write', 70, 'mod/forum', 16),
(141, 'mod/forum:replypost', 'write', 70, 'mod/forum', 16),
(142, 'mod/forum:addnews', 'write', 70, 'mod/forum', 16),
(143, 'mod/forum:replynews', 'write', 70, 'mod/forum', 16),
(144, 'mod/forum:viewrating', 'read', 70, 'mod/forum', 0),
(145, 'mod/forum:viewanyrating', 'read', 70, 'mod/forum', 0),
(146, 'mod/forum:rate', 'write', 70, 'mod/forum', 0),
(147, 'mod/forum:createattachment', 'write', 70, 'mod/forum', 16),
(148, 'mod/forum:deleteownpost', 'read', 70, 'mod/forum', 0),
(149, 'mod/forum:deleteanypost', 'read', 70, 'mod/forum', 0),
(150, 'mod/forum:splitdiscussions', 'read', 70, 'mod/forum', 0),
(151, 'mod/forum:movediscussions', 'read', 70, 'mod/forum', 0),
(152, 'mod/forum:editanypost', 'write', 70, 'mod/forum', 16),
(153, 'mod/forum:viewqandawithoutposting', 'read', 70, 'mod/forum', 0),
(154, 'mod/forum:viewsubscribers', 'read', 70, 'mod/forum', 0),
(155, 'mod/forum:managesubscriptions', 'read', 70, 'mod/forum', 16),
(156, 'mod/forum:initialsubscriptions', 'read', 70, 'mod/forum', 0),
(157, 'mod/forum:throttlingapplies', 'write', 70, 'mod/forum', 16),
(158, 'mod/glossary:write', 'write', 70, 'mod/glossary', 16),
(159, 'mod/glossary:manageentries', 'write', 70, 'mod/glossary', 16),
(160, 'mod/glossary:managecategories', 'write', 70, 'mod/glossary', 16),
(161, 'mod/glossary:comment', 'write', 70, 'mod/glossary', 16),
(162, 'mod/glossary:managecomments', 'write', 70, 'mod/glossary', 16),
(163, 'mod/glossary:import', 'write', 70, 'mod/glossary', 16),
(164, 'mod/glossary:export', 'read', 70, 'mod/glossary', 0),
(165, 'mod/glossary:approve', 'write', 70, 'mod/glossary', 16),
(166, 'mod/glossary:rate', 'write', 70, 'mod/glossary', 0),
(167, 'mod/glossary:viewrating', 'read', 70, 'mod/glossary', 0),
(168, 'mod/hotpot:attempt', 'read', 70, 'mod/hotpot', 0),
(169, 'mod/hotpot:viewreport', 'read', 70, 'mod/hotpot', 0),
(170, 'mod/hotpot:grade', 'read', 70, 'mod/hotpot', 0),
(171, 'mod/hotpot:deleteattempt', 'read', 70, 'mod/hotpot', 0),
(172, 'mod/lams:participate', 'write', 70, 'mod/lams', 0),
(173, 'mod/lams:manage', 'write', 70, 'mod/lams', 0),
(174, 'mod/lesson:edit', 'write', 70, 'mod/lesson', 4),
(175, 'mod/lesson:manage', 'write', 70, 'mod/lesson', 0),
(176, 'mod/quiz:view', 'read', 70, 'mod/quiz', 0),
(177, 'mod/quiz:attempt', 'write', 70, 'mod/quiz', 16),
(178, 'mod/quiz:reviewmyattempts', 'read', 70, 'mod/quiz', 0),
(179, 'mod/quiz:manage', 'write', 70, 'mod/quiz', 16),
(180, 'mod/quiz:preview', 'write', 70, 'mod/quiz', 0),
(181, 'mod/quiz:grade', 'write', 70, 'mod/quiz', 16),
(182, 'mod/quiz:viewreports', 'read', 70, 'mod/quiz', 8),
(183, 'mod/quiz:deleteattempts', 'write', 70, 'mod/quiz', 32),
(184, 'mod/quiz:ignoretimelimits', 'read', 70, 'mod/quiz', 0),
(185, 'mod/quiz:emailconfirmsubmission', 'read', 70, 'mod/quiz', 0),
(186, 'mod/quiz:emailnotifysubmission', 'read', 70, 'mod/quiz', 0),
(187, 'mod/scorm:viewreport', 'read', 70, 'mod/scorm', 0),
(188, 'mod/scorm:skipview', 'write', 70, 'mod/scorm', 0),
(189, 'mod/scorm:savetrack', 'write', 70, 'mod/scorm', 0),
(190, 'mod/scorm:viewscores', 'read', 70, 'mod/scorm', 0),
(191, 'mod/scorm:deleteresponses', 'read', 70, 'mod/scorm', 0),
(192, 'mod/survey:participate', 'read', 70, 'mod/survey', 0),
(193, 'mod/survey:readresponses', 'read', 70, 'mod/survey', 0),
(194, 'mod/survey:download', 'read', 70, 'mod/survey', 0),
(195, 'mod/wiki:participate', 'write', 70, 'mod/wiki', 16),
(196, 'mod/wiki:manage', 'write', 70, 'mod/wiki', 16),
(197, 'mod/wiki:overridelock', 'write', 70, 'mod/wiki', 0),
(198, 'mod/workshop:participate', 'write', 70, 'mod/workshop', 16),
(199, 'mod/workshop:manage', 'write', 70, 'mod/workshop', 16),
(200, 'block/online_users:viewlist', 'read', 80, 'block/online_users', 0),
(201, 'block/rss_client:createprivatefeeds', 'write', 80, 'block/rss_client', 0),
(202, 'block/rss_client:createsharedfeeds', 'write', 80, 'block/rss_client', 16),
(203, 'block/rss_client:manageownfeeds', 'write', 80, 'block/rss_client', 0),
(204, 'block/rss_client:manageanyfeeds', 'write', 80, 'block/rss_client', 16),
(205, 'enrol/authorize:managepayments', 'write', 10, 'enrol/authorize', 8),
(206, 'enrol/authorize:uploadcsv', 'write', 10, 'enrol/authorize', 4),
(207, 'gradeexport/ods:view', 'read', 50, 'gradeexport/ods', 8),
(208, 'gradeexport/ods:publish', 'read', 50, 'gradeexport/ods', 8),
(209, 'gradeexport/txt:view', 'read', 50, 'gradeexport/txt', 8),
(210, 'gradeexport/txt:publish', 'read', 50, 'gradeexport/txt', 8),
(211, 'gradeexport/xls:view', 'read', 50, 'gradeexport/xls', 8),
(212, 'gradeexport/xls:publish', 'read', 50, 'gradeexport/xls', 8),
(213, 'gradeexport/xml:view', 'read', 50, 'gradeexport/xml', 8),
(214, 'gradeexport/xml:publish', 'read', 50, 'gradeexport/xml', 8),
(215, 'gradeimport/csv:view', 'write', 50, 'gradeimport/csv', 0),
(216, 'gradeimport/xml:view', 'write', 50, 'gradeimport/xml', 0),
(217, 'gradeimport/xml:publish', 'write', 50, 'gradeimport/xml', 0),
(218, 'gradereport/grader:view', 'read', 50, 'gradereport/grader', 8),
(219, 'gradereport/outcomes:view', 'read', 50, 'gradereport/outcomes', 8),
(220, 'gradereport/overview:view', 'read', 50, 'gradereport/overview', 8),
(221, 'gradereport/user:view', 'read', 50, 'gradereport/user', 8),
(222, 'coursereport/log:view', 'read', 50, 'coursereport/log', 8),
(223, 'coursereport/log:viewlive', 'read', 50, 'coursereport/log', 8),
(224, 'coursereport/log:viewtoday', 'read', 50, 'coursereport/log', 8),
(225, 'coursereport/outline:view', 'read', 50, 'coursereport/outline', 8),
(226, 'coursereport/participation:view', 'read', 50, 'coursereport/participation', 8),
(227, 'coursereport/stats:view', 'read', 50, 'coursereport/stats', 8),
(228, 'report/courseoverview:view', 'read', 10, 'report/courseoverview', 8),
(229, 'report/security:view', 'read', 10, 'report/security', 2),
(230, 'report/unittest:view', 'read', 10, 'report/unittest', 32),
(231, 'mod/launcher:access', 'write', 10, 'mod/launcher', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_chat`
--

CREATE TABLE IF NOT EXISTS `mdl_chat` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `intro` text NOT NULL,
  `keepdays` bigint(11) NOT NULL DEFAULT '0',
  `studentlogs` smallint(4) NOT NULL DEFAULT '0',
  `chattime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `schedule` smallint(4) NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_chat_cou_ix` (`course`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Each of these is a chat room' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mdl_chat`
--

INSERT INTO `mdl_chat` (`id`, `course`, `name`, `intro`, `keepdays`, `studentlogs`, `chattime`, `schedule`, `timemodified`) VALUES
(1, 2, 'Test chat', 'Test chat<br /> ', 0, 0, 1329316200, 0, 1329316389);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_chat_messages`
--

CREATE TABLE IF NOT EXISTS `mdl_chat_messages` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` bigint(10) NOT NULL DEFAULT '0',
  `userid` bigint(10) NOT NULL DEFAULT '0',
  `groupid` bigint(10) NOT NULL DEFAULT '0',
  `system` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `timestamp` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_chatmess_use_ix` (`userid`),
  KEY `mdl_chatmess_gro_ix` (`groupid`),
  KEY `mdl_chatmess_timcha_ix` (`timestamp`,`chatid`),
  KEY `mdl_chatmess_cha_ix` (`chatid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores all the actual chat messages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_chat_messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_chat_users`
--

CREATE TABLE IF NOT EXISTS `mdl_chat_users` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `chatid` bigint(11) NOT NULL DEFAULT '0',
  `userid` bigint(11) NOT NULL DEFAULT '0',
  `groupid` bigint(11) NOT NULL DEFAULT '0',
  `version` varchar(16) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `firstping` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lastping` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lastmessageping` bigint(10) unsigned NOT NULL DEFAULT '0',
  `sid` varchar(32) NOT NULL DEFAULT '',
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lang` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_chatuser_use_ix` (`userid`),
  KEY `mdl_chatuser_las_ix` (`lastping`),
  KEY `mdl_chatuser_gro_ix` (`groupid`),
  KEY `mdl_chatuser_cha_ix` (`chatid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Keeps track of which users are in which chat rooms' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_chat_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_choice`
--

CREATE TABLE IF NOT EXISTS `mdl_choice` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `text` text NOT NULL,
  `format` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `publish` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `showresults` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `display` smallint(4) unsigned NOT NULL DEFAULT '0',
  `allowupdate` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `showunanswered` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `limitanswers` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `timeopen` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeclose` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_choi_cou_ix` (`course`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Available choices are stored here' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mdl_choice`
--

INSERT INTO `mdl_choice` (`id`, `course`, `name`, `text`, `format`, `publish`, `showresults`, `display`, `allowupdate`, `showunanswered`, `limitanswers`, `timeopen`, `timeclose`, `timemodified`) VALUES
(1, 3, 'test choice', ' Blabla ', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1326975312),
(2, 2, 'Test choice', ' Test choice ', 1, 1, 1, 0, 0, 0, 0, 0, 0, 1331205250);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_choice_answers`
--

CREATE TABLE IF NOT EXISTS `mdl_choice_answers` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `choiceid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `optionid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_choiansw_use_ix` (`userid`),
  KEY `mdl_choiansw_cho_ix` (`choiceid`),
  KEY `mdl_choiansw_opt_ix` (`optionid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='choices performed by users' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mdl_choice_answers`
--

INSERT INTO `mdl_choice_answers` (`id`, `choiceid`, `userid`, `optionid`, `timemodified`) VALUES
(1, 2, 2, 3, 1331205204);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_choice_options`
--

CREATE TABLE IF NOT EXISTS `mdl_choice_options` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `choiceid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `text` text,
  `maxanswers` bigint(10) unsigned DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_choiopti_cho_ix` (`choiceid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='available options to choice' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `mdl_choice_options`
--

INSERT INTO `mdl_choice_options` (`id`, `choiceid`, `text`, `maxanswers`, `timemodified`) VALUES
(1, 1, 'blabla', 0, 1326975312),
(2, 1, 'blabla', 0, 1326975312),
(3, 2, 'Choice 1', 0, 1331205250),
(4, 2, 'Choice 2', 0, 1331205250);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_config`
--

CREATE TABLE IF NOT EXISTS `mdl_config` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_conf_nam_uix` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Moodle configuration variables' AUTO_INCREMENT=434 ;

--
-- Dumping data for table `mdl_config`
--

INSERT INTO `mdl_config` (`id`, `name`, `value`) VALUES
(1, 'unicodedb', '1'),
(2, 'statsrolesupgraded', '1323876845'),
(3, 'auth', 'email'),
(4, 'auth_pop3mailbox', 'INBOX'),
(5, 'enrol', 'manual'),
(6, 'enrol_plugins_enabled', 'manual'),
(7, 'style', 'default'),
(8, 'template', 'default'),
(9, 'theme', 'children-education'),
(10, 'filter_multilang_converted', '1'),
(429, 'registerauth', ''),
(12, 'guestloginbutton', '1'),
(13, 'alternateloginurl', ''),
(14, 'forgottenpasswordurl', ''),
(15, 'auth_instructions', ''),
(16, 'allowemailaddresses', ''),
(17, 'denyemailaddresses', ''),
(18, 'verifychangedemail', '1'),
(19, 'recaptchapublickey', ''),
(20, 'recaptchaprivatekey', ''),
(21, 'nodefaultuserrolelists', '0'),
(22, 'autologinguests', '0'),
(23, 'hiddenuserfields', ''),
(24, 'allowuserswitchrolestheycantassign', '0'),
(25, 'enablecourserequests', '0'),
(26, 'courserequestnotify', ''),
(27, 'timezone', '99'),
(28, 'forcetimezone', '99'),
(29, 'country', '0'),
(30, 'geoipfile', '/home/menno/php_projects/jeelo/moodle_data/geoip/GeoLiteCity.dat'),
(31, 'googlemapkey', ''),
(32, 'autolang', '1'),
(33, 'lang', 'en_utf8'),
(34, 'langmenu', '1'),
(35, 'langlist', ''),
(36, 'langcache', '1'),
(37, 'locale', ''),
(38, 'latinexcelexport', '0'),
(39, 'cachetext', '60'),
(40, 'filteruploadedfiles', '0'),
(41, 'filtermatchoneperpage', '0'),
(42, 'filtermatchonepertext', '0'),
(43, 'filterall', '0'),
(44, 'filter_multilang_force_old', '0'),
(45, 'filter_mediaplugin_enable_mp3', '1'),
(46, 'filter_mediaplugin_enable_swf', '0'),
(47, 'filter_mediaplugin_enable_mov', '1'),
(48, 'filter_mediaplugin_enable_wmv', '1'),
(49, 'filter_mediaplugin_enable_mpg', '1'),
(50, 'filter_mediaplugin_enable_avi', '1'),
(51, 'filter_mediaplugin_enable_flv', '1'),
(52, 'filter_mediaplugin_enable_ram', '1'),
(53, 'filter_mediaplugin_enable_rpm', '1'),
(54, 'filter_mediaplugin_enable_rm', '1'),
(55, 'filter_mediaplugin_enable_youtube', '0'),
(56, 'filter_mediaplugin_enable_ogg', '1'),
(57, 'filter_mediaplugin_enable_ogv', '1'),
(58, 'filter_tex_latexpreamble', '\\usepackage[latin1]{inputenc}\n\\usepackage{amsmath}\n\\usepackage{amsfonts}\n\\RequirePackage{amsmath,amssymb,latexsym}\n'),
(59, 'filter_tex_latexbackground', '#FFFFFF'),
(60, 'filter_tex_density', '120'),
(61, 'filter_tex_pathlatex', '/usr/bin/latex'),
(62, 'filter_tex_pathdvips', '/usr/bin/dvips'),
(63, 'filter_tex_pathconvert', '/usr/bin/convert'),
(64, 'filter_tex_convertformat', 'gif'),
(65, 'filter_censor_badwords', ''),
(66, 'protectusernames', '1'),
(67, 'forcelogin', '0'),
(68, 'forceloginforprofiles', '1'),
(69, 'opentogoogle', '0'),
(70, 'maxbytes', '0'),
(71, 'messaging', '1'),
(72, 'allowobjectembed', '0'),
(73, 'enabletrusttext', '0'),
(74, 'maxeditingtime', '1800'),
(75, 'fullnamedisplay', 'language'),
(76, 'extendedusernamechars', '0'),
(77, 'sitepolicy', ''),
(78, 'bloglevel', '4'),
(79, 'usetags', '1'),
(80, 'keeptagnamecase', '1'),
(81, 'profilesforenrolledusersonly', '1'),
(82, 'cronclionly', '0'),
(83, 'cronremotepassword', ''),
(84, 'passwordpolicy', '1'),
(85, 'minpasswordlength', '8'),
(86, 'minpassworddigits', '1'),
(87, 'minpasswordlower', '1'),
(88, 'minpasswordupper', '1'),
(89, 'minpasswordnonalphanum', '1'),
(90, 'disableuserimages', '0'),
(91, 'emailchangeconfirmation', '1'),
(92, 'enablenotes', '1'),
(93, 'loginhttps', '0'),
(94, 'cookiesecure', '0'),
(95, 'cookiehttponly', '0'),
(96, 'regenloginsession', '1'),
(97, 'excludeoldflashclients', '10.0.12'),
(98, 'loginpasswordautocomplete', '0'),
(99, 'restrictmodulesfor', 'none'),
(100, 'restrictbydefault', '0'),
(101, 'displayloginfailures', ''),
(102, 'notifyloginfailures', ''),
(103, 'notifyloginthreshold', '10'),
(104, 'runclamonupload', '0'),
(105, 'pathtoclam', ''),
(106, 'quarantinedir', ''),
(107, 'clamfailureonupload', 'donothing'),
(108, 'themelist', ''),
(109, 'allowuserthemes', '0'),
(110, 'allowcoursethemes', '0'),
(111, 'allowcategorythemes', '0'),
(112, 'allowuserblockhiding', '1'),
(113, 'showblocksonmodpages', '0'),
(114, 'hideactivitytypenavlink', '0'),
(115, 'calendar_adminseesall', '0'),
(116, 'calendar_site_timeformat', '0'),
(117, 'calendar_startwday', '0'),
(118, 'calendar_weekend', '65'),
(119, 'calendar_lookahead', '21'),
(120, 'calendar_maxevents', '10'),
(121, 'enablecalendarexport', '1'),
(122, 'calendar_exportsalt', 'yxerahG5YXEf1J3zf2MRw3FykWp8abNfyhihrXahCCtqRPAaiU0pGlZmKujt'),
(123, 'htmleditor', '1'),
(124, 'editorbackgroundcolor', '#ffffff'),
(125, 'editorfontfamily', 'Trebuchet MS,Verdana,Arial,Helvetica,sans-serif'),
(126, 'editorfontsize', ''),
(127, 'editorfontlist', 'Trebuchet:Trebuchet MS,Verdana,Arial,Helvetica,sans-serif;Arial:arial,helvetica,sans-serif;Courier New:courier new,courier,monospace;Georgia:georgia,times new roman,times,serif;Tahoma:tahoma,arial,helvetica,sans-serif;Times New Roman:times new roman,times,serif;Verdana:verdana,arial,helvetica,sans-serif;Impact:impact;Wingdings:wingdings'),
(128, 'editorkillword', '1'),
(129, 'editorhidebuttons', ''),
(130, 'emoticons', ':-){:}smiley{;}:){:}smiley{;}:-D{:}biggrin{;};-){:}wink{;}:-/{:}mixed{;}V-.{:}thoughtful{;}:-P{:}tongueout{;}B-){:}cool{;}^-){:}approve{;}8-){:}wideeyes{;}:o){:}clown{;}:-({:}sad{;}:({:}sad{;}8-.{:}shy{;}:-I{:}blush{;}:-X{:}kiss{;}8-o{:}surprise{;}P-|{:}blackeye{;}8-[{:}angry{;}xx-P{:}dead{;}|-.{:}sleepy{;}}-]{:}evil{;}(h){:}heart{;}(heart){:}heart{;}(y){:}yes{;}(n){:}no{;}(martin){:}martin{;}( ){:}egg'),
(131, 'formatstringstriptags', '1'),
(132, 'docroot', 'http://docs.moodle.org'),
(133, 'doctonewwindow', '0'),
(134, 'mymoodleredirect', '0'),
(135, 'mycoursesperpage', '21'),
(136, 'enableajax', '1'),
(137, 'disablecourseajax', '1'),
(138, 'gdversion', '2'),
(139, 'zip', ''),
(140, 'unzip', ''),
(141, 'pathtodu', ''),
(142, 'aspellpath', ''),
(143, 'smtphosts', ''),
(144, 'smtpuser', ''),
(145, 'smtppass', ''),
(146, 'smtpmaxbulk', '1'),
(147, 'noreplyaddress', 'noreply@localhost'),
(148, 'digestmailtime', '17'),
(149, 'sitemailcharset', '0'),
(150, 'allowusermailcharset', '0'),
(151, 'mailnewline', 'LF'),
(152, 'supportpage', ''),
(153, 'dbsessions', '0'),
(154, 'sessiontimeout', '7200'),
(155, 'sessioncookie', ''),
(156, 'sessioncookiepath', '/'),
(157, 'sessioncookiedomain', ''),
(158, 'enablerssfeeds', '0'),
(159, 'debug', '38911'),
(160, 'debugdisplay', '1'),
(161, 'xmlstrictheaders', '0'),
(162, 'debugsmtp', '0'),
(163, 'perfdebug', '7'),
(164, 'enablestats', '0'),
(165, 'statsfirstrun', 'none'),
(166, 'statsmaxruntime', '0'),
(167, 'statsruntimedays', '31'),
(168, 'statsruntimestarthour', '0'),
(169, 'statsruntimestartminute', '0'),
(170, 'statsuserthreshold', '0'),
(171, 'statscatdepth', '1'),
(172, 'framename', '_top'),
(173, 'slasharguments', '1'),
(174, 'getremoteaddrconf', '0'),
(175, 'proxyhost', ''),
(176, 'proxyport', '0'),
(177, 'proxytype', 'HTTP'),
(178, 'proxyuser', ''),
(179, 'proxypassword', ''),
(180, 'longtimenosee', '120'),
(181, 'deleteunconfirmed', '168'),
(182, 'deleteincompleteusers', '0'),
(183, 'loglifetime', '0'),
(184, 'disablegradehistory', '0'),
(185, 'gradehistorylifetime', '0'),
(186, 'extramemorylimit', '128M'),
(187, 'cachetype', ''),
(188, 'rcache', '0'),
(189, 'rcachettl', '10'),
(190, 'intcachemax', '10'),
(191, 'memcachedhosts', ''),
(192, 'memcachedpconn', '0'),
(193, 'enableglobalsearch', '0'),
(194, 'smartpix', '0'),
(195, 'enablehtmlpurifier', '0'),
(196, 'enablegroupings', '0'),
(197, 'experimentalsplitrestore', '0'),
(198, 'enableimsccimport', '0'),
(199, 'enablesafebrowserintegration', '0'),
(200, 'mnet_dispatcher_mode', 'off'),
(201, 'mnet_localhost_id', '1'),
(202, 'mnet_all_hosts_id', '2'),
(203, 'version', '2007101591.08'),
(204, 'release', '1.9.15+ (Build: 20111205)'),
(205, 'assignment_type_online_version', '2005042900'),
(206, 'hotpot_showtimes', '0'),
(207, 'hotpot_excelencodings', ''),
(208, 'hotpot_initialdisable', '1'),
(209, 'journal_showrecentactivity', '1'),
(210, 'journal_initialdisable', '1'),
(211, 'lams_initialdisable', '1'),
(212, 'quiz_review', '16777215'),
(213, 'quiz_attemptonlast', '0'),
(214, 'quiz_attempts', '0'),
(215, 'quiz_grademethod', ''),
(216, 'quiz_decimalpoints', '2'),
(217, 'quiz_maximumgrade', '10'),
(218, 'quiz_password', ''),
(219, 'quiz_popup', '0'),
(220, 'quiz_questionsperpage', '0'),
(221, 'quiz_shuffleanswers', '1'),
(222, 'quiz_shufflequestions', '0'),
(223, 'quiz_subnet', ''),
(224, 'quiz_timelimit', '0'),
(225, 'quiz_optionflags', '1'),
(226, 'quiz_penaltyscheme', '1'),
(227, 'quiz_delay1', '0'),
(228, 'quiz_delay2', '0'),
(229, 'quiz_fix_review', '0'),
(230, 'quiz_fix_attemptonlast', '0'),
(231, 'quiz_fix_attempts', '0'),
(232, 'quiz_fix_grademethod', '0'),
(233, 'quiz_fix_decimalpoints', '0'),
(234, 'quiz_fix_password', '0'),
(235, 'quiz_fix_popup', '0'),
(236, 'quiz_fix_questionsperpage', '0'),
(237, 'quiz_fix_shuffleanswers', '0'),
(238, 'quiz_fix_shufflequestions', '0'),
(239, 'quiz_fix_subnet', '0'),
(240, 'quiz_fix_timelimit', '0'),
(241, 'quiz_fix_adaptive', '0'),
(242, 'quiz_fix_penaltyscheme', '0'),
(243, 'quiz_fix_delay1', '0'),
(244, 'quiz_fix_delay2', '0'),
(245, 'resource_hide_repository', '1'),
(246, 'workshop_initialdisable', '1'),
(247, 'qtype_calculated_version', '2006032200'),
(248, 'qtype_essay_version', '2006032200'),
(249, 'qtype_match_version', '2006032200'),
(250, 'qtype_multianswer_version', '2008050800'),
(251, 'qtype_multichoice_version', '2007081700'),
(252, 'qtype_numerical_version', '2006121500'),
(253, 'qtype_randomsamatch_version', '2006042800'),
(254, 'qtype_shortanswer_version', '2006032200'),
(255, 'qtype_truefalse_version', '2006032200'),
(256, 'backup_version', '2009111300'),
(257, 'backup_release', '1.9.7'),
(258, 'blocks_version', '2007081300'),
(259, 'enrol_authorize_version', '2006112903'),
(260, 'enrol_paypal_version', '2006092200'),
(261, 'gradeexport_ods_version', '2007092701'),
(262, 'gradeexport_txt_version', '2007092700'),
(263, 'gradeexport_xls_version', '2007092700'),
(264, 'gradeexport_xml_version', '2007092700'),
(265, 'gradeimport_csv_version', '2007072500'),
(266, 'gradeimport_xml_version', '2007092700'),
(267, 'gradereport_grader_version', '2007091700'),
(268, 'gradereport_outcomes_version', '2007073000'),
(269, 'gradereport_overview_version', '2009022500'),
(270, 'gradereport_user_version', '2007092500'),
(271, 'coursereport_log_version', '2007101504'),
(272, 'coursereport_outline_version', '2007101501'),
(273, 'coursereport_participation_version', '2007101501'),
(274, 'coursereport_stats_version', '2007101501'),
(275, 'report_courseoverview_version', '2007101503'),
(276, 'report_security_version', '2007101500'),
(277, 'report_unittest_version', '2007101501'),
(278, 'adminblocks_initialised', '1'),
(279, 'siteidentifier', 'o9zZYyl3HYYKaE4rlGEXkklgOheMjJDJlocalhost'),
(280, 'rolesactive', '1'),
(281, 'guestroleid', '6'),
(282, 'creatornewroleid', '3'),
(283, 'notloggedinroleid', '6'),
(284, 'defaultuserroleid', '7'),
(285, 'defaultcourseroleid', '5'),
(286, 'nonmetacoursesyncroleids', ''),
(287, 'defaultrequestcategory', '1'),
(288, 'gradebookroles', '5'),
(289, 'enableoutcomes', '0'),
(290, 'grade_profilereport', 'user'),
(291, 'grade_aggregationposition', '1'),
(292, 'grade_includescalesinaggregation', '1'),
(293, 'grade_hiddenasdate', '0'),
(294, 'gradepublishing', '0'),
(295, 'grade_export_displaytype', '1'),
(296, 'grade_export_decimalpoints', '2'),
(297, 'grade_navmethod', '0'),
(298, 'gradeexport', ''),
(299, 'unlimitedgrades', '0'),
(300, 'grade_hideforcedsettings', '1'),
(301, 'grade_aggregation', '6'),
(302, 'grade_aggregation_flag', '0'),
(303, 'grade_aggregations_visible', '0,10,11,12,2,4,6,8,13'),
(304, 'grade_aggregateonlygraded', '1'),
(305, 'grade_aggregateonlygraded_flag', '2'),
(306, 'grade_aggregateoutcomes', '0'),
(307, 'grade_aggregateoutcomes_flag', '2'),
(308, 'grade_aggregatesubcats', '0'),
(309, 'grade_aggregatesubcats_flag', '2'),
(310, 'grade_keephigh', '0'),
(311, 'grade_keephigh_flag', '3'),
(312, 'grade_droplow', '0'),
(313, 'grade_droplow_flag', '2'),
(314, 'grade_displaytype', '1'),
(315, 'grade_decimalpoints', '2'),
(316, 'grade_item_advanced', 'iteminfo,idnumber,gradepass,plusfactor,multfactor,display,decimals,hiddenuntil,locktime'),
(317, 'grade_report_studentsperpage', '100'),
(318, 'grade_report_quickgrading', '1'),
(319, 'grade_report_showquickfeedback', '0'),
(320, 'grade_report_fixedstudents', '0'),
(321, 'grade_report_meanselection', '1'),
(322, 'grade_report_showcalculations', '0'),
(323, 'grade_report_showeyecons', '0'),
(324, 'grade_report_showaverages', '1'),
(325, 'grade_report_showlocks', '0'),
(326, 'grade_report_showranges', '0'),
(327, 'grade_report_showuserimage', '1'),
(328, 'grade_report_showuseridnumber', '0'),
(329, 'grade_report_showactivityicons', '1'),
(330, 'grade_report_shownumberofgrades', '0'),
(331, 'grade_report_averagesdisplaytype', 'inherit'),
(332, 'grade_report_rangesdisplaytype', 'inherit'),
(333, 'grade_report_averagesdecimalpoints', 'inherit'),
(334, 'grade_report_rangesdecimalpoints', 'inherit'),
(335, 'grade_report_overview_showrank', '0'),
(336, 'grade_report_overview_showtotalsifcontainhidden', '0'),
(337, 'grade_report_user_showrank', '0'),
(338, 'grade_report_user_showpercentage', '2'),
(339, 'grade_report_user_showhiddenitems', '1'),
(340, 'grade_report_user_showtotalsifcontainhidden', '0'),
(341, 'assignment_maxbytes', '1048576'),
(342, 'assignment_itemstocount', '1'),
(343, 'assignment_showrecentsubmissions', '1'),
(344, 'chat_method', 'header_js'),
(345, 'chat_refresh_userlist', '10'),
(346, 'chat_old_ping', '35'),
(347, 'chat_refresh_room', '5'),
(348, 'chat_normal_updatemode', 'jsupdate'),
(349, 'chat_serverhost', 'localhost'),
(350, 'chat_serverip', '127.0.0.1'),
(351, 'chat_serverport', '9111'),
(352, 'chat_servermax', '100'),
(353, 'data_enablerssfeeds', '0'),
(354, 'forum_displaymode', '3'),
(355, 'forum_replytouser', '1'),
(356, 'forum_shortpost', '300'),
(357, 'forum_longpost', '600'),
(358, 'forum_manydiscussions', '100'),
(359, 'forum_maxbytes', '512000'),
(360, 'forum_trackreadposts', '1'),
(361, 'forum_oldpostdays', '14'),
(362, 'forum_usermarksread', '0'),
(363, 'forum_cleanreadtime', '2'),
(364, 'forum_enablerssfeeds', '0'),
(365, 'forum_enabletimedposts', '0'),
(366, 'forum_logblocked', '1'),
(367, 'forum_ajaxrating', '0'),
(368, 'glossary_entbypage', '10'),
(369, 'glossary_dupentries', '0'),
(370, 'glossary_allowcomments', '0'),
(371, 'glossary_linkbydefault', '1'),
(372, 'glossary_defaultapproval', '1'),
(373, 'glossary_enablerssfeeds', '0'),
(374, 'glossary_linkentries', '0'),
(375, 'glossary_casesensitive', '0'),
(376, 'glossary_fullmatch', '0'),
(377, 'lams_serverurl', ''),
(378, 'lams_serverid', ''),
(379, 'lams_serverkey', ''),
(380, 'resource_framesize', '130'),
(381, 'resource_websearch', 'http://google.com/'),
(382, 'resource_defaulturl', 'http://'),
(383, 'resource_secretphrase', 'b93Gq8IM8Sj90Y0rOYrD'),
(384, 'resource_popup', ''),
(385, 'resource_popupresizable', 'checked'),
(386, 'resource_popupscrollbars', 'checked'),
(387, 'resource_popupdirectories', 'checked'),
(388, 'resource_popuplocation', 'checked'),
(389, 'resource_popupmenubar', 'checked'),
(390, 'resource_popuptoolbar', 'checked'),
(391, 'resource_popupstatus', 'checked'),
(392, 'resource_popupwidth', '620'),
(393, 'resource_popupheight', '450'),
(394, 'resource_autofilerename', '1'),
(395, 'resource_blockdeletingfile', '1'),
(396, 'scorm_grademethod', '1'),
(397, 'scorm_maxgrade', '100'),
(398, 'scorm_maxattempts', '0'),
(399, 'scorm_whatgrade', '0'),
(400, 'scorm_framewidth', '100%'),
(401, 'scorm_frameheight', '500'),
(402, 'scorm_popup', '0'),
(403, 'scorm_resizable', '0'),
(404, 'scorm_scrollbars', '0'),
(405, 'scorm_directories', '0'),
(406, 'scorm_location', '0'),
(407, 'scorm_menubar', '0'),
(408, 'scorm_toolbar', '0'),
(409, 'scorm_status', '0'),
(410, 'scorm_skipview', '0'),
(411, 'scorm_hidebrowse', '0'),
(412, 'scorm_hidetoc', '0'),
(413, 'scorm_hidenav', '0'),
(414, 'scorm_auto', '0'),
(415, 'scorm_updatefreq', '0'),
(416, 'block_course_list_adminview', 'all'),
(417, 'block_course_list_hideallcourseslink', '0'),
(418, 'block_online_users_timetosee', '5'),
(419, 'defaultallowedmodules', ''),
(420, 'coursemanager', '3'),
(421, 'frontpage', '1'),
(422, 'frontpageloggedin', '1'),
(423, 'maxcategorydepth', '0'),
(424, 'coursesperpage', '20'),
(425, 'allowvisiblecoursesinhiddencategories', '0'),
(426, 'defaultfrontpageroleid', '0'),
(427, 'supportname', 'Admin User'),
(428, 'supportemail', 'm.deridder@solin.nl'),
(430, 'siteguest', '1'),
(431, 'jsrev', '1'),
(432, 'themerev', '1'),
(433, 'session_error_counter', '18');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_config_plugins`
--

CREATE TABLE IF NOT EXISTS `mdl_config_plugins` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `plugin` varchar(100) NOT NULL DEFAULT 'core',
  `name` varchar(100) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_confplug_plunam_uix` (`plugin`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Moodle modules and plugins configuration variables' AUTO_INCREMENT=17 ;

--
-- Dumping data for table `mdl_config_plugins`
--

INSERT INTO `mdl_config_plugins` (`id`, `plugin`, `name`, `value`) VALUES
(1, 'moodlecourse', 'format', 'weeks'),
(2, 'moodlecourse', 'numsections', '10'),
(3, 'moodlecourse', 'hiddensections', '0'),
(4, 'moodlecourse', 'newsitems', '5'),
(5, 'moodlecourse', 'showgrades', '1'),
(6, 'moodlecourse', 'showreports', '0'),
(7, 'moodlecourse', 'maxbytes', '2097152'),
(8, 'moodlecourse', 'metacourse', '0'),
(9, 'qtype_random', 'selectmanual', '0'),
(10, 'blocks/section_links', 'numsections1', '22'),
(11, 'blocks/section_links', 'incby1', '2'),
(12, 'blocks/section_links', 'numsections2', '40'),
(13, 'blocks/section_links', 'incby2', '5'),
(14, 'mnet', 'openssl_history', 'a:0:{}'),
(15, 'mnet', 'openssl_generations', '3'),
(16, 'mnet', 'openssl', '-----BEGIN CERTIFICATE-----\nMIIDszCCAxygAwIBAgIBADANBgkqhkiG9w0BAQQFADCBnjELMAkGA1UEBhMCTkwx\nDjAMBgNVBAgTBUJyZWRhMQ4wDAYDVQQHEwVCcmVkYTEXMBUGA1UEChMOSmVlbG8g\nTGF1bmNoZXIxDzANBgNVBAsTBk1vb2RsZTEhMB8GA1UEAxMYaHR0cDovL2xvY2Fs\naG9zdC9qZWVsbzE5MSIwIAYJKoZIhvcNAQkBFhNtLmRlcmlkZGVyQHNvbGluLm5s\nMB4XDTEyMDIxNTE1MDY0NFoXDTEyMDMxNDE1MDY0NFowgZ4xCzAJBgNVBAYTAk5M\nMQ4wDAYDVQQIEwVCcmVkYTEOMAwGA1UEBxMFQnJlZGExFzAVBgNVBAoTDkplZWxv\nIExhdW5jaGVyMQ8wDQYDVQQLEwZNb29kbGUxITAfBgNVBAMTGGh0dHA6Ly9sb2Nh\nbGhvc3QvamVlbG8xOTEiMCAGCSqGSIb3DQEJARYTbS5kZXJpZGRlckBzb2xpbi5u\nbDCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAu89LmMXZkrCqLdBaLOZgPuSD\njQupDD1D46Oh9IfbB1XiVt7VqI79/lot4UkKuiaMsL4HBQZZAM6Ucnua0YZLMh7z\nA2aoYWkQnJSxAVJ1cG4hSKh28qrpZJAurtmmydFKE8ODZkIbg6+5kzWZtS4ubBY3\nU+rrOwmjIqXJOAKHL7kCAwEAAaOB/jCB+zAdBgNVHQ4EFgQUIra+jAOl9KP2p/1z\nNuwWKSp4O5QwgcsGA1UdIwSBwzCBwIAUIra+jAOl9KP2p/1zNuwWKSp4O5ShgaSk\ngaEwgZ4xCzAJBgNVBAYTAk5MMQ4wDAYDVQQIEwVCcmVkYTEOMAwGA1UEBxMFQnJl\nZGExFzAVBgNVBAoTDkplZWxvIExhdW5jaGVyMQ8wDQYDVQQLEwZNb29kbGUxITAf\nBgNVBAMTGGh0dHA6Ly9sb2NhbGhvc3QvamVlbG8xOTEiMCAGCSqGSIb3DQEJARYT\nbS5kZXJpZGRlckBzb2xpbi5ubIIBADAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEB\nBAUAA4GBAIZcWM1Tfxagmt2/dzzw+QHwSqALl1dsJ3u11t6GvJqKQYOvdbOZ+s8M\nJdy0Z/ic+QHD8m2xrDxOu7B+b415x3V9L1ExLc2uMuXSqNVOUlS5H4EolKxHKkd+\nR8W5G4E5OxTE81DIvT74Gp6FAcQJLUXYTsHg5P0ghQ0JkypGMuoy\n-----END CERTIFICATE-----\n@@@@@@@@-----BEGIN RSA PRIVATE KEY-----\nMIICXgIBAAKBgQC7z0uYxdmSsKot0Fos5mA+5IONC6kMPUPjo6H0h9sHVeJW3tWo\njv3+Wi3hSQq6JoywvgcFBlkAzpRye5rRhksyHvMDZqhhaRCclLEBUnVwbiFIqHby\nqulkkC6u2abJ0UoTw4NmQhuDr7mTNZm1Li5sFjdT6us7CaMipck4AocvuQIDAQAB\nAoGBALEQ85kJj+O5I/klop8KZFtnXo+wGqUrbcJFGABPxbTYyBhW5uGQTu9rXi40\niySOC77mqf+WyHr2SQbWelRoZKMwcQtRZCXJHFgGGU/MCgvEBWKuwxO1zAoRcEGW\nJ6zZiZDn7DcL9NMgnds2NkEbIXuginUWGFuML/Z5S4BGD2TxAkEA9VOSYz9llw9d\n9mDCcYp6emgKtsxpFBlrYkQUTnExEWln8Png//onCCmJzvwQr8A08YcuFY6+QHOe\n8jccxYynMwJBAMP7G0npuX2j99votR6xjardZIIfuuO6UDJuYMcQqPgh28LnhpVc\nBFDIjPjU3a5McffmVYcU/E+xRLg4MUYHXWMCQQCpdOm4HnF478dyyRFmxkWlybok\n3Ht0w742KVpxeKRxJ4MBpEjz6AIQFEk5rUmFbNnlP//oKipmcLcJDmKUXnybAkAm\nw61zIkLpYhxtqArjRlVyPZZa0rHhx4GDaCfGWDpD0laop6kMNAY6gGC5+0jZ6A8G\n7M1wCauai8K++YZthplnAkEA0g+iTJINnHotFaDhkfPXNXXUQHclWsb0Hl5v7jh6\nhODplXthll5GScTuD6WrJbz6fcamSZjHeRg9jQ48l+AtWA==\n-----END RSA PRIVATE KEY-----\n');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_context`
--

CREATE TABLE IF NOT EXISTS `mdl_context` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `contextlevel` bigint(10) unsigned NOT NULL DEFAULT '0',
  `instanceid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) DEFAULT NULL,
  `depth` tinyint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_cont_conins_uix` (`contextlevel`,`instanceid`),
  KEY `mdl_cont_ins_ix` (`instanceid`),
  KEY `mdl_cont_pat_ix` (`path`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='one of these must be set' AUTO_INCREMENT=111 ;

--
-- Dumping data for table `mdl_context`
--

INSERT INTO `mdl_context` (`id`, `contextlevel`, `instanceid`, `path`, `depth`) VALUES
(1, 10, 0, '/1', 1),
(2, 50, 1, '/1/2', 2),
(3, 40, 1, '/1/3', 2),
(4, 80, 1, '/1/2/4', 3),
(5, 80, 2, '/1/2/5', 3),
(6, 80, 3, '/1/2/6', 3),
(7, 80, 4, '/1/2/7', 3),
(8, 50, 2, '/1/31/8', 3),
(9, 80, 7, '/1/31/8/9', 4),
(10, 80, 8, '/1/31/8/10', 4),
(11, 80, 9, '/1/31/8/11', 4),
(12, 80, 10, '/1/31/8/12', 4),
(13, 80, 11, '/1/31/8/13', 4),
(14, 80, 12, '/1/31/8/14', 4),
(15, 70, 1, '/1/31/8/15', 4),
(16, 80, 13, '/1/31/8/16', 4),
(17, 80, 14, '/1/31/8/17', 4),
(18, 80, 5, '/1/18', 2),
(19, 80, 6, '/1/19', 2),
(20, 50, 3, '/1/3/20', 3),
(21, 80, 15, '/1/3/20/21', 4),
(22, 80, 16, '/1/3/20/22', 4),
(23, 80, 17, '/1/3/20/23', 4),
(24, 80, 18, '/1/3/20/24', 4),
(25, 80, 19, '/1/3/20/25', 4),
(26, 80, 20, '/1/3/20/26', 4),
(27, 70, 2, '/1/3/20/27', 4),
(28, 80, 21, '/1/3/20/28', 4),
(29, 80, 22, '/1/3/20/29', 4),
(30, 70, 3, '/1/2/30', 3),
(31, 40, 2, '/1/31', 2),
(32, 50, 4, '/1/31/32', 3),
(33, 80, 23, '/1/31/32/33', 4),
(34, 80, 24, '/1/31/32/34', 4),
(35, 80, 25, '/1/31/32/35', 4),
(36, 80, 26, '/1/31/32/36', 4),
(37, 80, 27, '/1/31/32/37', 4),
(38, 80, 28, '/1/31/32/38', 4),
(39, 70, 4, '/1/31/32/39', 4),
(40, 80, 29, '/1/31/32/40', 4),
(41, 80, 30, '/1/31/32/41', 4),
(42, 50, 5, '/1/31/42', 3),
(43, 50, 6, '/1/31/43', 3),
(44, 40, 3, '/1/44', 2),
(45, 50, 7, '/1/44/45', 3),
(46, 80, 47, '/1/44/45/46', 4),
(47, 80, 48, '/1/44/45/47', 4),
(48, 80, 49, '/1/44/45/48', 4),
(49, 80, 50, '/1/44/45/49', 4),
(50, 80, 51, '/1/44/45/50', 4),
(51, 80, 52, '/1/44/45/51', 4),
(52, 70, 5, '/1/44/45/52', 4),
(53, 80, 53, '/1/44/45/53', 4),
(54, 80, 54, '/1/44/45/54', 4),
(55, 50, 8, '/1/44/55', 3),
(56, 50, 9, '/1/44/56', 3),
(57, 50, 10, '/1/44/57', 3),
(58, 80, 39, '/1/31/43/58', 4),
(59, 80, 40, '/1/31/43/59', 4),
(60, 80, 41, '/1/31/43/60', 4),
(61, 80, 42, '/1/31/43/61', 4),
(62, 80, 43, '/1/31/43/62', 4),
(63, 80, 44, '/1/31/43/63', 4),
(64, 70, 6, '/1/31/43/64', 4),
(65, 80, 45, '/1/31/43/65', 4),
(66, 80, 46, '/1/31/43/66', 4),
(67, 80, 31, '/1/31/42/67', 4),
(68, 80, 32, '/1/31/42/68', 4),
(69, 80, 33, '/1/31/42/69', 4),
(70, 80, 34, '/1/31/42/70', 4),
(71, 80, 35, '/1/31/42/71', 4),
(72, 80, 36, '/1/31/42/72', 4),
(73, 70, 7, '/1/31/42/73', 4),
(74, 80, 37, '/1/31/42/74', 4),
(75, 80, 38, '/1/31/42/75', 4),
(76, 80, 71, '/1/44/57/76', 4),
(77, 80, 72, '/1/44/57/77', 4),
(78, 80, 73, '/1/44/57/78', 4),
(79, 80, 74, '/1/44/57/79', 4),
(80, 80, 75, '/1/44/57/80', 4),
(81, 80, 76, '/1/44/57/81', 4),
(82, 70, 8, '/1/44/57/82', 4),
(83, 80, 77, '/1/44/57/83', 4),
(84, 80, 78, '/1/44/57/84', 4),
(85, 80, 63, '/1/44/56/85', 4),
(86, 80, 64, '/1/44/56/86', 4),
(87, 80, 65, '/1/44/56/87', 4),
(88, 80, 66, '/1/44/56/88', 4),
(89, 80, 67, '/1/44/56/89', 4),
(90, 80, 68, '/1/44/56/90', 4),
(91, 70, 9, '/1/44/56/91', 4),
(92, 80, 69, '/1/44/56/92', 4),
(93, 80, 70, '/1/44/56/93', 4),
(94, 80, 55, '/1/44/55/94', 4),
(95, 80, 56, '/1/44/55/95', 4),
(96, 80, 57, '/1/44/55/96', 4),
(97, 80, 58, '/1/44/55/97', 4),
(98, 80, 59, '/1/44/55/98', 4),
(99, 80, 60, '/1/44/55/99', 4),
(100, 70, 10, '/1/44/55/100', 4),
(101, 80, 61, '/1/44/55/101', 4),
(102, 80, 62, '/1/44/55/102', 4),
(103, 30, 1, '/1/103', 2),
(104, 30, 2, '/1/104', 2),
(105, 70, 11, '/1/31/43/105', 4),
(106, 70, 12, '/1/3/20/106', 4),
(107, 50, 11, '/1/31/107', 3),
(108, 50, 12, '/1/31/108', 3),
(109, 70, 13, '/1/31/8/109', 4),
(110, 70, 14, '/1/31/8/110', 4);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_context_temp`
--

CREATE TABLE IF NOT EXISTS `mdl_context_temp` (
  `id` bigint(10) unsigned NOT NULL,
  `path` varchar(255) NOT NULL DEFAULT '',
  `depth` tinyint(2) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Used by build_context_path() in upgrade and cron to keep con';

--
-- Dumping data for table `mdl_context_temp`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_course`
--

CREATE TABLE IF NOT EXISTS `mdl_course` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` bigint(10) unsigned NOT NULL DEFAULT '0',
  `sortorder` bigint(10) unsigned NOT NULL DEFAULT '0',
  `password` varchar(50) NOT NULL DEFAULT '',
  `fullname` varchar(254) NOT NULL DEFAULT '',
  `shortname` varchar(100) NOT NULL DEFAULT '',
  `idnumber` varchar(100) NOT NULL DEFAULT '',
  `summary` text,
  `format` varchar(10) NOT NULL DEFAULT 'topics',
  `showgrades` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `modinfo` longtext,
  `newsitems` mediumint(5) unsigned NOT NULL DEFAULT '1',
  `teacher` varchar(100) NOT NULL DEFAULT 'Teacher',
  `teachers` varchar(100) NOT NULL DEFAULT 'Teachers',
  `student` varchar(100) NOT NULL DEFAULT 'Student',
  `students` varchar(100) NOT NULL DEFAULT 'Students',
  `guest` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `startdate` bigint(10) unsigned NOT NULL DEFAULT '0',
  `enrolperiod` bigint(10) unsigned NOT NULL DEFAULT '0',
  `numsections` mediumint(5) unsigned NOT NULL DEFAULT '1',
  `marker` bigint(10) unsigned NOT NULL DEFAULT '0',
  `maxbytes` bigint(10) unsigned NOT NULL DEFAULT '0',
  `showreports` smallint(4) unsigned NOT NULL DEFAULT '0',
  `visible` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `hiddensections` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `groupmode` smallint(4) unsigned NOT NULL DEFAULT '0',
  `groupmodeforce` smallint(4) unsigned NOT NULL DEFAULT '0',
  `defaultgroupingid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lang` varchar(30) NOT NULL DEFAULT '',
  `theme` varchar(50) NOT NULL DEFAULT '',
  `groupyear` varchar(30) NOT NULL DEFAULT '',
  `cost` varchar(10) NOT NULL DEFAULT '',
  `currency` varchar(3) NOT NULL DEFAULT 'USD',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `metacourse` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `requested` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `restrictmodules` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `expirynotify` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `expirythreshold` bigint(10) unsigned NOT NULL DEFAULT '0',
  `notifystudents` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `enrollable` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `enrolstartdate` bigint(10) unsigned NOT NULL DEFAULT '0',
  `enrolenddate` bigint(10) unsigned NOT NULL DEFAULT '0',
  `enrol` varchar(20) NOT NULL DEFAULT '',
  `defaultrole` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_cour_cat_ix` (`category`),
  KEY `mdl_cour_idn_ix` (`idnumber`),
  KEY `mdl_cour_sho_ix` (`shortname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Central course table' AUTO_INCREMENT=13 ;

--
-- Dumping data for table `mdl_course`
--

INSERT INTO `mdl_course` (`id`, `category`, `sortorder`, `password`, `fullname`, `shortname`, `idnumber`, `summary`, `format`, `showgrades`, `modinfo`, `newsitems`, `teacher`, `teachers`, `student`, `students`, `guest`, `startdate`, `enrolperiod`, `numsections`, `marker`, `maxbytes`, `showreports`, `visible`, `hiddensections`, `groupmode`, `groupmodeforce`, `defaultgroupingid`, `lang`, `theme`, `groupyear`, `cost`, `currency`, `timecreated`, `timemodified`, `metacourse`, `requested`, `restrictmodules`, `expirynotify`, `expirythreshold`, `notifystudents`, `enrollable`, `enrolstartdate`, `enrolenddate`, `enrol`, `defaultrole`) VALUES
(1, 0, 0, '', 'Jeelo Launcher', 'jeelo_launcher', '', '', 'site', 1, 'a:1:{i:3;O:8:"stdClass":10:{s:2:"id";s:1:"1";s:2:"cm";i:3;s:3:"mod";s:8:"launcher";s:7:"section";s:1:"0";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:8:"Launcher";}}', 3, 'Teacher', 'Teachers', 'Student', 'Students', 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '', '', '', '', 'USD', 0, 1323877281, 0, 0, 0, 0, 0, 0, 1, 0, 0, '', 0),
(2, 2, 100, '', 'Jaar 1/2 - Samen spelen', 'CF101', '', ' Jaar 1/2 - Samen spelen', 'weeks', 1, 'a:3:{i:1;O:8:"stdClass":10:{s:2:"id";s:1:"1";s:2:"cm";i:1;s:3:"mod";s:5:"forum";s:7:"section";s:1:"0";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:10:"News+forum";}i:13;O:8:"stdClass":10:{s:2:"id";s:1:"1";s:2:"cm";i:13;s:3:"mod";s:4:"chat";s:7:"section";s:1:"1";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:9:"Test+chat";}i:14;O:8:"stdClass":10:{s:2:"id";s:1:"2";s:2:"cm";i:14;s:3:"mod";s:6:"choice";s:7:"section";s:1:"1";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:11:"Test+choice";}}', 5, 'Teacher', 'Teachers', 'Student', 'Students', 0, 1325026800, 0, 10, 0, 2097152, 0, 1, 0, 0, 0, 0, '', '', '1/2', '', 'USD', 1324980904, 1325682205, 0, 0, 0, 0, 864000, 0, 1, 0, 0, '', 0),
(3, 1, 99, '', 'Course Fullname 102', 'CF102', '', 'Test Course 2 ', 'weeks', 1, 'a:2:{i:2;O:8:"stdClass":10:{s:2:"id";s:1:"2";s:2:"cm";i:2;s:3:"mod";s:5:"forum";s:7:"section";s:1:"0";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:10:"News+forum";}i:12;O:8:"stdClass":10:{s:2:"id";s:1:"1";s:2:"cm";i:12;s:3:"mod";s:6:"choice";s:7:"section";s:1:"1";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:11:"test+choice";}}', 5, 'Teacher', 'Teachers', 'Student', 'Students', 0, 1325026800, 0, 10, 0, 2097152, 0, 1, 0, 0, 0, 0, '', '', '', '', 'USD', 1324980934, 1324980934, 0, 0, 0, 0, 864000, 0, 1, 0, 0, '', 0),
(4, 2, 99, '', 'Jaar 3/4 - Leven in een gezin', 'CF103', '', '', 'weeks', 1, 'a:1:{i:4;O:8:"stdClass":10:{s:2:"id";s:1:"3";s:2:"cm";i:4;s:3:"mod";s:5:"forum";s:7:"section";s:1:"0";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:10:"News+forum";}}', 5, 'Teacher', 'Teachers', 'Student', 'Students', 0, 1325631600, 0, 10, 0, 2097152, 0, 1, 0, 0, 0, 0, '', '', '3/4', '', 'USD', 1325605060, 1325682195, 0, 0, 0, 0, 864000, 0, 1, 0, 0, '', 0),
(5, 2, 98, '', 'Jaar 5/6 - Vrienden in een groep', 'CF104', '', '', 'weeks', 1, 'a:1:{i:7;O:8:"stdClass":10:{s:2:"id";s:1:"6";s:2:"cm";i:7;s:3:"mod";s:5:"forum";s:7:"section";s:1:"0";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:10:"News+forum";}}', 5, 'Teacher', 'Teachers', 'Student', 'Students', 0, 1325631600, 0, 10, 0, 2097152, 0, 1, 0, 0, 0, 0, '', '', '5/6', '', 'USD', 1325605111, 1325682183, 0, 0, 0, 0, 864000, 0, 1, 0, 0, '', 0),
(6, 2, 97, '', 'Jaar 7/8 - Waarderen van verschillen', 'CF105', '', '', 'weeks', 1, 'a:2:{i:6;O:8:"stdClass":10:{s:2:"id";s:1:"5";s:2:"cm";i:6;s:3:"mod";s:5:"forum";s:7:"section";s:1:"0";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:10:"News+forum";}i:11;O:8:"stdClass":10:{s:2:"id";s:1:"1";s:2:"cm";i:11;s:3:"mod";s:10:"assignment";s:7:"section";s:1:"1";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:13:"Test+activity";}}', 5, 'Teacher', 'Teachers', 'Student', 'Students', 0, 1325631600, 0, 10, 0, 2097152, 0, 1, 0, 0, 0, 0, '', '', '7/8', '', 'USD', 1325605140, 1325682169, 0, 0, 0, 0, 864000, 0, 1, 0, 0, '', 0),
(7, 3, 100, '', 'Jaar 1/2 - Wonen in je straat', 'CF106', '', '', 'weeks', 1, 'a:1:{i:5;O:8:"stdClass":10:{s:2:"id";s:1:"4";s:2:"cm";i:5;s:3:"mod";s:5:"forum";s:7:"section";s:1:"0";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:10:"News+forum";}}', 5, 'Teacher', 'Teachers', 'Student', 'Students', 0, 1325631600, 0, 10, 0, 2097152, 0, 1, 0, 0, 0, 0, '', '', '1/2', '', 'USD', 1325605204, 1325682246, 0, 0, 0, 0, 864000, 0, 1, 0, 0, '', 0),
(8, 3, 99, '', 'Jaar 3/4 - Zorg voor je wijk', 'CF107', '', '', 'weeks', 1, 'a:1:{i:10;O:8:"stdClass":10:{s:2:"id";s:1:"9";s:2:"cm";i:10;s:3:"mod";s:5:"forum";s:7:"section";s:1:"0";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:10:"News+forum";}}', 5, 'Teacher', 'Teachers', 'Student', 'Students', 0, 1325631600, 0, 10, 0, 2097152, 0, 1, 0, 0, 0, 0, '', '', '3/4', '', 'USD', 1325605237, 1325682238, 0, 0, 0, 0, 864000, 0, 1, 0, 0, '', 0),
(9, 3, 98, '', 'Jaar 5/6 - Vrije tijd in je stad of dorp', 'CF108', '', '', 'weeks', 1, 'a:1:{i:9;O:8:"stdClass":10:{s:2:"id";s:1:"8";s:2:"cm";i:9;s:3:"mod";s:5:"forum";s:7:"section";s:1:"0";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:10:"News+forum";}}', 5, 'Teacher', 'Teachers', 'Student', 'Students', 0, 1325631600, 0, 10, 0, 2097152, 0, 1, 0, 0, 0, 0, '', '', '5/6', '', 'USD', 1325605257, 1325682231, 0, 0, 0, 0, 864000, 0, 1, 0, 0, '', 0),
(10, 3, 97, '', 'Jaar 7/8 - Ontwikkelen van je gemeente', 'CF109', '', '', 'weeks', 1, 'a:1:{i:8;O:8:"stdClass":10:{s:2:"id";s:1:"7";s:2:"cm";i:8;s:3:"mod";s:5:"forum";s:7:"section";s:1:"0";s:7:"visible";s:1:"1";s:9:"groupmode";s:1:"0";s:10:"groupingid";s:1:"0";s:16:"groupmembersonly";s:1:"0";s:5:"extra";s:0:"";s:4:"name";s:10:"News+forum";}}', 5, 'Teacher', 'Teachers', 'Student', 'Students', 0, 1325631600, 0, 10, 0, 2097152, 0, 1, 0, 0, 0, 0, '', '', '7/8', '', 'USD', 1325605275, 1325682222, 0, 0, 0, 0, 864000, 0, 1, 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_course_allowed_modules`
--

CREATE TABLE IF NOT EXISTS `mdl_course_allowed_modules` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `module` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_courallomodu_cou_ix` (`course`),
  KEY `mdl_courallomodu_mod_ix` (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='allowed modules foreach course' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_course_allowed_modules`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_course_categories`
--

CREATE TABLE IF NOT EXISTS `mdl_course_categories` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `parent` bigint(10) unsigned NOT NULL DEFAULT '0',
  `sortorder` bigint(10) unsigned NOT NULL DEFAULT '0',
  `coursecount` bigint(10) unsigned NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `depth` bigint(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `theme` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_courcate_par_ix` (`parent`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Course categories' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mdl_course_categories`
--

INSERT INTO `mdl_course_categories` (`id`, `name`, `description`, `parent`, `sortorder`, `coursecount`, `visible`, `timemodified`, `depth`, `path`, `theme`) VALUES
(1, 'Miscellaneous', '', 0, 0, 1, 1, 0, 1, '/1', NULL),
(2, 'Project 1 - Omgaan met elkaar', ' Project 1 - Test project<br />', 0, 999, 4, 1, 0, 1, '/2', NULL),
(3, 'Project 2 - Inrichten van je eigen omgeving', '', 0, 999, 4, 1, 0, 1, '/3', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_course_display`
--

CREATE TABLE IF NOT EXISTS `mdl_course_display` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `display` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_courdisp_couuse_ix` (`course`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Stores info about how to display the course' AUTO_INCREMENT=10 ;

--
-- Dumping data for table `mdl_course_display`
--

INSERT INTO `mdl_course_display` (`id`, `course`, `userid`, `display`) VALUES
(1, 2, 2, 0),
(2, 3, 2, 0),
(3, 4, 2, 0),
(4, 7, 2, 0),
(5, 6, 2, 0),
(6, 5, 2, 0),
(7, 10, 2, 0),
(8, 9, 2, 0),
(9, 8, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_course_meta`
--

CREATE TABLE IF NOT EXISTS `mdl_course_meta` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `child_course` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_courmeta_par_ix` (`parent_course`),
  KEY `mdl_courmeta_chi_ix` (`child_course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to store meta-courses relations' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_course_meta`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_course_modules`
--

CREATE TABLE IF NOT EXISTS `mdl_course_modules` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `module` bigint(10) unsigned NOT NULL DEFAULT '0',
  `instance` bigint(10) unsigned NOT NULL DEFAULT '0',
  `section` bigint(10) unsigned NOT NULL DEFAULT '0',
  `idnumber` varchar(100) DEFAULT NULL,
  `added` bigint(10) unsigned NOT NULL DEFAULT '0',
  `score` smallint(4) NOT NULL DEFAULT '0',
  `indent` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `visibleold` tinyint(1) NOT NULL DEFAULT '1',
  `groupmode` smallint(4) NOT NULL DEFAULT '0',
  `groupingid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `groupmembersonly` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_courmodu_vis_ix` (`visible`),
  KEY `mdl_courmodu_cou_ix` (`course`),
  KEY `mdl_courmodu_mod_ix` (`module`),
  KEY `mdl_courmodu_ins_ix` (`instance`),
  KEY `mdl_courmodu_idncou_ix` (`idnumber`,`course`),
  KEY `mdl_courmodu_gro_ix` (`groupingid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='course_modules table retrofitted from MySQL' AUTO_INCREMENT=15 ;

--
-- Dumping data for table `mdl_course_modules`
--

INSERT INTO `mdl_course_modules` (`id`, `course`, `module`, `instance`, `section`, `idnumber`, `added`, `score`, `indent`, `visible`, `visibleold`, `groupmode`, `groupingid`, `groupmembersonly`) VALUES
(1, 2, 5, 1, 1, NULL, 1324980908, 0, 0, 1, 1, 0, 0, 0),
(2, 3, 5, 2, 12, NULL, 1324980936, 0, 0, 1, 1, 0, 0, 0),
(3, 1, 19, 1, 23, '', 1324983194, 0, 0, 1, 1, 0, 0, 0),
(4, 4, 5, 3, 24, NULL, 1325605079, 0, 0, 1, 1, 0, 0, 0),
(5, 7, 5, 4, 37, NULL, 1325605208, 0, 0, 1, 1, 0, 0, 0),
(6, 6, 5, 5, 36, NULL, 1325682169, 0, 0, 1, 1, 0, 0, 0),
(7, 5, 5, 6, 35, NULL, 1325682183, 0, 0, 1, 1, 0, 0, 0),
(8, 10, 5, 7, 50, NULL, 1325682222, 0, 0, 1, 1, 0, 0, 0),
(9, 9, 5, 8, 49, NULL, 1325682231, 0, 0, 1, 1, 0, 0, 0),
(10, 8, 5, 9, 48, NULL, 1325682239, 0, 0, 1, 1, 0, 0, 0),
(11, 6, 1, 1, 51, '', 1326115093, 0, 0, 1, 1, 0, 0, 0),
(12, 3, 3, 1, 13, '', 1326975312, 0, 0, 1, 1, 0, 0, 0),
(13, 2, 2, 1, 2, '', 1329316389, 0, 0, 1, 1, 0, 0, 0),
(14, 2, 3, 2, 2, '', 1329316463, 0, 0, 1, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_course_request`
--

CREATE TABLE IF NOT EXISTS `mdl_course_request` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(254) NOT NULL DEFAULT '',
  `shortname` varchar(15) NOT NULL DEFAULT '',
  `summary` text NOT NULL,
  `reason` text NOT NULL,
  `requester` bigint(10) unsigned NOT NULL DEFAULT '0',
  `password` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_courrequ_sho_ix` (`shortname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='course requests' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_course_request`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_course_sections`
--

CREATE TABLE IF NOT EXISTS `mdl_course_sections` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `section` bigint(10) unsigned NOT NULL DEFAULT '0',
  `summary` text,
  `sequence` text,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `mdl_coursect_cousec_ix` (`course`,`section`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='to define the sections for each course' AUTO_INCREMENT=123 ;

--
-- Dumping data for table `mdl_course_sections`
--

INSERT INTO `mdl_course_sections` (`id`, `course`, `section`, `summary`, `sequence`, `visible`) VALUES
(1, 2, 0, NULL, '1', 1),
(2, 2, 1, '', '13,14', 1),
(3, 2, 2, '', NULL, 1),
(4, 2, 3, '', NULL, 1),
(5, 2, 4, '', NULL, 1),
(6, 2, 5, '', NULL, 1),
(7, 2, 6, '', NULL, 1),
(8, 2, 7, '', NULL, 1),
(9, 2, 8, '', NULL, 1),
(10, 2, 9, '', NULL, 1),
(11, 2, 10, '', NULL, 1),
(12, 3, 0, NULL, '2', 1),
(13, 3, 1, 'blabla ', '12', 1),
(14, 3, 2, '', NULL, 1),
(15, 3, 3, '', NULL, 1),
(16, 3, 4, '', NULL, 1),
(17, 3, 5, '', NULL, 1),
(18, 3, 6, '', NULL, 1),
(19, 3, 7, '', NULL, 1),
(20, 3, 8, '', NULL, 1),
(21, 3, 9, '', NULL, 1),
(22, 3, 10, '', NULL, 1),
(23, 1, 0, '', '3', 1),
(24, 4, 0, NULL, '4', 1),
(25, 4, 1, '', NULL, 1),
(26, 4, 2, '', NULL, 1),
(27, 4, 3, '', NULL, 1),
(28, 4, 4, '', NULL, 1),
(29, 4, 5, '', NULL, 1),
(30, 4, 6, '', NULL, 1),
(31, 4, 7, '', NULL, 1),
(32, 4, 8, '', NULL, 1),
(33, 4, 9, '', NULL, 1),
(34, 4, 10, '', NULL, 1),
(35, 5, 0, NULL, '7', 1),
(36, 6, 0, NULL, '6', 1),
(37, 7, 0, NULL, '5', 1),
(38, 7, 1, '', NULL, 1),
(39, 7, 2, '', NULL, 1),
(40, 7, 3, '', NULL, 1),
(41, 7, 4, '', NULL, 1),
(42, 7, 5, '', NULL, 1),
(43, 7, 6, '', NULL, 1),
(44, 7, 7, '', NULL, 1),
(45, 7, 8, '', NULL, 1),
(46, 7, 9, '', NULL, 1),
(47, 7, 10, '', NULL, 1),
(48, 8, 0, NULL, '10', 1),
(49, 9, 0, NULL, '9', 1),
(50, 10, 0, NULL, '8', 1),
(51, 6, 1, '', '11', 1),
(52, 6, 2, '', NULL, 1),
(53, 6, 3, '', NULL, 1),
(54, 6, 4, '', NULL, 1),
(55, 6, 5, '', NULL, 1),
(56, 6, 6, '', NULL, 1),
(57, 6, 7, '', NULL, 1),
(58, 6, 8, '', NULL, 1),
(59, 6, 9, '', NULL, 1),
(60, 6, 10, '', NULL, 1),
(61, 5, 1, '', NULL, 1),
(62, 5, 2, '', NULL, 1),
(63, 5, 3, '', NULL, 1),
(64, 5, 4, '', NULL, 1),
(65, 5, 5, '', NULL, 1),
(66, 5, 6, '', NULL, 1),
(67, 5, 7, '', NULL, 1),
(68, 5, 8, '', NULL, 1),
(69, 5, 9, '', NULL, 1),
(70, 5, 10, '', NULL, 1),
(71, 10, 1, '', NULL, 1),
(72, 10, 2, '', NULL, 1),
(73, 10, 3, '', NULL, 1),
(74, 10, 4, '', NULL, 1),
(75, 10, 5, '', NULL, 1),
(76, 10, 6, '', NULL, 1),
(77, 10, 7, '', NULL, 1),
(78, 10, 8, '', NULL, 1),
(79, 10, 9, '', NULL, 1),
(80, 10, 10, '', NULL, 1),
(81, 9, 1, '', NULL, 1),
(82, 9, 2, '', NULL, 1),
(83, 9, 3, '', NULL, 1),
(84, 9, 4, '', NULL, 1),
(85, 9, 5, '', NULL, 1),
(86, 9, 6, '', NULL, 1),
(87, 9, 7, '', NULL, 1),
(88, 9, 8, '', NULL, 1),
(89, 9, 9, '', NULL, 1),
(90, 9, 10, '', NULL, 1),
(91, 8, 1, '', NULL, 1),
(92, 8, 2, '', NULL, 1),
(93, 8, 3, '', NULL, 1),
(94, 8, 4, '', NULL, 1),
(95, 8, 5, '', NULL, 1),
(96, 8, 6, '', NULL, 1),
(97, 8, 7, '', NULL, 1),
(98, 8, 8, '', NULL, 1),
(99, 8, 9, '', NULL, 1),
(100, 8, 10, '', NULL, 1),
(101, 11, 0, NULL, '', 1),
(102, 11, 1, '', '', 1),
(103, 11, 2, '', '', 1),
(104, 11, 3, '', '', 1),
(105, 11, 4, '', '', 1),
(106, 11, 5, '', '', 1),
(107, 11, 6, '', '', 1),
(108, 11, 7, '', '', 1),
(109, 11, 8, '', '', 1),
(110, 11, 9, '', '', 1),
(111, 11, 10, '', '', 1),
(112, 12, 0, NULL, '', 1),
(113, 12, 1, '', '', 1),
(114, 12, 2, '', '', 1),
(115, 12, 3, '', '', 1),
(116, 12, 4, '', '', 1),
(117, 12, 5, '', '', 1),
(118, 12, 6, '', '', 1),
(119, 12, 7, '', '', 1),
(120, 12, 8, '', '', 1),
(121, 12, 9, '', '', 1),
(122, 12, 10, '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_data`
--

CREATE TABLE IF NOT EXISTS `mdl_data` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `intro` text NOT NULL,
  `comments` smallint(4) unsigned NOT NULL DEFAULT '0',
  `timeavailablefrom` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeavailableto` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeviewfrom` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeviewto` bigint(10) unsigned NOT NULL DEFAULT '0',
  `requiredentries` int(8) unsigned NOT NULL DEFAULT '0',
  `requiredentriestoview` int(8) unsigned NOT NULL DEFAULT '0',
  `maxentries` int(8) unsigned NOT NULL DEFAULT '0',
  `rssarticles` smallint(4) unsigned NOT NULL DEFAULT '0',
  `singletemplate` text,
  `listtemplate` text,
  `listtemplateheader` text,
  `listtemplatefooter` text,
  `addtemplate` text,
  `rsstemplate` text,
  `rsstitletemplate` text,
  `csstemplate` text,
  `jstemplate` text,
  `asearchtemplate` text,
  `approval` smallint(4) unsigned NOT NULL DEFAULT '0',
  `scale` bigint(10) NOT NULL DEFAULT '0',
  `assessed` bigint(10) unsigned NOT NULL DEFAULT '0',
  `defaultsort` bigint(10) unsigned NOT NULL DEFAULT '0',
  `defaultsortdir` smallint(4) unsigned NOT NULL DEFAULT '0',
  `editany` smallint(4) unsigned NOT NULL DEFAULT '0',
  `notification` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_data_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='all database activities' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_data_comments`
--

CREATE TABLE IF NOT EXISTS `mdl_data_comments` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `recordid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `format` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `created` bigint(10) unsigned NOT NULL DEFAULT '0',
  `modified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_datacomm_rec_ix` (`recordid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to comment data records' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_data_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_data_content`
--

CREATE TABLE IF NOT EXISTS `mdl_data_content` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `fieldid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `recordid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `content` longtext,
  `content1` longtext,
  `content2` longtext,
  `content3` longtext,
  `content4` longtext,
  PRIMARY KEY (`id`),
  KEY `mdl_datacont_rec_ix` (`recordid`),
  KEY `mdl_datacont_fie_ix` (`fieldid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='the content introduced in each record/fields' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_data_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_data_fields`
--

CREATE TABLE IF NOT EXISTS `mdl_data_fields` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `dataid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `param1` text,
  `param2` text,
  `param3` text,
  `param4` text,
  `param5` text,
  `param6` text,
  `param7` text,
  `param8` text,
  `param9` text,
  `param10` text,
  PRIMARY KEY (`id`),
  KEY `mdl_datafiel_typdat_ix` (`type`,`dataid`),
  KEY `mdl_datafiel_dat_ix` (`dataid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='every field available' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_data_fields`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_data_ratings`
--

CREATE TABLE IF NOT EXISTS `mdl_data_ratings` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `recordid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `rating` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_datarati_rec_ix` (`recordid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to rate data records' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_data_ratings`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_data_records`
--

CREATE TABLE IF NOT EXISTS `mdl_data_records` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `groupid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `dataid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `approved` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_datareco_dat_ix` (`dataid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='every record introduced' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_data_records`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_enrol_authorize`
--

CREATE TABLE IF NOT EXISTS `mdl_enrol_authorize` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `paymentmethod` enum('cc','echeck') NOT NULL DEFAULT 'cc',
  `refundinfo` smallint(4) unsigned NOT NULL DEFAULT '0',
  `ccname` varchar(255) NOT NULL DEFAULT '',
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `transid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `status` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `settletime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `amount` varchar(10) NOT NULL DEFAULT '',
  `currency` varchar(3) NOT NULL DEFAULT 'USD',
  PRIMARY KEY (`id`),
  KEY `mdl_enroauth_cou_ix` (`courseid`),
  KEY `mdl_enroauth_use_ix` (`userid`),
  KEY `mdl_enroauth_sta_ix` (`status`),
  KEY `mdl_enroauth_tra_ix` (`transid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Holds all known information about authorize.net transactions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_enrol_authorize`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_enrol_authorize_refunds`
--

CREATE TABLE IF NOT EXISTS `mdl_enrol_authorize_refunds` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `orderid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `amount` varchar(10) NOT NULL DEFAULT '',
  `transid` bigint(20) unsigned DEFAULT '0',
  `settletime` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_enroauthrefu_tra_ix` (`transid`),
  KEY `mdl_enroauthrefu_ord_ix` (`orderid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Authorize.net refunds' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_enrol_authorize_refunds`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_enrol_paypal`
--

CREATE TABLE IF NOT EXISTS `mdl_enrol_paypal` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `business` varchar(255) NOT NULL DEFAULT '',
  `receiver_email` varchar(255) NOT NULL DEFAULT '',
  `receiver_id` varchar(255) NOT NULL DEFAULT '',
  `item_name` varchar(255) NOT NULL DEFAULT '',
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `memo` varchar(255) NOT NULL DEFAULT '',
  `tax` varchar(255) NOT NULL DEFAULT '',
  `option_name1` varchar(255) NOT NULL DEFAULT '',
  `option_selection1_x` varchar(255) NOT NULL DEFAULT '',
  `option_name2` varchar(255) NOT NULL DEFAULT '',
  `option_selection2_x` varchar(255) NOT NULL DEFAULT '',
  `payment_status` varchar(255) NOT NULL DEFAULT '',
  `pending_reason` varchar(255) NOT NULL DEFAULT '',
  `reason_code` varchar(30) NOT NULL DEFAULT '',
  `txn_id` varchar(255) NOT NULL DEFAULT '',
  `parent_txn_id` varchar(255) NOT NULL DEFAULT '',
  `payment_type` varchar(30) NOT NULL DEFAULT '',
  `timeupdated` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Holds all known information about PayPal transactions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_enrol_paypal`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_event`
--

CREATE TABLE IF NOT EXISTS `mdl_event` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `format` smallint(4) unsigned NOT NULL DEFAULT '0',
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `groupid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `repeatid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `modulename` varchar(20) NOT NULL DEFAULT '',
  `instance` bigint(10) unsigned NOT NULL DEFAULT '0',
  `eventtype` varchar(20) NOT NULL DEFAULT '',
  `timestart` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeduration` bigint(10) unsigned NOT NULL DEFAULT '0',
  `visible` smallint(4) NOT NULL DEFAULT '1',
  `uuid` varchar(36) NOT NULL DEFAULT '',
  `sequence` bigint(10) unsigned NOT NULL DEFAULT '1',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_even_cou_ix` (`courseid`),
  KEY `mdl_even_use_ix` (`userid`),
  KEY `mdl_even_tim_ix` (`timestart`),
  KEY `mdl_even_tim2_ix` (`timeduration`),
  KEY `mdl_even_grocouvisuse_ix` (`groupid`,`courseid`,`visible`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='For everything with a time associated to it' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mdl_event`
--

INSERT INTO `mdl_event` (`id`, `name`, `description`, `format`, `courseid`, `groupid`, `userid`, `repeatid`, `modulename`, `instance`, `eventtype`, `timestart`, `timeduration`, `visible`, `uuid`, `sequence`, `timemodified`) VALUES
(2, 'Test chat', 'Test chat<br /> ', 0, 2, 0, 0, 0, 'chat', 1, '0', 1329316200, 0, 1, '', 1, 1329316389);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_events_handlers`
--

CREATE TABLE IF NOT EXISTS `mdl_events_handlers` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `eventname` varchar(166) NOT NULL DEFAULT '',
  `handlermodule` varchar(166) NOT NULL DEFAULT '',
  `handlerfile` varchar(255) NOT NULL DEFAULT '',
  `handlerfunction` mediumtext,
  `schedule` varchar(255) DEFAULT NULL,
  `status` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_evenhand_evehan_uix` (`eventname`,`handlermodule`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='This table is for storing which components requests what typ' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_events_handlers`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_events_queue`
--

CREATE TABLE IF NOT EXISTS `mdl_events_queue` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `eventdata` longtext NOT NULL,
  `stackdump` mediumtext,
  `userid` bigint(10) unsigned DEFAULT NULL,
  `timecreated` bigint(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_evenqueu_use_ix` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='This table is for storing queued events. It stores only one ' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_events_queue`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_events_queue_handlers`
--

CREATE TABLE IF NOT EXISTS `mdl_events_queue_handlers` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `queuedeventid` bigint(10) unsigned NOT NULL,
  `handlerid` bigint(10) unsigned NOT NULL,
  `status` bigint(10) DEFAULT NULL,
  `errormessage` mediumtext,
  `timemodified` bigint(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_evenqueuhand_que_ix` (`queuedeventid`),
  KEY `mdl_evenqueuhand_han_ix` (`handlerid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='This is the list of queued handlers for processing. The even' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_events_queue_handlers`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_forum`
--

CREATE TABLE IF NOT EXISTS `mdl_forum` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `type` enum('single','news','general','social','eachuser','teacher','qanda') NOT NULL DEFAULT 'general',
  `name` varchar(255) NOT NULL DEFAULT '',
  `intro` text NOT NULL,
  `assessed` bigint(10) unsigned NOT NULL DEFAULT '0',
  `assesstimestart` bigint(10) unsigned NOT NULL DEFAULT '0',
  `assesstimefinish` bigint(10) unsigned NOT NULL DEFAULT '0',
  `scale` bigint(10) NOT NULL DEFAULT '0',
  `maxbytes` bigint(10) unsigned NOT NULL DEFAULT '0',
  `forcesubscribe` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `trackingtype` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `rsstype` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `rssarticles` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `warnafter` bigint(10) unsigned NOT NULL DEFAULT '0',
  `blockafter` bigint(10) unsigned NOT NULL DEFAULT '0',
  `blockperiod` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_foru_cou_ix` (`course`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Forums contain and structure discussion' AUTO_INCREMENT=10 ;

--
-- Dumping data for table `mdl_forum`
--

INSERT INTO `mdl_forum` (`id`, `course`, `type`, `name`, `intro`, `assessed`, `assesstimestart`, `assesstimefinish`, `scale`, `maxbytes`, `forcesubscribe`, `trackingtype`, `rsstype`, `rssarticles`, `timemodified`, `warnafter`, `blockafter`, `blockperiod`) VALUES
(1, 2, 'news', 'News forum', 'General news and announcements', 0, 0, 0, 1, 0, 1, 1, 0, 0, 1324980908, 0, 0, 0),
(2, 3, 'news', 'News forum', 'General news and announcements', 0, 0, 0, 1, 0, 1, 1, 0, 0, 1324980936, 0, 0, 0),
(3, 4, 'news', 'News forum', 'General news and announcements', 0, 0, 0, 1, 0, 1, 1, 0, 0, 1325605079, 0, 0, 0),
(4, 7, 'news', 'News forum', 'General news and announcements', 0, 0, 0, 1, 0, 1, 1, 0, 0, 1325605208, 0, 0, 0),
(5, 6, 'news', 'News forum', 'General news and announcements', 0, 0, 0, 1, 0, 1, 1, 0, 0, 1325682169, 0, 0, 0),
(6, 5, 'news', 'News forum', 'General news and announcements', 0, 0, 0, 1, 0, 1, 1, 0, 0, 1325682183, 0, 0, 0),
(7, 10, 'news', 'News forum', 'General news and announcements', 0, 0, 0, 1, 0, 1, 1, 0, 0, 1325682222, 0, 0, 0),
(8, 9, 'news', 'News forum', 'General news and announcements', 0, 0, 0, 1, 0, 1, 1, 0, 0, 1325682231, 0, 0, 0),
(9, 8, 'news', 'News forum', 'General news and announcements', 0, 0, 0, 1, 0, 1, 1, 0, 0, 1325682239, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_forum_discussions`
--

CREATE TABLE IF NOT EXISTS `mdl_forum_discussions` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `forum` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `firstpost` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `groupid` bigint(10) NOT NULL DEFAULT '-1',
  `assessed` tinyint(1) NOT NULL DEFAULT '1',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `usermodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timestart` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeend` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_forudisc_use_ix` (`userid`),
  KEY `mdl_forudisc_for_ix` (`forum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Forums are composed of discussions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_forum_discussions`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_forum_posts`
--

CREATE TABLE IF NOT EXISTS `mdl_forum_posts` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `discussion` bigint(10) unsigned NOT NULL DEFAULT '0',
  `parent` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `created` bigint(10) unsigned NOT NULL DEFAULT '0',
  `modified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `mailed` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `format` tinyint(2) NOT NULL DEFAULT '0',
  `attachment` varchar(100) NOT NULL DEFAULT '',
  `totalscore` smallint(4) NOT NULL DEFAULT '0',
  `mailnow` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_forupost_use_ix` (`userid`),
  KEY `mdl_forupost_cre_ix` (`created`),
  KEY `mdl_forupost_mai_ix` (`mailed`),
  KEY `mdl_forupost_dis_ix` (`discussion`),
  KEY `mdl_forupost_par_ix` (`parent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='All posts are stored in this table' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_forum_posts`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_forum_queue`
--

CREATE TABLE IF NOT EXISTS `mdl_forum_queue` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `discussionid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `postid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_foruqueu_use_ix` (`userid`),
  KEY `mdl_foruqueu_dis_ix` (`discussionid`),
  KEY `mdl_foruqueu_pos_ix` (`postid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='For keeping track of posts that will be mailed in digest for' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_forum_queue`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_forum_ratings`
--

CREATE TABLE IF NOT EXISTS `mdl_forum_ratings` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `post` bigint(10) unsigned NOT NULL DEFAULT '0',
  `time` bigint(10) unsigned NOT NULL DEFAULT '0',
  `rating` smallint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_forurati_use_ix` (`userid`),
  KEY `mdl_forurati_pos_ix` (`post`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='forum_ratings table retrofitted from MySQL' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_forum_ratings`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_forum_read`
--

CREATE TABLE IF NOT EXISTS `mdl_forum_read` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `forumid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `discussionid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `postid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `firstread` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lastread` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_foruread_usefor_ix` (`userid`,`forumid`),
  KEY `mdl_foruread_usedis_ix` (`userid`,`discussionid`),
  KEY `mdl_foruread_usepos_ix` (`userid`,`postid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Tracks each users read posts' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_forum_read`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_forum_subscriptions`
--

CREATE TABLE IF NOT EXISTS `mdl_forum_subscriptions` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `forum` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_forusubs_use_ix` (`userid`),
  KEY `mdl_forusubs_for_ix` (`forum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Keeps track of who is subscribed to what forum' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_forum_subscriptions`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_forum_track_prefs`
--

CREATE TABLE IF NOT EXISTS `mdl_forum_track_prefs` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `forumid` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_forutracpref_usefor_ix` (`userid`,`forumid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Tracks each users untracked forums' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_forum_track_prefs`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_glossary`
--

CREATE TABLE IF NOT EXISTS `mdl_glossary` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `intro` text NOT NULL,
  `allowduplicatedentries` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `displayformat` varchar(50) NOT NULL DEFAULT 'dictionary',
  `mainglossary` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `showspecial` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `showalphabet` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `showall` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `allowcomments` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `allowprintview` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `usedynalink` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `defaultapproval` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `globalglossary` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `entbypage` smallint(3) unsigned NOT NULL DEFAULT '10',
  `editalways` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `rsstype` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `rssarticles` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `assessed` bigint(10) unsigned NOT NULL DEFAULT '0',
  `assesstimestart` bigint(10) unsigned NOT NULL DEFAULT '0',
  `assesstimefinish` bigint(10) unsigned NOT NULL DEFAULT '0',
  `scale` bigint(10) NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_glos_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='all glossaries' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_glossary`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_glossary_alias`
--

CREATE TABLE IF NOT EXISTS `mdl_glossary_alias` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `entryid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `alias` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_glosalia_ent_ix` (`entryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='entries alias' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_glossary_alias`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_glossary_categories`
--

CREATE TABLE IF NOT EXISTS `mdl_glossary_categories` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `glossaryid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `usedynalink` tinyint(2) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `mdl_gloscate_glo_ix` (`glossaryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='all categories for glossary entries' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_glossary_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_glossary_comments`
--

CREATE TABLE IF NOT EXISTS `mdl_glossary_comments` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `entryid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `entrycomment` text NOT NULL,
  `format` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_gloscomm_use_ix` (`userid`),
  KEY `mdl_gloscomm_ent_ix` (`entryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='comments on glossary entries' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_glossary_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_glossary_entries`
--

CREATE TABLE IF NOT EXISTS `mdl_glossary_entries` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `glossaryid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `concept` varchar(255) NOT NULL DEFAULT '',
  `definition` text NOT NULL,
  `format` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `attachment` varchar(100) NOT NULL DEFAULT '',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `teacherentry` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `sourceglossaryid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `usedynalink` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `casesensitive` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `fullmatch` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `approved` tinyint(2) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `mdl_glosentr_use_ix` (`userid`),
  KEY `mdl_glosentr_con_ix` (`concept`),
  KEY `mdl_glosentr_glo_ix` (`glossaryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='all glossary entries' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_glossary_entries`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_glossary_entries_categories`
--

CREATE TABLE IF NOT EXISTS `mdl_glossary_entries_categories` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `categoryid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `entryid` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_glosentrcate_cat_ix` (`categoryid`),
  KEY `mdl_glosentrcate_ent_ix` (`entryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='categories of each glossary entry' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_glossary_entries_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_glossary_formats`
--

CREATE TABLE IF NOT EXISTS `mdl_glossary_formats` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `popupformatname` varchar(50) NOT NULL DEFAULT '',
  `visible` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `showgroup` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `defaultmode` varchar(50) NOT NULL DEFAULT '',
  `defaulthook` varchar(50) NOT NULL DEFAULT '',
  `sortkey` varchar(50) NOT NULL DEFAULT '',
  `sortorder` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Setting of the display formats' AUTO_INCREMENT=8 ;

--
-- Dumping data for table `mdl_glossary_formats`
--

INSERT INTO `mdl_glossary_formats` (`id`, `name`, `popupformatname`, `visible`, `showgroup`, `defaultmode`, `defaulthook`, `sortkey`, `sortorder`) VALUES
(1, 'continuous', 'continuous', 1, 1, '', '', '', ''),
(2, 'dictionary', 'dictionary', 1, 1, '', '', '', ''),
(3, 'encyclopedia', 'encyclopedia', 1, 1, '', '', '', ''),
(4, 'entrylist', 'entrylist', 1, 1, '', '', '', ''),
(5, 'faq', 'faq', 1, 1, '', '', '', ''),
(6, 'fullwithauthor', 'fullwithauthor', 1, 1, '', '', '', ''),
(7, 'fullwithoutauthor', 'fullwithoutauthor', 1, 1, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_glossary_ratings`
--

CREATE TABLE IF NOT EXISTS `mdl_glossary_ratings` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `entryid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `time` bigint(10) unsigned NOT NULL DEFAULT '0',
  `rating` smallint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_glosrati_use_ix` (`userid`),
  KEY `mdl_glosrati_ent_ix` (`entryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Contains user ratings for entries' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_glossary_ratings`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_categories`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_categories` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL,
  `parent` bigint(10) unsigned DEFAULT NULL,
  `depth` bigint(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) DEFAULT NULL,
  `fullname` varchar(255) NOT NULL DEFAULT '',
  `aggregation` bigint(10) NOT NULL DEFAULT '0',
  `keephigh` bigint(10) NOT NULL DEFAULT '0',
  `droplow` bigint(10) NOT NULL DEFAULT '0',
  `aggregateonlygraded` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `aggregateoutcomes` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `aggregatesubcats` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_gradcate_cou_ix` (`courseid`),
  KEY `mdl_gradcate_par_ix` (`parent`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='This table keeps information about categories, used for grou' AUTO_INCREMENT=13 ;

--
-- Dumping data for table `mdl_grade_categories`
--

INSERT INTO `mdl_grade_categories` (`id`, `courseid`, `parent`, `depth`, `path`, `fullname`, `aggregation`, `keephigh`, `droplow`, `aggregateonlygraded`, `aggregateoutcomes`, `aggregatesubcats`, `timecreated`, `timemodified`) VALUES
(1, 1, NULL, 1, '/1/', '?', 11, 0, 0, 1, 0, 0, 1324983152, 1324983152),
(2, 2, NULL, 1, '/2/', '?', 11, 0, 0, 1, 0, 0, 1325778549, 1325778549),
(3, 6, NULL, 1, '/3/', '?', 11, 0, 0, 1, 0, 0, 1326105886, 1326105886),
(4, 3, NULL, 1, '/4/', '?', 11, 0, 0, 1, 0, 0, 1326975312, 1326975312),
(5, 11, NULL, 1, '/5/', '?', 11, 0, 0, 1, 0, 0, 1325778549, 1328632893),
(6, 12, NULL, 1, '/6/', '?', 11, 0, 0, 1, 0, 0, 1325778549, 1328632955),
(7, 4, NULL, 1, '/7/', '?', 11, 0, 0, 1, 0, 0, 1328791611, 1328791611),
(8, 5, NULL, 1, '/8/', '?', 11, 0, 0, 1, 0, 0, 1328791611, 1328791611),
(9, 7, NULL, 1, '/9/', '?', 11, 0, 0, 1, 0, 0, 1328791611, 1328791611),
(10, 8, NULL, 1, '/10/', '?', 11, 0, 0, 1, 0, 0, 1328791611, 1328791612),
(11, 9, NULL, 1, '/11/', '?', 11, 0, 0, 1, 0, 0, 1328791612, 1328791612),
(12, 10, NULL, 1, '/12/', '?', 11, 0, 0, 1, 0, 0, 1328791612, 1328791612);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_categories_history`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_categories_history` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `action` bigint(10) unsigned NOT NULL DEFAULT '0',
  `oldid` bigint(10) unsigned NOT NULL,
  `source` varchar(255) DEFAULT NULL,
  `timemodified` bigint(10) unsigned DEFAULT NULL,
  `loggeduser` bigint(10) unsigned DEFAULT NULL,
  `courseid` bigint(10) unsigned NOT NULL,
  `parent` bigint(10) unsigned DEFAULT NULL,
  `depth` bigint(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) DEFAULT NULL,
  `fullname` varchar(255) NOT NULL DEFAULT '',
  `aggregation` bigint(10) NOT NULL DEFAULT '0',
  `keephigh` bigint(10) NOT NULL DEFAULT '0',
  `droplow` bigint(10) NOT NULL DEFAULT '0',
  `aggregateonlygraded` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `aggregateoutcomes` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `aggregatesubcats` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_gradcatehist_act_ix` (`action`),
  KEY `mdl_gradcatehist_old_ix` (`oldid`),
  KEY `mdl_gradcatehist_cou_ix` (`courseid`),
  KEY `mdl_gradcatehist_par_ix` (`parent`),
  KEY `mdl_gradcatehist_log_ix` (`loggeduser`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='History of grade_categories' AUTO_INCREMENT=27 ;

--
-- Dumping data for table `mdl_grade_categories_history`
--

INSERT INTO `mdl_grade_categories_history` (`id`, `action`, `oldid`, `source`, `timemodified`, `loggeduser`, `courseid`, `parent`, `depth`, `path`, `fullname`, `aggregation`, `keephigh`, `droplow`, `aggregateonlygraded`, `aggregateoutcomes`, `aggregatesubcats`) VALUES
(1, 1, 1, 'system', 1324983152, 2, 1, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(2, 2, 1, 'system', 1324983152, 2, 1, NULL, 1, '/1/', '?', 11, 0, 0, 1, 0, 0),
(3, 1, 2, 'system', 1325778549, 2, 2, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(4, 2, 2, 'system', 1325778549, 2, 2, NULL, 1, '/2/', '?', 11, 0, 0, 1, 0, 0),
(5, 1, 3, 'system', 1326105886, 2, 6, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(6, 2, 3, 'system', 1326105886, 2, 6, NULL, 1, '/3/', '?', 11, 0, 0, 1, 0, 0),
(7, 1, 4, 'system', 1326975312, 2, 3, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(8, 2, 4, 'system', 1326975312, 2, 3, NULL, 1, '/4/', '?', 11, 0, 0, 1, 0, 0),
(9, 1, 5, 'system', 1328632893, 2, 11, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(10, 2, 5, 'system', 1328632893, 2, 11, NULL, 1, '/5/', '?', 11, 0, 0, 1, 0, 0),
(11, 2, 5, 'restore', 1328632893, 2, 11, NULL, 1, '/5/', '?', 11, 0, 0, 1, 0, 0),
(12, 1, 6, 'system', 1328632955, 2, 12, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(13, 2, 6, 'system', 1328632955, 2, 12, NULL, 1, '/6/', '?', 11, 0, 0, 1, 0, 0),
(14, 2, 6, 'restore', 1328632955, 2, 12, NULL, 1, '/6/', '?', 11, 0, 0, 1, 0, 0),
(15, 1, 7, 'system', 1328791611, 2, 4, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(16, 2, 7, 'system', 1328791611, 2, 4, NULL, 1, '/7/', '?', 11, 0, 0, 1, 0, 0),
(17, 1, 8, 'system', 1328791611, 2, 5, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(18, 2, 8, 'system', 1328791611, 2, 5, NULL, 1, '/8/', '?', 11, 0, 0, 1, 0, 0),
(19, 1, 9, 'system', 1328791611, 2, 7, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(20, 2, 9, 'system', 1328791611, 2, 7, NULL, 1, '/9/', '?', 11, 0, 0, 1, 0, 0),
(21, 1, 10, 'system', 1328791611, 2, 8, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(22, 2, 10, 'system', 1328791612, 2, 8, NULL, 1, '/10/', '?', 11, 0, 0, 1, 0, 0),
(23, 1, 11, 'system', 1328791612, 2, 9, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(24, 2, 11, 'system', 1328791612, 2, 9, NULL, 1, '/11/', '?', 11, 0, 0, 1, 0, 0),
(25, 1, 12, 'system', 1328791612, 2, 10, NULL, 0, NULL, '?', 11, 0, 0, 1, 0, 0),
(26, 2, 12, 'system', 1328791612, 2, 10, NULL, 1, '/12/', '?', 11, 0, 0, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_grades`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_grades` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemid` bigint(10) unsigned NOT NULL,
  `userid` bigint(10) unsigned NOT NULL,
  `rawgrade` decimal(10,5) DEFAULT NULL,
  `rawgrademax` decimal(10,5) NOT NULL DEFAULT '100.00000',
  `rawgrademin` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `rawscaleid` bigint(10) unsigned DEFAULT NULL,
  `usermodified` bigint(10) unsigned DEFAULT NULL,
  `finalgrade` decimal(10,5) DEFAULT NULL,
  `hidden` bigint(10) unsigned NOT NULL DEFAULT '0',
  `locked` bigint(10) unsigned NOT NULL DEFAULT '0',
  `locktime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `exported` bigint(10) unsigned NOT NULL DEFAULT '0',
  `overridden` bigint(10) unsigned NOT NULL DEFAULT '0',
  `excluded` bigint(10) unsigned NOT NULL DEFAULT '0',
  `feedback` mediumtext,
  `feedbackformat` bigint(10) unsigned NOT NULL DEFAULT '0',
  `information` mediumtext,
  `informationformat` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned DEFAULT NULL,
  `timemodified` bigint(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_gradgrad_useite_uix` (`userid`,`itemid`),
  KEY `mdl_gradgrad_locloc_ix` (`locked`,`locktime`),
  KEY `mdl_gradgrad_ite_ix` (`itemid`),
  KEY `mdl_gradgrad_use_ix` (`userid`),
  KEY `mdl_gradgrad_raw_ix` (`rawscaleid`),
  KEY `mdl_gradgrad_use2_ix` (`usermodified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='grade_grades  This table keeps individual grades for each us' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_grade_grades`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_grades_history`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_grades_history` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `action` bigint(10) unsigned NOT NULL DEFAULT '0',
  `oldid` bigint(10) unsigned NOT NULL,
  `source` varchar(255) DEFAULT NULL,
  `timemodified` bigint(10) unsigned DEFAULT NULL,
  `loggeduser` bigint(10) unsigned DEFAULT NULL,
  `itemid` bigint(10) unsigned NOT NULL,
  `userid` bigint(10) unsigned NOT NULL,
  `rawgrade` decimal(10,5) DEFAULT NULL,
  `rawgrademax` decimal(10,5) NOT NULL DEFAULT '100.00000',
  `rawgrademin` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `rawscaleid` bigint(10) unsigned DEFAULT NULL,
  `usermodified` bigint(10) unsigned DEFAULT NULL,
  `finalgrade` decimal(10,5) DEFAULT NULL,
  `hidden` bigint(10) unsigned NOT NULL DEFAULT '0',
  `locked` bigint(10) unsigned NOT NULL DEFAULT '0',
  `locktime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `exported` bigint(10) unsigned NOT NULL DEFAULT '0',
  `overridden` bigint(10) unsigned NOT NULL DEFAULT '0',
  `excluded` bigint(10) unsigned NOT NULL DEFAULT '0',
  `feedback` mediumtext,
  `feedbackformat` bigint(10) unsigned NOT NULL DEFAULT '0',
  `information` mediumtext,
  `informationformat` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_gradgradhist_act_ix` (`action`),
  KEY `mdl_gradgradhist_old_ix` (`oldid`),
  KEY `mdl_gradgradhist_ite_ix` (`itemid`),
  KEY `mdl_gradgradhist_use_ix` (`userid`),
  KEY `mdl_gradgradhist_raw_ix` (`rawscaleid`),
  KEY `mdl_gradgradhist_use2_ix` (`usermodified`),
  KEY `mdl_gradgradhist_log_ix` (`loggeduser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='History table' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_grade_grades_history`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_import_newitem`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_import_newitem` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemname` varchar(255) NOT NULL DEFAULT '',
  `importcode` bigint(10) unsigned NOT NULL,
  `importer` bigint(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_gradimponewi_imp_ix` (`importer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='temporary table for storing new grade_item names from grade ' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_grade_import_newitem`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_import_values`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_import_values` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemid` bigint(10) unsigned DEFAULT NULL,
  `newgradeitem` bigint(10) unsigned DEFAULT NULL,
  `userid` bigint(10) unsigned NOT NULL,
  `finalgrade` decimal(10,5) DEFAULT NULL,
  `feedback` mediumtext,
  `importcode` bigint(10) unsigned NOT NULL,
  `importer` bigint(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_gradimpovalu_ite_ix` (`itemid`),
  KEY `mdl_gradimpovalu_new_ix` (`newgradeitem`),
  KEY `mdl_gradimpovalu_imp_ix` (`importer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Temporary table for importing grades' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_grade_import_values`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_items`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_items` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned DEFAULT NULL,
  `categoryid` bigint(10) unsigned DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `itemtype` varchar(30) NOT NULL DEFAULT '',
  `itemmodule` varchar(30) DEFAULT NULL,
  `iteminstance` bigint(10) unsigned DEFAULT NULL,
  `itemnumber` bigint(10) unsigned DEFAULT NULL,
  `iteminfo` mediumtext,
  `idnumber` varchar(255) DEFAULT NULL,
  `calculation` mediumtext,
  `gradetype` smallint(4) NOT NULL DEFAULT '1',
  `grademax` decimal(10,5) NOT NULL DEFAULT '100.00000',
  `grademin` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `scaleid` bigint(10) unsigned DEFAULT NULL,
  `outcomeid` bigint(10) unsigned DEFAULT NULL,
  `gradepass` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `multfactor` decimal(10,5) NOT NULL DEFAULT '1.00000',
  `plusfactor` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `aggregationcoef` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `sortorder` bigint(10) NOT NULL DEFAULT '0',
  `display` bigint(10) NOT NULL DEFAULT '0',
  `decimals` tinyint(1) unsigned DEFAULT NULL,
  `hidden` bigint(10) NOT NULL DEFAULT '0',
  `locked` bigint(10) NOT NULL DEFAULT '0',
  `locktime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `needsupdate` bigint(10) NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned DEFAULT NULL,
  `timemodified` bigint(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_graditem_locloc_ix` (`locked`,`locktime`),
  KEY `mdl_graditem_itenee_ix` (`itemtype`,`needsupdate`),
  KEY `mdl_graditem_gra_ix` (`gradetype`),
  KEY `mdl_graditem_idncou_ix` (`idnumber`,`courseid`),
  KEY `mdl_graditem_cou_ix` (`courseid`),
  KEY `mdl_graditem_cat_ix` (`categoryid`),
  KEY `mdl_graditem_sca_ix` (`scaleid`),
  KEY `mdl_graditem_out_ix` (`outcomeid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='This table keeps information about gradeable items (ie colum' AUTO_INCREMENT=14 ;

--
-- Dumping data for table `mdl_grade_items`
--

INSERT INTO `mdl_grade_items` (`id`, `courseid`, `categoryid`, `itemname`, `itemtype`, `itemmodule`, `iteminstance`, `itemnumber`, `iteminfo`, `idnumber`, `calculation`, `gradetype`, `grademax`, `grademin`, `scaleid`, `outcomeid`, `gradepass`, `multfactor`, `plusfactor`, `aggregationcoef`, `sortorder`, `display`, `decimals`, `hidden`, `locked`, `locktime`, `needsupdate`, `timecreated`, `timemodified`) VALUES
(1, 1, NULL, NULL, 'course', NULL, 1, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 0, 1324983152, 1324983152),
(2, 2, NULL, NULL, 'course', NULL, 2, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 0, 1325778549, 1325778549),
(3, 6, NULL, NULL, 'course', NULL, 3, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 0, 1326105886, 1326105886),
(4, 6, 3, 'Test activity', 'mod', 'assignment', 1, 0, NULL, '', NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 2, 0, NULL, 0, 0, 0, 0, 1326115093, 1326115093),
(5, 3, NULL, NULL, 'course', NULL, 4, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 0, 1326975312, 1326975312),
(6, 11, NULL, NULL, 'course', NULL, 5, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 1, 1325778549, 1328632893),
(7, 12, NULL, NULL, 'course', NULL, 6, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 1, 1325778549, 1328632955),
(8, 4, NULL, NULL, 'course', NULL, 7, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 0, 1328791611, 1328791611),
(9, 5, NULL, NULL, 'course', NULL, 8, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 0, 1328791611, 1328791611),
(10, 7, NULL, NULL, 'course', NULL, 9, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 0, 1328791611, 1328791611),
(11, 8, NULL, NULL, 'course', NULL, 10, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 0, 1328791611, 1328791611),
(12, 9, NULL, NULL, 'course', NULL, 11, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 0, 1328791612, 1328791612),
(13, 10, NULL, NULL, 'course', NULL, 12, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, NULL, 0, 0, 0, 0, 1328791612, 1328791612);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_items_history`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_items_history` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `action` bigint(10) unsigned NOT NULL DEFAULT '0',
  `oldid` bigint(10) unsigned NOT NULL,
  `source` varchar(255) DEFAULT NULL,
  `timemodified` bigint(10) unsigned DEFAULT NULL,
  `loggeduser` bigint(10) unsigned DEFAULT NULL,
  `courseid` bigint(10) unsigned DEFAULT NULL,
  `categoryid` bigint(10) unsigned DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `itemtype` varchar(30) NOT NULL DEFAULT '',
  `itemmodule` varchar(30) DEFAULT NULL,
  `iteminstance` bigint(10) unsigned DEFAULT NULL,
  `itemnumber` bigint(10) unsigned DEFAULT NULL,
  `iteminfo` mediumtext,
  `idnumber` varchar(255) DEFAULT NULL,
  `calculation` mediumtext,
  `gradetype` smallint(4) NOT NULL DEFAULT '1',
  `grademax` decimal(10,5) NOT NULL DEFAULT '100.00000',
  `grademin` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `scaleid` bigint(10) unsigned DEFAULT NULL,
  `outcomeid` bigint(10) unsigned DEFAULT NULL,
  `gradepass` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `multfactor` decimal(10,5) NOT NULL DEFAULT '1.00000',
  `plusfactor` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `aggregationcoef` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `sortorder` bigint(10) NOT NULL DEFAULT '0',
  `hidden` bigint(10) NOT NULL DEFAULT '0',
  `locked` bigint(10) NOT NULL DEFAULT '0',
  `locktime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `needsupdate` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_graditemhist_act_ix` (`action`),
  KEY `mdl_graditemhist_old_ix` (`oldid`),
  KEY `mdl_graditemhist_cou_ix` (`courseid`),
  KEY `mdl_graditemhist_cat_ix` (`categoryid`),
  KEY `mdl_graditemhist_sca_ix` (`scaleid`),
  KEY `mdl_graditemhist_out_ix` (`outcomeid`),
  KEY `mdl_graditemhist_log_ix` (`loggeduser`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='History of grade_items' AUTO_INCREMENT=16 ;

--
-- Dumping data for table `mdl_grade_items_history`
--

INSERT INTO `mdl_grade_items_history` (`id`, `action`, `oldid`, `source`, `timemodified`, `loggeduser`, `courseid`, `categoryid`, `itemname`, `itemtype`, `itemmodule`, `iteminstance`, `itemnumber`, `iteminfo`, `idnumber`, `calculation`, `gradetype`, `grademax`, `grademin`, `scaleid`, `outcomeid`, `gradepass`, `multfactor`, `plusfactor`, `aggregationcoef`, `sortorder`, `hidden`, `locked`, `locktime`, `needsupdate`) VALUES
(1, 1, 1, 'system', 1324983152, 2, 1, NULL, NULL, 'course', NULL, 1, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(2, 1, 2, 'system', 1325778549, 2, 2, NULL, NULL, 'course', NULL, 2, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(3, 1, 3, 'system', 1326105886, 2, 6, NULL, NULL, 'course', NULL, 3, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(4, 1, 4, NULL, 1326115093, 2, 6, 3, 'Test activity', 'mod', 'assignment', 1, 0, NULL, '', NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 2, 0, 0, 0, 1),
(5, 1, 5, 'system', 1326975312, 2, 3, NULL, NULL, 'course', NULL, 4, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(6, 1, 6, 'system', 1328632893, 2, 11, NULL, NULL, 'course', NULL, 5, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(7, 2, 6, 'restore', 1328632893, 2, 11, NULL, NULL, 'course', NULL, 5, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(8, 1, 7, 'system', 1328632955, 2, 12, NULL, NULL, 'course', NULL, 6, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(9, 2, 7, 'restore', 1328632955, 2, 12, NULL, NULL, 'course', NULL, 6, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(10, 1, 8, 'system', 1328791611, 2, 4, NULL, NULL, 'course', NULL, 7, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(11, 1, 9, 'system', 1328791611, 2, 5, NULL, NULL, 'course', NULL, 8, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(12, 1, 10, 'system', 1328791611, 2, 7, NULL, NULL, 'course', NULL, 9, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(13, 1, 11, 'system', 1328791611, 2, 8, NULL, NULL, 'course', NULL, 10, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(14, 1, 12, 'system', 1328791612, 2, 9, NULL, NULL, 'course', NULL, 11, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1),
(15, 1, 13, 'system', 1328791612, 2, 10, NULL, NULL, 'course', NULL, 12, NULL, NULL, NULL, NULL, 1, '100.00000', '0.00000', NULL, NULL, '0.00000', '1.00000', '0.00000', '0.00000', 1, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_letters`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_letters` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `contextid` bigint(10) unsigned NOT NULL,
  `lowerboundary` decimal(10,5) NOT NULL,
  `letter` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_gradlett_conlow_ix` (`contextid`,`lowerboundary`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Repository for grade letters, for courses and other moodle e' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_grade_letters`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_outcomes`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_outcomes` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned DEFAULT NULL,
  `shortname` varchar(255) NOT NULL DEFAULT '',
  `fullname` text NOT NULL,
  `scaleid` bigint(10) unsigned DEFAULT NULL,
  `description` text,
  `timecreated` bigint(10) unsigned DEFAULT NULL,
  `timemodified` bigint(10) unsigned DEFAULT NULL,
  `usermodified` bigint(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_gradoutc_cousho_uix` (`courseid`,`shortname`),
  KEY `mdl_gradoutc_cou_ix` (`courseid`),
  KEY `mdl_gradoutc_sca_ix` (`scaleid`),
  KEY `mdl_gradoutc_use_ix` (`usermodified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='This table describes the outcomes used in the system. An out' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_grade_outcomes`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_outcomes_courses`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_outcomes_courses` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL,
  `outcomeid` bigint(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_gradoutccour_couout_uix` (`courseid`,`outcomeid`),
  KEY `mdl_gradoutccour_cou_ix` (`courseid`),
  KEY `mdl_gradoutccour_out_ix` (`outcomeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='stores what outcomes are used in what courses.' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_grade_outcomes_courses`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_outcomes_history`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_outcomes_history` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `action` bigint(10) unsigned NOT NULL DEFAULT '0',
  `oldid` bigint(10) unsigned NOT NULL,
  `source` varchar(255) DEFAULT NULL,
  `timemodified` bigint(10) unsigned DEFAULT NULL,
  `loggeduser` bigint(10) unsigned DEFAULT NULL,
  `courseid` bigint(10) unsigned DEFAULT NULL,
  `shortname` varchar(255) NOT NULL DEFAULT '',
  `fullname` text NOT NULL,
  `scaleid` bigint(10) unsigned DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `mdl_gradoutchist_act_ix` (`action`),
  KEY `mdl_gradoutchist_old_ix` (`oldid`),
  KEY `mdl_gradoutchist_cou_ix` (`courseid`),
  KEY `mdl_gradoutchist_sca_ix` (`scaleid`),
  KEY `mdl_gradoutchist_log_ix` (`loggeduser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='History table' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_grade_outcomes_history`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_grade_settings`
--

CREATE TABLE IF NOT EXISTS `mdl_grade_settings` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_gradsett_counam_uix` (`courseid`,`name`),
  KEY `mdl_gradsett_cou_ix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='gradebook settings' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_grade_settings`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_groupings`
--

CREATE TABLE IF NOT EXISTS `mdl_groupings` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `configdata` text,
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_grou_cou2_ix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='A grouping is a collection of groups. WAS: groups_groupings' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_groupings`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_groupings_groups`
--

CREATE TABLE IF NOT EXISTS `mdl_groupings_groups` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupingid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `groupid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeadded` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_grougrou_gro_ix` (`groupingid`),
  KEY `mdl_grougrou_gro2_ix` (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Link a grouping to a group (note, groups can be in multiple ' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_groupings_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_groups`
--

CREATE TABLE IF NOT EXISTS `mdl_groups` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL,
  `name` varchar(254) NOT NULL DEFAULT '',
  `description` text,
  `enrolmentkey` varchar(50) DEFAULT NULL,
  `picture` bigint(10) unsigned NOT NULL DEFAULT '0',
  `hidepicture` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_grou_cou_ix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Each record represents a group.' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_groups_members`
--

CREATE TABLE IF NOT EXISTS `mdl_groups_members` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeadded` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_groumemb_gro_ix` (`groupid`),
  KEY `mdl_groumemb_use_ix` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Link a user to a group.' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_groups_members`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_hotpot`
--

CREATE TABLE IF NOT EXISTS `mdl_hotpot` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `summary` text NOT NULL,
  `timeopen` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeclose` bigint(10) unsigned NOT NULL DEFAULT '0',
  `location` smallint(4) unsigned NOT NULL DEFAULT '0',
  `reference` varchar(255) NOT NULL DEFAULT '',
  `outputformat` smallint(4) unsigned NOT NULL DEFAULT '1',
  `navigation` smallint(4) unsigned NOT NULL DEFAULT '1',
  `studentfeedback` smallint(4) unsigned NOT NULL DEFAULT '0',
  `studentfeedbackurl` varchar(255) NOT NULL DEFAULT '',
  `forceplugins` smallint(4) unsigned NOT NULL DEFAULT '0',
  `shownextquiz` smallint(4) unsigned NOT NULL DEFAULT '0',
  `review` smallint(4) NOT NULL DEFAULT '0',
  `grade` bigint(10) NOT NULL DEFAULT '0',
  `grademethod` smallint(4) NOT NULL DEFAULT '1',
  `attempts` mediumint(6) NOT NULL DEFAULT '0',
  `password` varchar(255) NOT NULL DEFAULT '',
  `subnet` varchar(255) NOT NULL DEFAULT '',
  `clickreporting` smallint(4) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='details about Hot Potatoes quizzes' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_hotpot`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_hotpot_attempts`
--

CREATE TABLE IF NOT EXISTS `mdl_hotpot_attempts` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `hotpot` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `starttime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `endtime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `score` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `penalties` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `attempt` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `timestart` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timefinish` bigint(10) unsigned NOT NULL DEFAULT '0',
  `status` smallint(4) unsigned NOT NULL DEFAULT '1',
  `clickreportid` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_hotpatte_use_ix` (`userid`),
  KEY `mdl_hotpatte_hot_ix` (`hotpot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='details about Hot Potatoes quiz attempts' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_hotpot_attempts`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_hotpot_details`
--

CREATE TABLE IF NOT EXISTS `mdl_hotpot_details` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `attempt` bigint(10) unsigned NOT NULL DEFAULT '0',
  `details` text,
  PRIMARY KEY (`id`),
  KEY `mdl_hotpdeta_att_ix` (`attempt`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='raw details (as XML) of Hot Potatoes quiz attempts' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_hotpot_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_hotpot_questions`
--

CREATE TABLE IF NOT EXISTS `mdl_hotpot_questions` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `type` smallint(4) unsigned NOT NULL DEFAULT '0',
  `text` bigint(10) unsigned NOT NULL DEFAULT '0',
  `hotpot` bigint(10) unsigned NOT NULL DEFAULT '0',
  `md5key` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_hotpques_md5_ix` (`md5key`),
  KEY `mdl_hotpques_hot_ix` (`hotpot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='details about questions in Hot Potatoes quiz attempts' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_hotpot_questions`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_hotpot_responses`
--

CREATE TABLE IF NOT EXISTS `mdl_hotpot_responses` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `attempt` bigint(10) unsigned NOT NULL DEFAULT '0',
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `score` mediumint(6) NOT NULL DEFAULT '0',
  `weighting` mediumint(6) NOT NULL DEFAULT '0',
  `correct` varchar(255) NOT NULL DEFAULT '',
  `wrong` varchar(255) NOT NULL DEFAULT '',
  `ignored` varchar(255) NOT NULL DEFAULT '',
  `hints` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `clues` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `checks` mediumint(6) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_hotpresp_att_ix` (`attempt`),
  KEY `mdl_hotpresp_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='details about responses in Hot Potatoes quiz attempts' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_hotpot_responses`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_hotpot_strings`
--

CREATE TABLE IF NOT EXISTS `mdl_hotpot_strings` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `string` text NOT NULL,
  `md5key` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_hotpstri_md5_ix` (`md5key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='strings used in Hot Potatoes questions and responses' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_hotpot_strings`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_journal`
--

CREATE TABLE IF NOT EXISTS `mdl_journal` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `intro` text NOT NULL,
  `introformat` tinyint(2) NOT NULL DEFAULT '0',
  `days` mediumint(5) unsigned NOT NULL DEFAULT '7',
  `assessed` bigint(10) NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_jour_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='data for each journal' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_journal`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_journal_entries`
--

CREATE TABLE IF NOT EXISTS `mdl_journal_entries` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `journal` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `modified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `format` tinyint(2) NOT NULL DEFAULT '0',
  `rating` bigint(10) DEFAULT '0',
  `entrycomment` text,
  `teacher` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemarked` bigint(10) unsigned NOT NULL DEFAULT '0',
  `mailed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_jourentr_use_ix` (`userid`),
  KEY `mdl_jourentr_jou_ix` (`journal`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='All the journal entries of all people' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_journal_entries`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_label`
--

CREATE TABLE IF NOT EXISTS `mdl_label` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_labe_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines labels' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_label`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_lams`
--

CREATE TABLE IF NOT EXISTS `mdl_lams` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `introduction` text NOT NULL,
  `learning_session_id` bigint(20) DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_lams_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='LAMS activity' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_lams`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_launcher`
--

CREATE TABLE IF NOT EXISTS `mdl_launcher` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `intro` mediumtext,
  `introformat` smallint(4) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `average_loadtime` double DEFAULT '0',
  `installed` bigint(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_laun_cou_ix` (`course`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Default comment for launcher, please edit me' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mdl_launcher`
--

INSERT INTO `mdl_launcher` (`id`, `course`, `name`, `intro`, `introformat`, `timecreated`, `timemodified`, `average_loadtime`, `installed`) VALUES
(1, 1, 'Launcher', NULL, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_launcher_moodles`
--

CREATE TABLE IF NOT EXISTS `mdl_launcher_moodles` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `shortname` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(100) DEFAULT NULL,
  `admin_email` varchar(100) NOT NULL DEFAULT '',
  `domain` varchar(100) NOT NULL DEFAULT '',
  `server_name` varchar(100) NOT NULL DEFAULT '',
  `launcher_id` bigint(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Known current moodle environments.' AUTO_INCREMENT=36 ;

--
-- Dumping data for table `mdl_launcher_moodles`
--

INSERT INTO `mdl_launcher_moodles` (`id`, `name`, `shortname`, `description`, `admin_email`, `domain`, `server_name`, `launcher_id`) VALUES
(35, 'jeelotarget1', 'jeelotarget1', '', 'm.deridder@solin.nl', 'jeelotarget1.jeelo.nl', 'localhost', 3);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_lesson`
--

CREATE TABLE IF NOT EXISTS `mdl_lesson` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `practice` smallint(3) unsigned NOT NULL DEFAULT '0',
  `modattempts` smallint(3) unsigned NOT NULL DEFAULT '0',
  `usepassword` smallint(3) unsigned NOT NULL DEFAULT '0',
  `password` varchar(32) NOT NULL DEFAULT '',
  `dependency` bigint(10) unsigned NOT NULL DEFAULT '0',
  `conditions` text NOT NULL,
  `grade` smallint(3) NOT NULL DEFAULT '0',
  `custom` smallint(3) unsigned NOT NULL DEFAULT '0',
  `ongoing` smallint(3) unsigned NOT NULL DEFAULT '0',
  `usemaxgrade` smallint(3) NOT NULL DEFAULT '0',
  `maxanswers` smallint(3) unsigned NOT NULL DEFAULT '4',
  `maxattempts` smallint(3) unsigned NOT NULL DEFAULT '5',
  `review` smallint(3) unsigned NOT NULL DEFAULT '0',
  `nextpagedefault` smallint(3) unsigned NOT NULL DEFAULT '0',
  `feedback` smallint(3) unsigned NOT NULL DEFAULT '1',
  `minquestions` smallint(3) unsigned NOT NULL DEFAULT '0',
  `maxpages` smallint(3) unsigned NOT NULL DEFAULT '0',
  `timed` smallint(3) unsigned NOT NULL DEFAULT '0',
  `maxtime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `retake` smallint(3) unsigned NOT NULL DEFAULT '1',
  `activitylink` bigint(10) unsigned NOT NULL DEFAULT '0',
  `mediafile` varchar(255) NOT NULL DEFAULT '',
  `mediaheight` bigint(10) unsigned NOT NULL DEFAULT '100',
  `mediawidth` bigint(10) unsigned NOT NULL DEFAULT '650',
  `mediaclose` smallint(3) unsigned NOT NULL DEFAULT '0',
  `slideshow` smallint(3) unsigned NOT NULL DEFAULT '0',
  `width` bigint(10) unsigned NOT NULL DEFAULT '640',
  `height` bigint(10) unsigned NOT NULL DEFAULT '480',
  `bgcolor` varchar(7) NOT NULL DEFAULT '#FFFFFF',
  `displayleft` smallint(3) unsigned NOT NULL DEFAULT '0',
  `displayleftif` smallint(3) unsigned NOT NULL DEFAULT '0',
  `progressbar` smallint(3) unsigned NOT NULL DEFAULT '0',
  `highscores` smallint(3) unsigned NOT NULL DEFAULT '0',
  `maxhighscores` bigint(10) unsigned NOT NULL DEFAULT '0',
  `available` bigint(10) unsigned NOT NULL DEFAULT '0',
  `deadline` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_less_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_lesson`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_lesson_answers`
--

CREATE TABLE IF NOT EXISTS `mdl_lesson_answers` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `lessonid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `pageid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `jumpto` bigint(11) NOT NULL DEFAULT '0',
  `grade` smallint(3) unsigned NOT NULL DEFAULT '0',
  `score` bigint(10) NOT NULL DEFAULT '0',
  `flags` smallint(3) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `answer` text,
  `response` text,
  PRIMARY KEY (`id`),
  KEY `mdl_lessansw_les_ix` (`lessonid`),
  KEY `mdl_lessansw_pag_ix` (`pageid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson_answers' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_lesson_answers`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_lesson_attempts`
--

CREATE TABLE IF NOT EXISTS `mdl_lesson_attempts` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `lessonid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `pageid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `answerid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `retry` smallint(3) unsigned NOT NULL DEFAULT '0',
  `correct` bigint(10) unsigned NOT NULL DEFAULT '0',
  `useranswer` text,
  `timeseen` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_lessatte_use_ix` (`userid`),
  KEY `mdl_lessatte_les_ix` (`lessonid`),
  KEY `mdl_lessatte_pag_ix` (`pageid`),
  KEY `mdl_lessatte_ans_ix` (`answerid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson_attempts' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_lesson_attempts`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_lesson_branch`
--

CREATE TABLE IF NOT EXISTS `mdl_lesson_branch` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `lessonid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `pageid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `retry` bigint(10) unsigned NOT NULL DEFAULT '0',
  `flag` smallint(3) unsigned NOT NULL DEFAULT '0',
  `timeseen` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_lessbran_use_ix` (`userid`),
  KEY `mdl_lessbran_les_ix` (`lessonid`),
  KEY `mdl_lessbran_pag_ix` (`pageid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='branches for each lesson/user' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_lesson_branch`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_lesson_default`
--

CREATE TABLE IF NOT EXISTS `mdl_lesson_default` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `practice` smallint(3) unsigned NOT NULL DEFAULT '0',
  `modattempts` smallint(3) unsigned NOT NULL DEFAULT '0',
  `usepassword` smallint(3) unsigned NOT NULL DEFAULT '0',
  `password` varchar(32) NOT NULL DEFAULT '',
  `conditions` text NOT NULL,
  `grade` smallint(3) NOT NULL DEFAULT '0',
  `custom` smallint(3) unsigned NOT NULL DEFAULT '0',
  `ongoing` smallint(3) unsigned NOT NULL DEFAULT '0',
  `usemaxgrade` smallint(3) unsigned NOT NULL DEFAULT '0',
  `maxanswers` smallint(3) unsigned NOT NULL DEFAULT '4',
  `maxattempts` smallint(3) unsigned NOT NULL DEFAULT '5',
  `review` smallint(3) unsigned NOT NULL DEFAULT '0',
  `nextpagedefault` smallint(3) unsigned NOT NULL DEFAULT '0',
  `feedback` smallint(3) unsigned NOT NULL DEFAULT '1',
  `minquestions` smallint(3) unsigned NOT NULL DEFAULT '0',
  `maxpages` smallint(3) unsigned NOT NULL DEFAULT '0',
  `timed` smallint(3) unsigned NOT NULL DEFAULT '0',
  `maxtime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `retake` smallint(3) unsigned NOT NULL DEFAULT '1',
  `mediaheight` bigint(10) unsigned NOT NULL DEFAULT '100',
  `mediawidth` bigint(10) unsigned NOT NULL DEFAULT '650',
  `mediaclose` smallint(3) unsigned NOT NULL DEFAULT '0',
  `slideshow` smallint(3) unsigned NOT NULL DEFAULT '0',
  `width` bigint(10) unsigned NOT NULL DEFAULT '640',
  `height` bigint(10) unsigned NOT NULL DEFAULT '480',
  `bgcolor` varchar(7) DEFAULT '#FFFFFF',
  `displayleft` smallint(3) unsigned NOT NULL DEFAULT '0',
  `displayleftif` smallint(3) unsigned NOT NULL DEFAULT '0',
  `progressbar` smallint(3) unsigned NOT NULL DEFAULT '0',
  `highscores` smallint(3) unsigned NOT NULL DEFAULT '0',
  `maxhighscores` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson_default' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_lesson_default`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_lesson_grades`
--

CREATE TABLE IF NOT EXISTS `mdl_lesson_grades` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `lessonid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `grade` double unsigned NOT NULL DEFAULT '0',
  `late` smallint(3) unsigned NOT NULL DEFAULT '0',
  `completed` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_lessgrad_use_ix` (`userid`),
  KEY `mdl_lessgrad_les_ix` (`lessonid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson_grades' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_lesson_grades`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_lesson_high_scores`
--

CREATE TABLE IF NOT EXISTS `mdl_lesson_high_scores` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `lessonid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `gradeid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `nickname` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_lesshighscor_use_ix` (`userid`),
  KEY `mdl_lesshighscor_les_ix` (`lessonid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='high scores for each lesson' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_lesson_high_scores`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_lesson_pages`
--

CREATE TABLE IF NOT EXISTS `mdl_lesson_pages` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `lessonid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `prevpageid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `nextpageid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `qtype` smallint(3) unsigned NOT NULL DEFAULT '0',
  `qoption` smallint(3) unsigned NOT NULL DEFAULT '0',
  `layout` smallint(3) unsigned NOT NULL DEFAULT '1',
  `display` smallint(3) unsigned NOT NULL DEFAULT '1',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `contents` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_lesspage_les_ix` (`lessonid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson_pages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_lesson_pages`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_lesson_timer`
--

CREATE TABLE IF NOT EXISTS `mdl_lesson_timer` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `lessonid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `starttime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lessontime` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_lesstime_use_ix` (`userid`),
  KEY `mdl_lesstime_les_ix` (`lessonid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='lesson timer for each lesson' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_lesson_timer`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_log`
--

CREATE TABLE IF NOT EXISTS `mdl_log` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `module` varchar(20) NOT NULL DEFAULT '',
  `cmid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `action` varchar(40) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL DEFAULT '',
  `info` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_log_coumodact_ix` (`course`,`module`,`action`),
  KEY `mdl_log_tim_ix` (`time`),
  KEY `mdl_log_act_ix` (`action`),
  KEY `mdl_log_usecou_ix` (`userid`,`course`),
  KEY `mdl_log_cmi_ix` (`cmid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Every action is logged as far as possible' AUTO_INCREMENT=431 ;

--
-- Dumping data for table `mdl_log`
--

INSERT INTO `mdl_log` (`id`, `time`, `userid`, `ip`, `course`, `module`, `cmid`, `action`, `url`, `info`) VALUES
(1, 1323877094, 2, '127.0.0.1', 1, 'user', 0, 'update', 'view.php?id=2&course=1', ''),
(2, 1323877282, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(3, 1324977671, 2, '0.0.0.0', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(4, 1324977672, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(5, 1324979827, 2, '0.0.0.0', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(6, 1324979827, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(7, 1324980904, 2, '0.0.0.0', 1, 'course', 0, 'new', 'view.php?id=2', 'Course Fullname 101 (ID 2)'),
(8, 1324980908, 2, '0.0.0.0', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(9, 1324980909, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(10, 1324980934, 2, '0.0.0.0', 1, 'course', 0, 'new', 'view.php?id=3', 'Course Fullname 102 (ID 3)'),
(11, 1324980936, 2, '0.0.0.0', 3, 'course', 0, 'view', 'view.php?id=3', '3'),
(12, 1324981272, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(13, 1324981364, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(14, 1324981369, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(15, 1324981369, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(16, 1324981672, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(17, 1324981698, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(18, 1324981716, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(19, 1324981904, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(20, 1324981917, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(21, 1324982035, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(22, 1324982042, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(23, 1324982066, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(24, 1324982114, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(25, 1324982133, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(26, 1324982288, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(27, 1324982379, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(28, 1324983194, 2, '0.0.0.0', 1, 'course', 0, 'add mod', '../mod/launcher/view.php?id=3', 'launcher 1'),
(29, 1324983194, 2, '0.0.0.0', 1, 'launcher', 3, 'add', 'view.php?id=3', '1'),
(30, 1324983194, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(31, 1324983194, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(32, 1324983866, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(33, 1324992853, 2, '0.0.0.0', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(34, 1324992853, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(35, 1324992869, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(36, 1324996401, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(37, 1325070927, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(38, 1325070928, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(39, 1325496915, 2, '0.0.0.0', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(40, 1325496915, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(41, 1325497703, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(42, 1325513832, 2, '0.0.0.0', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(43, 1325513832, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(44, 1325514079, 2, '0.0.0.0', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(45, 1325514079, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(46, 1325514386, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(47, 1325514390, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(48, 1325514391, 2, '0.0.0.0', 1, 'user', 0, 'logout', 'view.php?id=2&course=1', '2'),
(49, 1325514465, 2, '0.0.0.0', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(50, 1325514473, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(51, 1325514478, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(52, 1325514478, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(53, 1325515756, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(54, 1325518041, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(55, 1325521371, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(56, 1325584457, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(57, 1325584459, 2, '0.0.0.0', 1, 'user', 0, 'logout', 'view.php?id=2&course=1', '2'),
(58, 1325584468, 2, '0.0.0.0', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(59, 1325584468, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(60, 1325586086, 2, '0.0.0.0', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(61, 1325595109, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(62, 1325598224, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(63, 1325599434, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(64, 1325601442, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(65, 1325601560, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(66, 1325601610, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(67, 1325602347, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(68, 1325602774, 2, '0.0.0.0', 2, 'course', 0, 'update', 'edit.php?id=2', '2'),
(69, 1325602774, 2, '0.0.0.0', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(70, 1325602778, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(71, 1325602964, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(72, 1325604800, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(73, 1325605006, 2, '0.0.0.0', 2, 'course', 0, 'update', 'edit.php?id=2', '2'),
(74, 1325605006, 2, '0.0.0.0', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(75, 1325605010, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(76, 1325605060, 2, '0.0.0.0', 1, 'course', 0, 'new', 'view.php?id=4', 'Leerjaar 3/4 - Leven in een gezin (ID 4)'),
(77, 1325605063, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(78, 1325605079, 2, '0.0.0.0', 4, 'course', 0, 'update', 'edit.php?id=4', '4'),
(79, 1325605079, 2, '0.0.0.0', 4, 'course', 0, 'view', 'view.php?id=4', '4'),
(80, 1325605111, 2, '0.0.0.0', 1, 'course', 0, 'new', 'view.php?id=5', 'Jaar 5/6 - Vrienden in een groep (ID 5)'),
(81, 1325605113, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(82, 1325605140, 2, '0.0.0.0', 1, 'course', 0, 'new', 'view.php?id=6', 'Jaar 7/8 - Waarderen van verschillen (ID 6)'),
(83, 1325605142, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(84, 1325605204, 2, '0.0.0.0', 1, 'course', 0, 'new', 'view.php?id=7', 'Jaar 1/2 - Wonen in je straat (ID 7)'),
(85, 1325605208, 2, '0.0.0.0', 7, 'course', 0, 'view', 'view.php?id=7', '7'),
(86, 1325605209, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(87, 1325605237, 2, '0.0.0.0', 1, 'course', 0, 'new', 'view.php?id=8', 'Jaar 3/4 - Zorg voor je wijk (ID 8)'),
(88, 1325605257, 2, '0.0.0.0', 1, 'course', 0, 'new', 'view.php?id=9', 'Jaar 5/6 - Vrije tijd in je stad of dorp (ID 9)'),
(89, 1325605275, 2, '0.0.0.0', 1, 'course', 0, 'new', 'view.php?id=10', 'Jaar 7/8 - Ontwikkelen van je gemeente (ID 10)'),
(90, 1325605276, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(91, 1325606114, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(92, 1325673692, 0, '127.0.0.1', 0, 'login', 0, 'error', 'index.php', 'stoasadmin'),
(93, 1325673697, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(94, 1325673698, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(95, 1325673934, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(96, 1325673945, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(97, 1325673959, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(98, 1325680884, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(99, 1325682137, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(100, 1325682169, 2, '127.0.0.1', 6, 'course', 0, 'update', 'edit.php?id=6', '6'),
(101, 1325682169, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(102, 1325682183, 2, '127.0.0.1', 5, 'course', 0, 'update', 'edit.php?id=5', '5'),
(103, 1325682183, 2, '127.0.0.1', 5, 'course', 0, 'view', 'view.php?id=5', '5'),
(104, 1325682195, 2, '127.0.0.1', 4, 'course', 0, 'update', 'edit.php?id=4', '4'),
(105, 1325682195, 2, '127.0.0.1', 4, 'course', 0, 'view', 'view.php?id=4', '4'),
(106, 1325682205, 2, '127.0.0.1', 2, 'course', 0, 'update', 'edit.php?id=2', '2'),
(107, 1325682205, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(108, 1325682222, 2, '127.0.0.1', 10, 'course', 0, 'update', 'edit.php?id=10', '10'),
(109, 1325682222, 2, '127.0.0.1', 10, 'course', 0, 'view', 'view.php?id=10', '10'),
(110, 1325682231, 2, '127.0.0.1', 9, 'course', 0, 'update', 'edit.php?id=9', '9'),
(111, 1325682231, 2, '127.0.0.1', 9, 'course', 0, 'view', 'view.php?id=9', '9'),
(112, 1325682238, 2, '127.0.0.1', 8, 'course', 0, 'update', 'edit.php?id=8', '8'),
(113, 1325682239, 2, '127.0.0.1', 8, 'course', 0, 'view', 'view.php?id=8', '8'),
(114, 1325682246, 2, '127.0.0.1', 7, 'course', 0, 'update', 'edit.php?id=7', '7'),
(115, 1325682246, 2, '127.0.0.1', 7, 'course', 0, 'view', 'view.php?id=7', '7'),
(116, 1325682250, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(117, 1325687274, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(118, 1325687278, 2, '127.0.0.1', 5, 'course', 0, 'view', 'view.php?id=5', '5'),
(119, 1325766068, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(120, 1325768019, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(121, 1325771021, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(122, 1325775025, 0, '127.0.0.1', 0, 'login', 0, 'error', 'index.php', 'admin'),
(123, 1325775028, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(124, 1325775028, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(125, 1326100577, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(126, 1326100577, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(127, 1326101417, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(128, 1326103078, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(129, 1326114322, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(130, 1326115059, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(131, 1326115065, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(132, 1326115067, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(133, 1326115093, 2, '127.0.0.1', 6, 'course', 0, 'add mod', '../mod/assignment/view.php?id=11', 'assignment 1'),
(134, 1326115093, 2, '127.0.0.1', 6, 'assignment', 11, 'add', 'view.php?id=11', '1'),
(135, 1326115093, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(136, 1326117917, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(137, 1326119197, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(138, 1326121625, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(139, 1326122380, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(140, 1326122380, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(141, 1326199007, 2, '0.0.0.0', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(142, 1326808448, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(143, 1326808448, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(144, 1326885036, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(145, 1326885418, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(146, 1326886022, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(147, 1326886448, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(148, 1326967865, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(149, 1326967865, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(150, 1326971757, 2, '127.0.0.1', 7, 'course', 0, 'view', 'view.php?id=7', '7'),
(151, 1326972365, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(152, 1326972365, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(153, 1326974317, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(154, 1326974318, 2, '127.0.0.1', 3, 'course', 0, 'view', 'view.php?id=3', '3'),
(155, 1326974711, 2, '127.0.0.1', 3, 'course', 0, 'view', 'view.php?id=3', '3'),
(156, 1326974742, 2, '127.0.0.1', 3, 'course', 0, 'view', 'view.php?id=3', '3'),
(157, 1326975217, 2, '127.0.0.1', 3, 'course', 0, 'view', 'view.php?id=3', '3'),
(158, 1326975312, 2, '127.0.0.1', 3, 'course', 0, 'add mod', '../mod/choice/view.php?id=12', 'choice 1'),
(159, 1326975312, 2, '127.0.0.1', 3, 'choice', 12, 'add', 'view.php?id=12', '1'),
(160, 1326975312, 2, '127.0.0.1', 3, 'course', 0, 'view', 'view.php?id=3', '3'),
(161, 1326975315, 2, '127.0.0.1', 3, 'choice', 12, 'view', 'view.php?id=12', '1'),
(162, 1326975321, 2, '127.0.0.1', 3, 'choice', 12, 'view', 'view.php?id=12', '1'),
(163, 1326975810, 2, '127.0.0.1', 3, 'choice', 12, 'view', 'view.php?id=12', '1'),
(164, 1326976660, 2, '127.0.0.1', 3, 'course', 0, 'editsection', 'editsection.php?id=13', '1'),
(165, 1326976660, 2, '127.0.0.1', 3, 'course', 0, 'view', 'view.php?id=3', '3'),
(166, 1326976857, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(167, 1326976864, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(168, 1326976868, 2, '127.0.0.1', 3, 'course', 0, 'view', 'view.php?id=3', '3'),
(169, 1326979501, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(170, 1326979565, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(171, 1326979567, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(172, 1326979567, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(173, 1326979570, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(174, 1326979570, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(175, 1326979776, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(176, 1326981656, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(177, 1326981656, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(178, 1326988854, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(179, 1326988854, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(180, 1327500310, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(181, 1327500310, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(182, 1327500780, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(183, 1327515653, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(184, 1327515672, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(185, 1327515678, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(186, 1327515682, 2, '127.0.0.1', 1, 'user', 0, 'logout', 'view.php?id=2&course=1', '2'),
(187, 1327515685, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(188, 1327515826, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(189, 1327516608, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(190, 1327516745, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(191, 1327591405, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(192, 1327591408, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(193, 1327934839, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(194, 1327934839, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(195, 1327934859, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(196, 1327935297, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(197, 1328526375, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(198, 1328534143, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(199, 1328535282, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(200, 1328535827, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(201, 1328608110, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(202, 1328608110, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(203, 1328627963, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(204, 1328790110, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(205, 1328791536, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(206, 1328799063, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(207, 1328800564, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(208, 1328801640, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(209, 1328803324, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(210, 1328804448, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(211, 1329213729, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(212, 1329219538, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(213, 1329219573, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(214, 1329305831, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(215, 1329305913, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(216, 1329309241, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(217, 1329316263, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(218, 1329316355, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(219, 1329316373, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(220, 1329316375, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(221, 1329316389, 2, '127.0.0.1', 2, 'course', 0, 'add mod', '../mod/chat/view.php?id=13', 'chat 1'),
(222, 1329316389, 2, '127.0.0.1', 2, 'chat', 13, 'add', 'view.php?id=13', '1'),
(223, 1329316389, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(224, 1329316463, 2, '127.0.0.1', 2, 'course', 0, 'add mod', '../mod/choice/view.php?id=14', 'choice 2'),
(225, 1329316463, 2, '127.0.0.1', 2, 'choice', 14, 'add', 'view.php?id=14', '2'),
(226, 1329316463, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(227, 1329316472, 2, '127.0.0.1', 2, 'course', 0, 'update mod', '../mod/choice/view.php?id=14', 'choice 2'),
(228, 1329316472, 2, '127.0.0.1', 2, 'choice', 14, 'update', 'view.php?id=14', '2'),
(229, 1329316472, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(230, 1329316475, 2, '127.0.0.1', 2, 'choice', 14, 'view', 'view.php?id=14', '2'),
(231, 1329316485, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(232, 1329316589, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(233, 1329317358, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(234, 1329317423, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(235, 1329317430, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(236, 1329317543, 2, '127.0.0.1', 10, 'course', 0, 'view', 'view.php?id=10', '10'),
(237, 1329317555, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(238, 1329317708, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(239, 1329318291, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(240, 1329318865, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(241, 1329320138, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(242, 1329320143, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(243, 1329321224, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(244, 1329384990, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(245, 1329384990, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(246, 1329385464, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(247, 1329386805, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(248, 1329386927, 2, '127.0.0.1', 1, 'role', 0, 'add', 'admin/roles/manage.php?action=add', 'Substitute'),
(249, 1329386951, 2, '127.0.0.1', 1, 'role', 0, 'delete', 'admin/roles/action=delete&roleid=8', 'Substitute'),
(250, 1329387453, 2, '127.0.0.1', 1, 'role', 0, 'duplicate', 'admin/roles/manage.php?roleid=9&action=duplicate', 'Non-editing teacher copy 1'),
(251, 1329387996, 2, '127.0.0.1', 1, 'role', 0, 'edit', 'admin/roles/manage.php?action=edit&roleid=9', 'Substitute'),
(252, 1329388010, 2, '127.0.0.1', 1, 'role', 0, 'duplicate', 'admin/roles/manage.php?roleid=10&action=duplicate', 'Administrator copy 1'),
(253, 1329388051, 2, '127.0.0.1', 1, 'role', 0, 'edit', 'admin/roles/manage.php?action=edit&roleid=10', 'Manager'),
(254, 1329388079, 2, '127.0.0.1', 1, 'role', 0, 'edit', 'admin/roles/manage.php?action=edit&roleid=10', 'Manager'),
(255, 1329388730, 2, '127.0.0.1', 1, 'role', 0, 'delete', 'admin/roles/action=delete&roleid=10', 'Manager'),
(256, 1329389210, 2, '127.0.0.1', 1, 'role', 0, 'duplicate', 'admin/roles/manage.php?roleid=11&action=duplicate', 'Non-editing teacher copy 1'),
(257, 1329389244, 2, '127.0.0.1', 1, 'role', 0, 'edit', 'admin/roles/manage.php?action=edit&roleid=11', 'School leader'),
(258, 1329389522, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(259, 1329390291, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(260, 1329391325, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(261, 1329392138, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(262, 1329393090, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(263, 1329393090, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(264, 1329393322, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(265, 1329393401, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(266, 1329393523, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(267, 1329394209, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create', 'ERROR: Could not instantiate mail function.'),
(268, 1329398209, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(269, 1329398359, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(270, 1329398391, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(271, 1329398713, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(272, 1329398882, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(273, 1329398910, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(274, 1329398917, 2, '127.0.0.1', 7, 'course', 0, 'view', 'view.php?id=7', '7'),
(275, 1329399586, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(276, 1329400186, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(277, 1329400314, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(278, 1329403068, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(279, 1329403092, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(280, 1329403100, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(281, 1329403404, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(282, 1329403410, 2, '127.0.0.1', 10, 'course', 0, 'view', 'view.php?id=10', '10'),
(283, 1329405307, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(284, 1330333778, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(285, 1330333779, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(286, 1330348487, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(287, 1330350538, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(288, 1330352371, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(289, 1330353254, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(290, 1330357018, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(291, 1330361600, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(292, 1330363187, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(293, 1330512597, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(294, 1330512950, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(295, 1330513353, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(296, 1330513585, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(297, 1330513610, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(298, 1330513933, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(299, 1330513984, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(300, 1330517308, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(301, 1330519567, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(302, 1330522935, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(303, 1330522977, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(304, 1330524595, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(305, 1330525362, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(306, 1330526318, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(307, 1330526422, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(308, 1330531616, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(309, 1330600045, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(310, 1330607393, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(311, 1330679780, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(312, 1330680290, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(313, 1330680296, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(314, 1330680304, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(315, 1330680321, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(316, 1330680324, 2, '127.0.0.1', 1, 'user', 0, 'logout', 'view.php?id=2&course=1', '2'),
(317, 1330680328, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(318, 1330680328, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(319, 1330680656, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(320, 1330680662, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(321, 1330681116, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(322, 1330681116, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(323, 1330681428, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(324, 1330681831, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(325, 1330684300, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(326, 1330691496, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(327, 1330692529, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(328, 1330703688, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(329, 1330703921, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(330, 1330704245, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(331, 1330706729, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(332, 1330939622, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(333, 1330940420, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(334, 1330944603, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(335, 1330944728, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(336, 1330945756, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(337, 1331036681, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(338, 1331042852, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(339, 1331049672, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(340, 1331117192, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(341, 1331122572, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(342, 1331122729, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(343, 1331129729, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(344, 1331197838, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(345, 1331204340, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(346, 1331204341, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(347, 1331204762, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(348, 1331204764, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(349, 1331204963, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(350, 1331204965, 2, '127.0.0.1', 5, 'course', 0, 'view', 'view.php?id=5', '5'),
(351, 1331204969, 2, '127.0.0.1', 5, 'course', 0, 'view', 'view.php?id=5', '5'),
(352, 1331205043, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(353, 1331205113, 2, '127.0.0.1', 6, 'course', 0, 'update mod', '../mod/assignment/view.php?id=11', 'assignment 1'),
(354, 1331205113, 2, '127.0.0.1', 6, 'assignment', 11, 'update', 'view.php?id=11', '1'),
(355, 1331205113, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(356, 1331205115, 2, '127.0.0.1', 6, 'assignment', 11, 'view', 'view.php?id=11', '1'),
(357, 1331205135, 2, '127.0.0.1', 6, 'assignment', 11, 'view submission', 'submissions.php?id=11', '1'),
(358, 1331205140, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(359, 1331205142, 2, '127.0.0.1', 6, 'assignment', 11, 'view', 'view.php?id=11', '1'),
(360, 1331205147, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(361, 1331205152, 2, '127.0.0.1', 6, 'forum', 6, 'view forum', 'view.php?id=6', '5'),
(362, 1331205157, 2, '127.0.0.1', 6, 'assignment', 11, 'view', 'view.php?id=11', '1'),
(363, 1331205183, 2, '127.0.0.1', 6, 'course', 0, 'update mod', '../mod/assignment/view.php?id=11', 'assignment 1'),
(364, 1331205183, 2, '127.0.0.1', 6, 'assignment', 11, 'update', 'view.php?id=11', '1'),
(365, 1331205183, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(366, 1331205186, 2, '127.0.0.1', 6, 'assignment', 11, 'view', 'view.php?id=11', '1'),
(367, 1331205193, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(368, 1331205195, 2, '127.0.0.1', 7, 'course', 0, 'view', 'view.php?id=7', '7'),
(369, 1331205199, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(370, 1331205201, 2, '127.0.0.1', 2, 'choice', 14, 'view', 'view.php?id=14', '2'),
(371, 1331205204, 2, '127.0.0.1', 2, 'choice', 14, 'choose', 'view.php?id=14', '2'),
(372, 1331205204, 2, '127.0.0.1', 2, 'choice', 14, 'view', 'view.php?id=14', '2'),
(373, 1331205250, 2, '127.0.0.1', 2, 'course', 0, 'update mod', '../mod/choice/view.php?id=14', 'choice 2'),
(374, 1331205250, 2, '127.0.0.1', 2, 'choice', 14, 'update', 'view.php?id=14', '2'),
(375, 1331205250, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(376, 1331205252, 2, '127.0.0.1', 2, 'choice', 14, 'view', 'view.php?id=14', '2'),
(377, 1331205266, 2, '127.0.0.1', 2, 'course', 0, 'view', 'view.php?id=2', '2'),
(378, 1331221936, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(379, 1331221936, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(380, 1331640981, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(381, 1331653595, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(382, 1331653596, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(383, 1331717699, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(384, 1331717700, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(385, 1331734597, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(386, 1331735439, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(387, 1331738974, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(388, 1331739337, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(389, 1331807418, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(390, 1331812351, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(391, 1331813260, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(392, 1331817637, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(393, 1331823400, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(394, 1332148072, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(395, 1332148072, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(396, 1332151198, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(397, 1332153883, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(398, 1332154005, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(399, 1332154493, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(400, 1332161956, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(401, 1332162646, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(402, 1332169329, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(403, 1332170526, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(404, 1332170601, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(405, 1332170604, 2, '127.0.0.1', 6, 'course', 0, 'view', 'view.php?id=6', '6'),
(406, 1332170749, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(407, 1332171353, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(408, 1332171495, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(409, 1332171655, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(410, 1332171663, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(411, 1332171951, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(412, 1332172063, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(413, 1332172366, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(414, 1332172657, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(415, 1332173606, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(416, 1332175398, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(417, 1332176548, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(418, 1332176846, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(419, 1332236498, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(420, 1332246756, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(421, 1332246920, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(422, 1332251276, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(423, 1332329599, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(424, 1332413911, 2, '127.0.0.1', 1, 'user', 0, 'login', 'view.php?id=0&course=1', '2'),
(425, 1332418111, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(426, 1332431617, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(427, 1332432004, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(428, 1332432048, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1'),
(429, 1332437809, 2, '127.0.0.1', 1, 'library', 0, 'mailer', 'http://localhost/jeelo19/mod/launcher/view.php?id=3&controller=moodle&action=create_school', 'ERROR: Could not instantiate mail function.'),
(430, 1332437840, 2, '127.0.0.1', 1, 'course', 0, 'view', 'view.php?id=1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_log_display`
--

CREATE TABLE IF NOT EXISTS `mdl_log_display` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(20) NOT NULL DEFAULT '',
  `action` varchar(40) NOT NULL DEFAULT '',
  `mtable` varchar(30) NOT NULL DEFAULT '',
  `field` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_logdisp_modact_uix` (`module`,`action`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='For a particular module/action, specifies a moodle table/fie' AUTO_INCREMENT=113 ;

--
-- Dumping data for table `mdl_log_display`
--

INSERT INTO `mdl_log_display` (`id`, `module`, `action`, `mtable`, `field`) VALUES
(1, 'user', 'view', 'user', 'CONCAT(firstname,'' '',lastname)'),
(2, 'course', 'user report', 'user', 'CONCAT(firstname,'' '',lastname)'),
(3, 'course', 'view', 'course', 'fullname'),
(4, 'course', 'update', 'course', 'fullname'),
(5, 'course', 'enrol', 'course', 'fullname'),
(6, 'course', 'unenrol', 'course', 'fullname'),
(7, 'course', 'report log', 'course', 'fullname'),
(8, 'course', 'report live', 'course', 'fullname'),
(9, 'course', 'report outline', 'course', 'fullname'),
(10, 'course', 'report participation', 'course', 'fullname'),
(11, 'course', 'report stats', 'course', 'fullname'),
(12, 'message', 'write', 'user', 'CONCAT(firstname,'' '',lastname)'),
(13, 'message', 'read', 'user', 'CONCAT(firstname,'' '',lastname)'),
(14, 'message', 'add contact', 'user', 'CONCAT(firstname,'' '',lastname)'),
(15, 'message', 'remove contact', 'user', 'CONCAT(firstname,'' '',lastname)'),
(16, 'message', 'block contact', 'user', 'CONCAT(firstname,'' '',lastname)'),
(17, 'message', 'unblock contact', 'user', 'CONCAT(firstname,'' '',lastname)'),
(18, 'group', 'view', 'groups', 'name'),
(19, 'tag', 'update', 'tag', 'name'),
(20, 'assignment', 'view', 'assignment', 'name'),
(21, 'assignment', 'add', 'assignment', 'name'),
(22, 'assignment', 'update', 'assignment', 'name'),
(23, 'assignment', 'view submission', 'assignment', 'name'),
(24, 'assignment', 'upload', 'assignment', 'name'),
(25, 'chat', 'view', 'chat', 'name'),
(26, 'chat', 'add', 'chat', 'name'),
(27, 'chat', 'update', 'chat', 'name'),
(28, 'chat', 'report', 'chat', 'name'),
(29, 'chat', 'talk', 'chat', 'name'),
(30, 'choice', 'view', 'choice', 'name'),
(31, 'choice', 'update', 'choice', 'name'),
(32, 'choice', 'add', 'choice', 'name'),
(33, 'choice', 'report', 'choice', 'name'),
(34, 'choice', 'choose', 'choice', 'name'),
(35, 'choice', 'choose again', 'choice', 'name'),
(36, 'data', 'view', 'data', 'name'),
(37, 'data', 'add', 'data', 'name'),
(38, 'data', 'update', 'data', 'name'),
(39, 'data', 'record delete', 'data', 'name'),
(40, 'data', 'fields add', 'data_fields', 'name'),
(41, 'data', 'fields update', 'data_fields', 'name'),
(42, 'data', 'templates saved', 'data', 'name'),
(43, 'data', 'templates def', 'data', 'name'),
(44, 'forum', 'add', 'forum', 'name'),
(45, 'forum', 'update', 'forum', 'name'),
(46, 'forum', 'add discussion', 'forum_discussions', 'name'),
(47, 'forum', 'add post', 'forum_posts', 'subject'),
(48, 'forum', 'update post', 'forum_posts', 'subject'),
(49, 'forum', 'user report', 'user', 'CONCAT(firstname,'' '',lastname)'),
(50, 'forum', 'move discussion', 'forum_discussions', 'name'),
(51, 'forum', 'view subscribers', 'forum', 'name'),
(52, 'forum', 'view discussion', 'forum_discussions', 'name'),
(53, 'forum', 'view forum', 'forum', 'name'),
(54, 'forum', 'subscribe', 'forum', 'name'),
(55, 'forum', 'unsubscribe', 'forum', 'name'),
(56, 'glossary', 'add', 'glossary', 'name'),
(57, 'glossary', 'update', 'glossary', 'name'),
(58, 'glossary', 'view', 'glossary', 'name'),
(59, 'glossary', 'view all', 'glossary', 'name'),
(60, 'glossary', 'add entry', 'glossary', 'name'),
(61, 'glossary', 'update entry', 'glossary', 'name'),
(62, 'glossary', 'add category', 'glossary', 'name'),
(63, 'glossary', 'update category', 'glossary', 'name'),
(64, 'glossary', 'delete category', 'glossary', 'name'),
(65, 'glossary', 'add comment', 'glossary', 'name'),
(66, 'glossary', 'update comment', 'glossary', 'name'),
(67, 'glossary', 'delete comment', 'glossary', 'name'),
(68, 'glossary', 'approve entry', 'glossary', 'name'),
(69, 'glossary', 'view entry', 'glossary_entries', 'concept'),
(70, 'journal', 'view', 'journal', 'name'),
(71, 'journal', 'add entry', 'journal', 'name'),
(72, 'journal', 'update entry', 'journal', 'name'),
(73, 'journal', 'view responses', 'journal', 'name'),
(74, 'label', 'add', 'label', 'name'),
(75, 'label', 'update', 'label', 'name'),
(76, 'lesson', 'start', 'lesson', 'name'),
(77, 'lesson', 'end', 'lesson', 'name'),
(78, 'lesson', 'view', 'lesson_pages', 'title'),
(79, 'quiz', 'add', 'quiz', 'name'),
(80, 'quiz', 'update', 'quiz', 'name'),
(81, 'quiz', 'view', 'quiz', 'name'),
(82, 'quiz', 'report', 'quiz', 'name'),
(83, 'quiz', 'attempt', 'quiz', 'name'),
(84, 'quiz', 'submit', 'quiz', 'name'),
(85, 'quiz', 'review', 'quiz', 'name'),
(86, 'quiz', 'editquestions', 'quiz', 'name'),
(87, 'quiz', 'preview', 'quiz', 'name'),
(88, 'quiz', 'start attempt', 'quiz', 'name'),
(89, 'quiz', 'close attempt', 'quiz', 'name'),
(90, 'quiz', 'continue attempt', 'quiz', 'name'),
(91, 'resource', 'view', 'resource', 'name'),
(92, 'resource', 'update', 'resource', 'name'),
(93, 'resource', 'add', 'resource', 'name'),
(94, 'scorm', 'view', 'scorm', 'name'),
(95, 'scorm', 'review', 'scorm', 'name'),
(96, 'scorm', 'update', 'scorm', 'name'),
(97, 'scorm', 'add', 'scorm', 'name'),
(98, 'survey', 'add', 'survey', 'name'),
(99, 'survey', 'update', 'survey', 'name'),
(100, 'survey', 'download', 'survey', 'name'),
(101, 'survey', 'view form', 'survey', 'name'),
(102, 'survey', 'view graph', 'survey', 'name'),
(103, 'survey', 'view report', 'survey', 'name'),
(104, 'survey', 'submit', 'survey', 'name'),
(105, 'workshop', 'assessments', 'workshop', 'name'),
(106, 'workshop', 'close', 'workshop', 'name'),
(107, 'workshop', 'display', 'workshop', 'name'),
(108, 'workshop', 'resubmit', 'workshop', 'name'),
(109, 'workshop', 'set up', 'workshop', 'name'),
(110, 'workshop', 'submissions', 'workshop', 'name'),
(111, 'workshop', 'view', 'workshop', 'name'),
(112, 'workshop', 'update', 'workshop', 'name');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_message`
--

CREATE TABLE IF NOT EXISTS `mdl_message` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `useridfrom` bigint(10) unsigned NOT NULL DEFAULT '0',
  `useridto` bigint(10) unsigned NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `format` smallint(4) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) NOT NULL DEFAULT '0',
  `messagetype` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_mess_use_ix` (`useridfrom`),
  KEY `mdl_mess_use2_ix` (`useridto`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores all unread messages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_message`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_message_contacts`
--

CREATE TABLE IF NOT EXISTS `mdl_message_contacts` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `contactid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `blocked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_messcont_usecon_uix` (`userid`,`contactid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Maintains lists of relationships between users' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_message_contacts`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_message_read`
--

CREATE TABLE IF NOT EXISTS `mdl_message_read` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `useridfrom` bigint(10) unsigned NOT NULL DEFAULT '0',
  `useridto` bigint(10) unsigned NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `format` smallint(4) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) NOT NULL DEFAULT '0',
  `timeread` bigint(10) NOT NULL DEFAULT '0',
  `messagetype` varchar(50) NOT NULL DEFAULT '',
  `mailed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_messread_use_ix` (`useridfrom`),
  KEY `mdl_messread_use2_ix` (`useridto`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores all messages that have been read' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_message_read`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_mnet_application`
--

CREATE TABLE IF NOT EXISTS `mdl_mnet_application` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `display_name` varchar(50) NOT NULL DEFAULT '',
  `xmlrpc_server_url` varchar(255) NOT NULL DEFAULT '',
  `sso_land_url` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Information about applications on remote hosts' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mdl_mnet_application`
--

INSERT INTO `mdl_mnet_application` (`id`, `name`, `display_name`, `xmlrpc_server_url`, `sso_land_url`) VALUES
(1, 'moodle', 'Moodle', '/mnet/xmlrpc/server.php', '/auth/mnet/land.php'),
(2, 'mahara', 'Mahara', '/api/xmlrpc/server.php', '/auth/xmlrpc/land.php');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_mnet_enrol_assignments`
--

CREATE TABLE IF NOT EXISTS `mdl_mnet_enrol_assignments` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `hostid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `rolename` varchar(255) NOT NULL DEFAULT '',
  `enroltime` bigint(10) unsigned NOT NULL DEFAULT '0',
  `enroltype` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_mnetenroassi_hoscou_ix` (`hostid`,`courseid`),
  KEY `mdl_mnetenroassi_use_ix` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Information about enrolments on courses on remote hosts' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_mnet_enrol_assignments`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_mnet_enrol_course`
--

CREATE TABLE IF NOT EXISTS `mdl_mnet_enrol_course` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `hostid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `remoteid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `cat_id` bigint(10) unsigned NOT NULL DEFAULT '0',
  `cat_name` varchar(255) NOT NULL DEFAULT '',
  `cat_description` mediumtext NOT NULL,
  `sortorder` bigint(10) unsigned NOT NULL DEFAULT '0',
  `fullname` varchar(254) NOT NULL DEFAULT '',
  `shortname` varchar(15) NOT NULL DEFAULT '',
  `idnumber` varchar(100) NOT NULL DEFAULT '',
  `summary` mediumtext NOT NULL,
  `startdate` bigint(10) unsigned NOT NULL DEFAULT '0',
  `cost` varchar(10) NOT NULL DEFAULT '',
  `currency` varchar(3) NOT NULL DEFAULT '',
  `defaultroleid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `defaultrolename` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_mnetenrocour_hosrem_uix` (`hostid`,`remoteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Information about courses on remote hosts' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_mnet_enrol_course`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_mnet_host`
--

CREATE TABLE IF NOT EXISTS `mdl_mnet_host` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `wwwroot` varchar(255) NOT NULL DEFAULT '',
  `ip_address` varchar(39) NOT NULL DEFAULT '',
  `name` varchar(80) NOT NULL DEFAULT '',
  `public_key` mediumtext NOT NULL,
  `public_key_expires` bigint(10) unsigned NOT NULL DEFAULT '0',
  `transport` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `portno` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `last_connect_time` bigint(10) unsigned NOT NULL DEFAULT '0',
  `last_log_id` bigint(10) unsigned NOT NULL DEFAULT '0',
  `force_theme` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) DEFAULT NULL,
  `applicationid` bigint(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `mdl_mnethost_app_ix` (`applicationid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Information about the local and remote hosts for RPC' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mdl_mnet_host`
--

INSERT INTO `mdl_mnet_host` (`id`, `deleted`, `wwwroot`, `ip_address`, `name`, `public_key`, `public_key_expires`, `transport`, `portno`, `last_connect_time`, `last_log_id`, `force_theme`, `theme`, `applicationid`) VALUES
(1, 0, 'http://localhost/jeelo19', '127.0.0.1', '', '-----BEGIN CERTIFICATE-----\nMIIDszCCAxygAwIBAgIBADANBgkqhkiG9w0BAQQFADCBnjELMAkGA1UEBhMCTkwx\nDjAMBgNVBAgTBUJyZWRhMQ4wDAYDVQQHEwVCcmVkYTEXMBUGA1UEChMOSmVlbG8g\nTGF1bmNoZXIxDzANBgNVBAsTBk1vb2RsZTEhMB8GA1UEAxMYaHR0cDovL2xvY2Fs\naG9zdC9qZWVsbzE5MSIwIAYJKoZIhvcNAQkBFhNtLmRlcmlkZGVyQHNvbGluLm5s\nMB4XDTEyMDIxNTE1MDY0NFoXDTEyMDMxNDE1MDY0NFowgZ4xCzAJBgNVBAYTAk5M\nMQ4wDAYDVQQIEwVCcmVkYTEOMAwGA1UEBxMFQnJlZGExFzAVBgNVBAoTDkplZWxv\nIExhdW5jaGVyMQ8wDQYDVQQLEwZNb29kbGUxITAfBgNVBAMTGGh0dHA6Ly9sb2Nh\nbGhvc3QvamVlbG8xOTEiMCAGCSqGSIb3DQEJARYTbS5kZXJpZGRlckBzb2xpbi5u\nbDCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAu89LmMXZkrCqLdBaLOZgPuSD\njQupDD1D46Oh9IfbB1XiVt7VqI79/lot4UkKuiaMsL4HBQZZAM6Ucnua0YZLMh7z\nA2aoYWkQnJSxAVJ1cG4hSKh28qrpZJAurtmmydFKE8ODZkIbg6+5kzWZtS4ubBY3\nU+rrOwmjIqXJOAKHL7kCAwEAAaOB/jCB+zAdBgNVHQ4EFgQUIra+jAOl9KP2p/1z\nNuwWKSp4O5QwgcsGA1UdIwSBwzCBwIAUIra+jAOl9KP2p/1zNuwWKSp4O5ShgaSk\ngaEwgZ4xCzAJBgNVBAYTAk5MMQ4wDAYDVQQIEwVCcmVkYTEOMAwGA1UEBxMFQnJl\nZGExFzAVBgNVBAoTDkplZWxvIExhdW5jaGVyMQ8wDQYDVQQLEwZNb29kbGUxITAf\nBgNVBAMTGGh0dHA6Ly9sb2NhbGhvc3QvamVlbG8xOTEiMCAGCSqGSIb3DQEJARYT\nbS5kZXJpZGRlckBzb2xpbi5ubIIBADAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEB\nBAUAA4GBAIZcWM1Tfxagmt2/dzzw+QHwSqALl1dsJ3u11t6GvJqKQYOvdbOZ+s8M\nJdy0Z/ic+QHD8m2xrDxOu7B+b415x3V9L1ExLc2uMuXSqNVOUlS5H4EolKxHKkd+\nR8W5G4E5OxTE81DIvT74Gp6FAcQJLUXYTsHg5P0ghQ0JkypGMuoy\n-----END CERTIFICATE-----\n', 1331737604, 0, 0, 0, 0, 0, '', 1),
(2, 0, '', '', 'All Hosts', '', 0, 0, 0, 0, 0, 0, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_mnet_host2service`
--

CREATE TABLE IF NOT EXISTS `mdl_mnet_host2service` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `hostid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `serviceid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `publish` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subscribe` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_mnethost_hosser_uix` (`hostid`,`serviceid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Information about the services for a given host' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_mnet_host2service`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_mnet_log`
--

CREATE TABLE IF NOT EXISTS `mdl_mnet_log` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `hostid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `remoteid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `time` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `coursename` varchar(40) NOT NULL DEFAULT '',
  `module` varchar(20) NOT NULL DEFAULT '',
  `cmid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `action` varchar(40) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL DEFAULT '',
  `info` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_mnetlog_hosusecou_ix` (`hostid`,`userid`,`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Store session data from users migrating to other sites' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_mnet_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_mnet_rpc`
--

CREATE TABLE IF NOT EXISTS `mdl_mnet_rpc` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `function_name` varchar(40) NOT NULL DEFAULT '',
  `xmlrpc_path` varchar(80) NOT NULL DEFAULT '',
  `parent_type` varchar(6) NOT NULL DEFAULT '',
  `parent` varchar(20) NOT NULL DEFAULT '',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `help` mediumtext NOT NULL,
  `profile` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_mnetrpc_enaxml_ix` (`enabled`,`xmlrpc_path`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Functions or methods that we may publish or subscribe to' AUTO_INCREMENT=15 ;

--
-- Dumping data for table `mdl_mnet_rpc`
--

INSERT INTO `mdl_mnet_rpc` (`id`, `function_name`, `xmlrpc_path`, `parent_type`, `parent`, `enabled`, `help`, `profile`) VALUES
(1, 'user_authorise', 'auth/mnet/auth.php/user_authorise', 'auth', 'mnet', 0, 'Return user data for the provided token, compare with user_agent string.', 'a:3:{i:0;a:2:{s:4:"type";s:5:"array";s:11:"description";s:44:"$userdata Array of user info for remote host";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:45:"token - The unique ID provided by remotehost.";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"useragent - User Agent string.";}}'),
(2, 'keepalive_server', 'auth/mnet/auth.php/keepalive_server', 'auth', 'mnet', 0, 'Receives an array of usernames from a remote machine and prods their\\n sessions to keep them alive', 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"\\"All ok\\" or an error message";}i:1;a:2:{s:4:"type";s:5:"array";s:11:"description";s:29:"array - An array of usernames";}}'),
(3, 'kill_children', 'auth/mnet/auth.php/kill_children', 'auth', 'mnet', 0, 'The IdP uses this function to kill child sessions on other hosts', 'a:3:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"A plaintext report of what has happened";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"username - Username for session to kill";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"useragent - SHA1 hash of user agent to look for";}}'),
(4, 'refresh_log', 'auth/mnet/auth.php/refresh_log', 'auth', 'mnet', 0, 'Receives an array of log entries from an SP and adds them to the mnet_log\\n table', 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"\\"All ok\\" or an error message";}i:1;a:2:{s:4:"type";s:5:"array";s:11:"description";s:29:"array - An array of usernames";}}'),
(5, 'fetch_user_image', 'auth/mnet/auth.php/fetch_user_image', 'auth', 'mnet', 0, 'Returns the user''s image as a base64 encoded string.', 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:17:"The encoded image";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:29:"username - The id of the user";}}'),
(6, 'fetch_theme_info', 'auth/mnet/auth.php/fetch_theme_info', 'auth', 'mnet', 0, 'Returns the theme information and logo url as strings.', 'a:1:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:14:"The theme info";}}'),
(7, 'update_enrolments', 'auth/mnet/auth.php/update_enrolments', 'auth', 'mnet', 0, 'Invoke this function _on_ the IDP to update it with enrolment info local to\\n the SP right after calling user_authorise()\\n \\n Normally called by the SP after calling', 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";N;}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:23:"username - The username";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:77:"courses - Assoc array of courses following the structure of mnet_enrol_course";}}'),
(8, 'keepalive_client', 'auth/mnet/auth.php/keepalive_client', 'auth', 'mnet', 0, 'Poll the IdP server to let it know that a user it has authenticated is still\\n online', 'a:1:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";N;}}'),
(9, 'kill_child', 'auth/mnet/auth.php/kill_child', 'auth', 'mnet', 0, 'TODO:Untested When the IdP requests that child sessions are terminated,\\n this function will be called on each of the child hosts. The machine that\\n calls the function (over xmlrpc) provides us with the mnethostid we need.', 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:15:"True on success";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"username - Username for session to kill";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"useragent - SHA1 hash of user agent to look for";}}'),
(10, 'available_courses', 'enrol/mnet/enrol.php/available_courses', 'enrol', 'mnet', 0, 'Does Foo', 'a:1:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:47:"Whether the user can login from the remote host";}}'),
(11, 'user_enrolments', 'enrol/mnet/enrol.php/user_enrolments', 'enrol', 'mnet', 0, 'No description given.', 'a:2:{i:0;a:2:{s:4:"type";s:4:"void";s:11:"description";s:0:"";}i:1;s:6:"userid";}'),
(12, 'enrol_user', 'enrol/mnet/enrol.php/enrol_user', 'enrol', 'mnet', 0, 'Enrols user to course with the default role', 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:41:"Whether the enrolment has been successful";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:37:"user - The username of the remote use";}i:2;a:2:{s:4:"type";s:3:"int";s:11:"description";s:37:"courseid - The id of the local course";}}'),
(13, 'unenrol_user', 'enrol/mnet/enrol.php/unenrol_user', 'enrol', 'mnet', 0, 'Unenrol a user from a course', 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:47:"Whether the user can login from the remote host";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:23:"username - The username";}i:2;a:2:{s:4:"type";s:3:"int";s:11:"description";s:37:"courseid - The id of the local course";}}'),
(14, 'course_enrolments', 'enrol/mnet/enrol.php/course_enrolments', 'enrol', 'mnet', 0, 'Get a list of users from the client server who are enrolled in a course', 'a:3:{i:0;a:2:{s:4:"type";s:5:"array";s:11:"description";s:39:"Array of usernames who are homed on the";}i:1;a:2:{s:4:"type";s:3:"int";s:11:"description";s:24:"courseid - The Course ID";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"roles - Comma-separated list of role shortnames";}}');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_mnet_service`
--

CREATE TABLE IF NOT EXISTS `mdl_mnet_service` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `description` varchar(40) NOT NULL DEFAULT '',
  `apiversion` varchar(10) NOT NULL DEFAULT '',
  `offer` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='A service is a group of functions' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mdl_mnet_service`
--

INSERT INTO `mdl_mnet_service` (`id`, `name`, `description`, `apiversion`, `offer`) VALUES
(1, 'sso_idp', '', '1', 1),
(2, 'sso_sp', '', '1', 1),
(3, 'mnet_enrol', '', '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_mnet_service2rpc`
--

CREATE TABLE IF NOT EXISTS `mdl_mnet_service2rpc` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `serviceid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `rpcid` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_mnetserv_rpcser_uix` (`rpcid`,`serviceid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Group functions or methods under a service' AUTO_INCREMENT=15 ;

--
-- Dumping data for table `mdl_mnet_service2rpc`
--

INSERT INTO `mdl_mnet_service2rpc` (`id`, `serviceid`, `rpcid`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 2, 8),
(9, 2, 9),
(10, 3, 10),
(11, 3, 11),
(12, 3, 12),
(13, 3, 13),
(14, 3, 14);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_mnet_session`
--

CREATE TABLE IF NOT EXISTS `mdl_mnet_session` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL DEFAULT '',
  `token` varchar(40) NOT NULL DEFAULT '',
  `mnethostid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `useragent` varchar(40) NOT NULL DEFAULT '',
  `confirm_timeout` bigint(10) unsigned NOT NULL DEFAULT '0',
  `session_id` varchar(40) NOT NULL DEFAULT '',
  `expires` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_mnetsess_tok_uix` (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Store session data from users migrating to other sites' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_mnet_session`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_mnet_sso_access_control`
--

CREATE TABLE IF NOT EXISTS `mdl_mnet_sso_access_control` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `mnet_host_id` bigint(10) unsigned NOT NULL DEFAULT '0',
  `accessctrl` varchar(20) NOT NULL DEFAULT 'allow',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_mnetssoaccecont_mneuse_uix` (`mnet_host_id`,`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Users by host permitted (or not) to login from a remote prov' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_mnet_sso_access_control`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_modules`
--

CREATE TABLE IF NOT EXISTS `mdl_modules` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `version` bigint(10) NOT NULL DEFAULT '0',
  `cron` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lastcron` bigint(10) unsigned NOT NULL DEFAULT '0',
  `search` varchar(255) NOT NULL DEFAULT '',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `mdl_modu_nam_ix` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='modules available in the site' AUTO_INCREMENT=21 ;

--
-- Dumping data for table `mdl_modules`
--

INSERT INTO `mdl_modules` (`id`, `name`, `version`, `cron`, `lastcron`, `search`, `visible`) VALUES
(1, 'assignment', 2007101511, 60, 0, '', 1),
(2, 'chat', 2009031100, 300, 0, '', 1),
(3, 'choice', 2007101509, 0, 0, '', 1),
(4, 'data', 2007101515, 60, 0, '', 1),
(5, 'forum', 2007101513, 60, 0, '', 1),
(6, 'glossary', 2007101509, 0, 0, '', 1),
(7, 'hotpot', 2007101513, 0, 0, '', 0),
(8, 'journal', 2007101509, 60, 0, '', 0),
(9, 'label', 2007101510, 0, 0, '', 1),
(10, 'lams', 2007101509, 0, 0, '', 0),
(11, 'lesson', 2008112601, 0, 0, '', 1),
(12, 'quiz', 2007101511, 0, 0, '', 1),
(13, 'resource', 2007101511, 0, 0, '', 1),
(14, 'scorm', 2007110503, 300, 0, '', 1),
(15, 'survey', 2007101509, 0, 0, '', 1),
(16, 'wiki', 2007101509, 3600, 0, '', 1),
(17, 'workshop', 2007101510, 60, 0, '', 0),
(20, 'soda', 2011101601, 0, 0, '', 0),
(19, 'launcher', 2012030201, 0, 0, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_post`
--

CREATE TABLE IF NOT EXISTS `mdl_post` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(20) NOT NULL DEFAULT '',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `groupid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `moduleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `coursemoduleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(128) NOT NULL DEFAULT '',
  `summary` longtext,
  `content` longtext,
  `uniquehash` varchar(128) NOT NULL DEFAULT '',
  `rating` bigint(10) unsigned NOT NULL DEFAULT '0',
  `format` bigint(10) unsigned NOT NULL DEFAULT '0',
  `attachment` varchar(100) DEFAULT NULL,
  `publishstate` enum('draft','site','public') NOT NULL DEFAULT 'draft',
  `lastmodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `created` bigint(10) unsigned NOT NULL DEFAULT '0',
  `usermodified` bigint(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_post_iduse_uix` (`id`,`userid`),
  KEY `mdl_post_las_ix` (`lastmodified`),
  KEY `mdl_post_mod_ix` (`module`),
  KEY `mdl_post_sub_ix` (`subject`),
  KEY `mdl_post_use_ix` (`usermodified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Generic post table to hold data blog entries etc in differen' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_post`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question`
--

CREATE TABLE IF NOT EXISTS `mdl_question` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` bigint(10) NOT NULL DEFAULT '0',
  `parent` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `questiontext` text NOT NULL,
  `questiontextformat` tinyint(2) NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL DEFAULT '',
  `generalfeedback` text NOT NULL,
  `defaultgrade` bigint(10) unsigned NOT NULL DEFAULT '1',
  `penalty` double NOT NULL DEFAULT '0.1',
  `qtype` varchar(20) NOT NULL DEFAULT '',
  `length` bigint(10) unsigned NOT NULL DEFAULT '1',
  `stamp` varchar(255) NOT NULL DEFAULT '',
  `version` varchar(255) NOT NULL DEFAULT '',
  `hidden` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `createdby` bigint(10) unsigned DEFAULT NULL,
  `modifiedby` bigint(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_ques_cat_ix` (`category`),
  KEY `mdl_ques_par_ix` (`parent`),
  KEY `mdl_ques_cre_ix` (`createdby`),
  KEY `mdl_ques_mod_ix` (`modifiedby`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='The questions themselves' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_answers`
--

CREATE TABLE IF NOT EXISTS `mdl_question_answers` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `answer` text NOT NULL,
  `fraction` double NOT NULL DEFAULT '0',
  `feedback` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_quesansw_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Answers, with a fractional grade (0-1) and feedback' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_answers`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_attempts`
--

CREATE TABLE IF NOT EXISTS `mdl_question_attempts` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `modulename` varchar(20) NOT NULL DEFAULT 'quiz',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Student attempts. This table gets extended by the modules' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_attempts`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_calculated`
--

CREATE TABLE IF NOT EXISTS `mdl_question_calculated` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `answer` bigint(10) unsigned NOT NULL DEFAULT '0',
  `tolerance` varchar(20) NOT NULL DEFAULT '0.0',
  `tolerancetype` bigint(10) NOT NULL DEFAULT '1',
  `correctanswerlength` bigint(10) NOT NULL DEFAULT '2',
  `correctanswerformat` bigint(10) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`),
  KEY `mdl_quescalc_ans_ix` (`answer`),
  KEY `mdl_quescalc_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for questions of type calculated' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_calculated`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_categories`
--

CREATE TABLE IF NOT EXISTS `mdl_question_categories` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contextid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `info` text NOT NULL,
  `stamp` varchar(255) NOT NULL DEFAULT '',
  `parent` bigint(10) unsigned NOT NULL DEFAULT '0',
  `sortorder` bigint(10) unsigned NOT NULL DEFAULT '999',
  PRIMARY KEY (`id`),
  KEY `mdl_quescate_con_ix` (`contextid`),
  KEY `mdl_quescate_par_ix` (`parent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Categories are for grouping questions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_datasets`
--

CREATE TABLE IF NOT EXISTS `mdl_question_datasets` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `datasetdefinition` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_quesdata_quedat_ix` (`question`,`datasetdefinition`),
  KEY `mdl_quesdata_que_ix` (`question`),
  KEY `mdl_quesdata_dat_ix` (`datasetdefinition`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Many-many relation between questions and dataset definitions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_datasets`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_dataset_definitions`
--

CREATE TABLE IF NOT EXISTS `mdl_question_dataset_definitions` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` bigint(10) NOT NULL DEFAULT '0',
  `options` varchar(255) NOT NULL DEFAULT '',
  `itemcount` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_quesdatadefi_cat_ix` (`category`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Organises and stores properties for dataset items' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_dataset_definitions`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_dataset_items`
--

CREATE TABLE IF NOT EXISTS `mdl_question_dataset_items` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `definition` bigint(10) unsigned NOT NULL DEFAULT '0',
  `itemnumber` bigint(10) unsigned NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_quesdataitem_def_ix` (`definition`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Individual dataset items' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_dataset_items`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_match`
--

CREATE TABLE IF NOT EXISTS `mdl_question_match` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `subquestions` varchar(255) NOT NULL DEFAULT '',
  `shuffleanswers` smallint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `mdl_quesmatc_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines fixed matching questions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_match`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_match_sub`
--

CREATE TABLE IF NOT EXISTS `mdl_question_match_sub` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` bigint(10) unsigned NOT NULL DEFAULT '0',
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `questiontext` text NOT NULL,
  `answertext` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_quesmatcsub_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines the subquestions that make up a matching question' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_match_sub`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_multianswer`
--

CREATE TABLE IF NOT EXISTS `mdl_question_multianswer` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `sequence` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_quesmult_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for multianswer questions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_multianswer`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_multichoice`
--

CREATE TABLE IF NOT EXISTS `mdl_question_multichoice` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `layout` smallint(4) NOT NULL DEFAULT '0',
  `answers` varchar(255) NOT NULL DEFAULT '',
  `single` smallint(4) NOT NULL DEFAULT '0',
  `shuffleanswers` smallint(4) NOT NULL DEFAULT '1',
  `correctfeedback` text NOT NULL,
  `partiallycorrectfeedback` text NOT NULL,
  `incorrectfeedback` text NOT NULL,
  `answernumbering` varchar(10) NOT NULL DEFAULT 'abc',
  PRIMARY KEY (`id`),
  KEY `mdl_quesmult_que2_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for multiple choice questions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_multichoice`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_numerical`
--

CREATE TABLE IF NOT EXISTS `mdl_question_numerical` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `answer` bigint(10) unsigned NOT NULL DEFAULT '0',
  `tolerance` varchar(255) NOT NULL DEFAULT '0.0',
  PRIMARY KEY (`id`),
  KEY `mdl_quesnume_ans_ix` (`answer`),
  KEY `mdl_quesnume_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for numerical questions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_numerical`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_numerical_units`
--

CREATE TABLE IF NOT EXISTS `mdl_question_numerical_units` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `multiplier` decimal(40,20) NOT NULL DEFAULT '1.00000000000000000000',
  `unit` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_quesnumeunit_queuni_uix` (`question`,`unit`),
  KEY `mdl_quesnumeunit_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Optional unit options for numerical questions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_numerical_units`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_randomsamatch`
--

CREATE TABLE IF NOT EXISTS `mdl_question_randomsamatch` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `choose` bigint(10) unsigned NOT NULL DEFAULT '4',
  PRIMARY KEY (`id`),
  KEY `mdl_quesrand_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about a random short-answer matching question' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_randomsamatch`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_sessions`
--

CREATE TABLE IF NOT EXISTS `mdl_question_sessions` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `attemptid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `questionid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `newest` bigint(10) unsigned NOT NULL DEFAULT '0',
  `newgraded` bigint(10) unsigned NOT NULL DEFAULT '0',
  `sumpenalty` double NOT NULL DEFAULT '0',
  `manualcomment` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_quessess_attque_uix` (`attemptid`,`questionid`),
  KEY `mdl_quessess_att_ix` (`attemptid`),
  KEY `mdl_quessess_que_ix` (`questionid`),
  KEY `mdl_quessess_new_ix` (`newest`),
  KEY `mdl_quessess_new2_ix` (`newgraded`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Gives ids of the newest open and newest graded states' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_shortanswer`
--

CREATE TABLE IF NOT EXISTS `mdl_question_shortanswer` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `answers` varchar(255) NOT NULL DEFAULT '',
  `usecase` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_quesshor_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for short answer questions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_shortanswer`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_states`
--

CREATE TABLE IF NOT EXISTS `mdl_question_states` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `attempt` bigint(10) unsigned NOT NULL DEFAULT '0',
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `originalquestion` bigint(10) unsigned NOT NULL DEFAULT '0',
  `seq_number` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `answer` text NOT NULL,
  `timestamp` bigint(10) unsigned NOT NULL DEFAULT '0',
  `event` smallint(4) unsigned NOT NULL DEFAULT '0',
  `grade` double NOT NULL DEFAULT '0',
  `raw_grade` double NOT NULL DEFAULT '0',
  `penalty` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_quesstat_att_ix` (`attempt`),
  KEY `mdl_quesstat_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores user responses to an attempt, and percentage grades' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_states`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_question_truefalse`
--

CREATE TABLE IF NOT EXISTS `mdl_question_truefalse` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `trueanswer` bigint(10) unsigned NOT NULL DEFAULT '0',
  `falseanswer` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_questrue_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for True-False questions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_question_truefalse`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_quiz`
--

CREATE TABLE IF NOT EXISTS `mdl_quiz` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `intro` text NOT NULL,
  `timeopen` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeclose` bigint(10) unsigned NOT NULL DEFAULT '0',
  `optionflags` bigint(10) unsigned NOT NULL DEFAULT '0',
  `penaltyscheme` smallint(4) unsigned NOT NULL DEFAULT '0',
  `attempts` mediumint(6) NOT NULL DEFAULT '0',
  `attemptonlast` smallint(4) NOT NULL DEFAULT '0',
  `grademethod` smallint(4) NOT NULL DEFAULT '1',
  `decimalpoints` smallint(4) NOT NULL DEFAULT '2',
  `review` bigint(10) unsigned NOT NULL DEFAULT '0',
  `questionsperpage` bigint(10) NOT NULL DEFAULT '0',
  `shufflequestions` smallint(4) NOT NULL DEFAULT '0',
  `shuffleanswers` smallint(4) NOT NULL DEFAULT '0',
  `questions` text NOT NULL,
  `sumgrades` bigint(10) NOT NULL DEFAULT '0',
  `grade` bigint(10) NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timelimit` bigint(10) unsigned NOT NULL DEFAULT '0',
  `password` varchar(255) NOT NULL DEFAULT '',
  `subnet` varchar(255) NOT NULL DEFAULT '',
  `popup` smallint(4) NOT NULL DEFAULT '0',
  `delay1` bigint(10) NOT NULL DEFAULT '0',
  `delay2` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_quiz_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Main information about each quiz' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_quiz`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_quiz_attempts`
--

CREATE TABLE IF NOT EXISTS `mdl_quiz_attempts` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniqueid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `quiz` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `attempt` mediumint(6) NOT NULL DEFAULT '0',
  `sumgrades` double NOT NULL DEFAULT '0',
  `timestart` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timefinish` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `layout` text NOT NULL,
  `preview` smallint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_quizatte_uni_uix` (`uniqueid`),
  KEY `mdl_quizatte_use_ix` (`userid`),
  KEY `mdl_quizatte_qui_ix` (`quiz`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores various attempts on a quiz' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_quiz_attempts`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_quiz_feedback`
--

CREATE TABLE IF NOT EXISTS `mdl_quiz_feedback` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `quizid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `feedbacktext` text NOT NULL,
  `mingrade` double NOT NULL DEFAULT '0',
  `maxgrade` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_quizfeed_qui_ix` (`quizid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Feedback given to students based on their overall score on t' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_quiz_feedback`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_quiz_grades`
--

CREATE TABLE IF NOT EXISTS `mdl_quiz_grades` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `quiz` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `grade` double NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_quizgrad_use_ix` (`userid`),
  KEY `mdl_quizgrad_qui_ix` (`quiz`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Final quiz grade (may be best of several attempts)' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_quiz_grades`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_quiz_question_instances`
--

CREATE TABLE IF NOT EXISTS `mdl_quiz_question_instances` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `quiz` bigint(10) unsigned NOT NULL DEFAULT '0',
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `grade` mediumint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_quizquesinst_qui_ix` (`quiz`),
  KEY `mdl_quizquesinst_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='The grade for a question in a quiz' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_quiz_question_instances`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_quiz_question_versions`
--

CREATE TABLE IF NOT EXISTS `mdl_quiz_question_versions` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `quiz` bigint(10) unsigned NOT NULL DEFAULT '0',
  `oldquestion` bigint(10) unsigned NOT NULL DEFAULT '0',
  `newquestion` bigint(10) unsigned NOT NULL DEFAULT '0',
  `originalquestion` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timestamp` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_quizquesvers_qui_ix` (`quiz`),
  KEY `mdl_quizquesvers_old_ix` (`oldquestion`),
  KEY `mdl_quizquesvers_new_ix` (`newquestion`),
  KEY `mdl_quizquesvers_ori_ix` (`originalquestion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='quiz_question_versions table retrofitted from MySQL' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_quiz_question_versions`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_resource`
--

CREATE TABLE IF NOT EXISTS `mdl_resource` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(30) NOT NULL DEFAULT '',
  `reference` varchar(255) NOT NULL DEFAULT '',
  `summary` text,
  `alltext` mediumtext NOT NULL,
  `popup` text NOT NULL,
  `options` varchar(255) NOT NULL DEFAULT '',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_reso_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='each record is one resource and its config data' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_role`
--

CREATE TABLE IF NOT EXISTS `mdl_role` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `shortname` varchar(100) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `sortorder` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_role_sor_uix` (`sortorder`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='moodle roles' AUTO_INCREMENT=12 ;

--
-- Dumping data for table `mdl_role`
--

INSERT INTO `mdl_role` (`id`, `name`, `shortname`, `description`, `sortorder`) VALUES
(1, 'Administrator', 'admin', 'Administrators can usually do anything on the site, in all courses.', 0),
(2, 'Course creator', 'coursecreator', 'Course creators can create new courses.', 1),
(3, 'Teacher', 'editingteacher', 'Teachers can do anything within a course, including changing the activities and grading students.', 2),
(4, 'Non-editing teacher', 'teacher', 'Non-editing teachers can teach in courses and grade students, but may not alter activities.', 3),
(5, 'Student', 'student', 'Students generally have fewer privileges within a course.', 4),
(6, 'Guest', 'guest', 'Guests have minimal privileges and usually can not enter text anywhere.', 5),
(7, 'Authenticated user', 'user', 'All logged in users.', 6),
(9, 'Substitute', 'substitute', ' Substitute is a duplicate of Non-editing teacher. Substitutes get enrolled in all courses.<br /> ', 7),
(11, 'School leader', 'schoolleader', 'School leader is a duplicate of Non-editing teacher.<br />A school leader gets enrolled in all courses.<br /> ', 8);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_role_allow_assign`
--

CREATE TABLE IF NOT EXISTS `mdl_role_allow_assign` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `roleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `allowassign` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_rolealloassi_rolall_uix` (`roleid`,`allowassign`),
  KEY `mdl_rolealloassi_rol_ix` (`roleid`),
  KEY `mdl_rolealloassi_all_ix` (`allowassign`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='this defines what role can assign what role' AUTO_INCREMENT=18 ;

--
-- Dumping data for table `mdl_role_allow_assign`
--

INSERT INTO `mdl_role_allow_assign` (`id`, `roleid`, `allowassign`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 4),
(4, 1, 3),
(5, 1, 5),
(6, 1, 6),
(7, 2, 4),
(8, 2, 3),
(9, 2, 5),
(10, 2, 6),
(11, 3, 4),
(12, 3, 5),
(13, 3, 6),
(15, 1, 9),
(17, 1, 11);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_role_allow_override`
--

CREATE TABLE IF NOT EXISTS `mdl_role_allow_override` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `roleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `allowoverride` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_rolealloover_rolall_uix` (`roleid`,`allowoverride`),
  KEY `mdl_rolealloover_rol_ix` (`roleid`),
  KEY `mdl_rolealloover_all_ix` (`allowoverride`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='this defines what role can override what role' AUTO_INCREMENT=12 ;

--
-- Dumping data for table `mdl_role_allow_override`
--

INSERT INTO `mdl_role_allow_override` (`id`, `roleid`, `allowoverride`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 4),
(4, 1, 3),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(9, 1, 9),
(11, 1, 11);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_role_assignments`
--

CREATE TABLE IF NOT EXISTS `mdl_role_assignments` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `roleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `contextid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `hidden` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `timestart` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeend` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `modifierid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `enrol` varchar(20) NOT NULL DEFAULT '',
  `sortorder` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_roleassi_conroluse_uix` (`contextid`,`roleid`,`userid`),
  KEY `mdl_roleassi_sor_ix` (`sortorder`),
  KEY `mdl_roleassi_rol_ix` (`roleid`),
  KEY `mdl_roleassi_con_ix` (`contextid`),
  KEY `mdl_roleassi_use_ix` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='assigning roles to different context' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mdl_role_assignments`
--

INSERT INTO `mdl_role_assignments` (`id`, `roleid`, `contextid`, `userid`, `hidden`, `timestart`, `timeend`, `timemodified`, `modifierid`, `enrol`, `sortorder`) VALUES
(1, 1, 1, 2, 0, 0, 0, 1323876931, 0, 'manual', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_role_capabilities`
--

CREATE TABLE IF NOT EXISTS `mdl_role_capabilities` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `contextid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `roleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `capability` varchar(255) NOT NULL DEFAULT '',
  `permission` bigint(10) NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `modifierid` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_rolecapa_rolconcap_uix` (`roleid`,`contextid`,`capability`),
  KEY `mdl_rolecapa_rol_ix` (`roleid`),
  KEY `mdl_rolecapa_con_ix` (`contextid`),
  KEY `mdl_rolecapa_mod_ix` (`modifierid`),
  KEY `mdl_rolecapa_cap_ix` (`capability`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='permission has to be signed, overriding a capability for a p' AUTO_INCREMENT=998 ;

--
-- Dumping data for table `mdl_role_capabilities`
--

INSERT INTO `mdl_role_capabilities` (`id`, `contextid`, `roleid`, `capability`, `permission`, `timemodified`, `modifierid`) VALUES
(1, 1, 1, 'moodle/legacy:admin', 1, 1323876844, 0),
(2, 1, 2, 'moodle/legacy:coursecreator', 1, 1323876844, 0),
(3, 1, 3, 'moodle/legacy:editingteacher', 1, 1323876844, 0),
(4, 1, 4, 'moodle/legacy:teacher', 1, 1323876844, 0),
(5, 1, 5, 'moodle/legacy:student', 1, 1323876844, 0),
(6, 1, 6, 'moodle/legacy:guest', 1, 1323876844, 0),
(7, 1, 7, 'moodle/legacy:user', 1, 1323876844, 0),
(8, 1, 1, 'moodle/site:doanything', 1, 1323876844, 0),
(9, 1, 1, 'moodle/site:config', 1, 1323876844, 0),
(10, 1, 1, 'moodle/site:readallmessages', 1, 1323876844, 0),
(11, 1, 3, 'moodle/site:readallmessages', 1, 1323876844, 0),
(12, 1, 1, 'moodle/site:sendmessage', 1, 1323876844, 0),
(13, 1, 7, 'moodle/site:sendmessage', 1, 1323876844, 0),
(14, 1, 1, 'moodle/site:approvecourse', 1, 1323876844, 0),
(15, 1, 3, 'moodle/site:import', 1, 1323876844, 0),
(16, 1, 1, 'moodle/site:import', 1, 1323876844, 0),
(17, 1, 3, 'moodle/site:backup', 1, 1323876844, 0),
(18, 1, 1, 'moodle/site:backup', 1, 1323876844, 0),
(19, 1, 1, 'moodle/backup:userinfo', 1, 1323876844, 0),
(20, 1, 3, 'moodle/site:restore', 1, 1323876844, 0),
(21, 1, 1, 'moodle/site:restore', 1, 1323876844, 0),
(22, 1, 1, 'moodle/restore:createuser', 1, 1323876844, 0),
(23, 1, 1, 'moodle/restore:userinfo', 1, 1323876844, 0),
(24, 1, 2, 'moodle/restore:rolldates', 1, 1323876844, 0),
(25, 1, 1, 'moodle/restore:rolldates', 1, 1323876844, 0),
(26, 1, 3, 'moodle/site:manageblocks', 1, 1323876844, 0),
(27, 1, 1, 'moodle/site:manageblocks', 1, 1323876844, 0),
(28, 1, 4, 'moodle/site:accessallgroups', 1, 1323876844, 0),
(29, 1, 3, 'moodle/site:accessallgroups', 1, 1323876844, 0),
(30, 1, 1, 'moodle/site:accessallgroups', 1, 1323876844, 0),
(31, 1, 4, 'moodle/site:viewfullnames', 1, 1323876844, 0),
(32, 1, 3, 'moodle/site:viewfullnames', 1, 1323876844, 0),
(33, 1, 1, 'moodle/site:viewfullnames', 1, 1323876844, 0),
(34, 1, 4, 'moodle/site:viewreports', 1, 1323876844, 0),
(35, 1, 3, 'moodle/site:viewreports', 1, 1323876844, 0),
(36, 1, 1, 'moodle/site:viewreports', 1, 1323876844, 0),
(37, 1, 3, 'moodle/site:trustcontent', 1, 1323876844, 0),
(38, 1, 1, 'moodle/site:trustcontent', 1, 1323876844, 0),
(39, 1, 1, 'moodle/site:uploadusers', 1, 1323876844, 0),
(40, 1, 1, 'moodle/site:langeditmaster', -1, 1323876844, 0),
(41, 1, 1, 'moodle/site:langeditlocal', 1, 1323876844, 0),
(42, 1, 1, 'moodle/user:create', 1, 1323876844, 0),
(43, 1, 1, 'moodle/user:delete', 1, 1323876844, 0),
(44, 1, 1, 'moodle/user:update', 1, 1323876844, 0),
(45, 1, 6, 'moodle/user:viewdetails', 1, 1323876844, 0),
(46, 1, 5, 'moodle/user:viewdetails', 1, 1323876844, 0),
(47, 1, 4, 'moodle/user:viewdetails', 1, 1323876844, 0),
(48, 1, 3, 'moodle/user:viewdetails', 1, 1323876844, 0),
(49, 1, 1, 'moodle/user:viewdetails', 1, 1323876844, 0),
(50, 1, 4, 'moodle/user:viewhiddendetails', 1, 1323876844, 0),
(51, 1, 3, 'moodle/user:viewhiddendetails', 1, 1323876844, 0),
(52, 1, 1, 'moodle/user:viewhiddendetails', 1, 1323876844, 0),
(53, 1, 1, 'moodle/user:loginas', 1, 1323876844, 0),
(54, 1, 3, 'moodle/role:assign', 1, 1323876844, 0),
(55, 1, 1, 'moodle/role:assign', 1, 1323876844, 0),
(56, 1, 1, 'moodle/role:override', 1, 1323876844, 0),
(57, 1, 3, 'moodle/role:safeoverride', 1, 1323876844, 0),
(58, 1, 1, 'moodle/role:manage', 1, 1323876844, 0),
(59, 1, 4, 'moodle/role:unassignself', 1, 1323876844, 0),
(60, 1, 3, 'moodle/role:unassignself', 1, 1323876844, 0),
(61, 1, 2, 'moodle/role:unassignself', 1, 1323876844, 0),
(62, 1, 1, 'moodle/role:unassignself', 1, 1323876844, 0),
(63, 1, 4, 'moodle/role:viewhiddenassigns', 1, 1323876844, 0),
(64, 1, 3, 'moodle/role:viewhiddenassigns', 1, 1323876844, 0),
(65, 1, 1, 'moodle/role:viewhiddenassigns', 1, 1323876844, 0),
(66, 1, 3, 'moodle/role:switchroles', 1, 1323876844, 0),
(67, 1, 1, 'moodle/role:switchroles', 1, 1323876844, 0),
(68, 1, 1, 'moodle/category:manage', 1, 1323876844, 0),
(69, 1, 2, 'moodle/category:viewhiddencategories', 1, 1323876844, 0),
(70, 1, 1, 'moodle/category:viewhiddencategories', 1, 1323876844, 0),
(71, 1, 2, 'moodle/course:create', 1, 1323876844, 0),
(72, 1, 1, 'moodle/course:create', 1, 1323876844, 0),
(73, 1, 7, 'moodle/course:request', 1, 1323876844, 0),
(74, 1, 1, 'moodle/course:delete', 1, 1323876844, 0),
(75, 1, 3, 'moodle/course:update', 1, 1323876844, 0),
(76, 1, 1, 'moodle/course:update', 1, 1323876844, 0),
(77, 1, 6, 'moodle/course:view', 1, 1323876844, 0),
(78, 1, 5, 'moodle/course:view', 1, 1323876844, 0),
(79, 1, 4, 'moodle/course:view', 1, 1323876844, 0),
(80, 1, 3, 'moodle/course:view', 1, 1323876844, 0),
(81, 1, 4, 'moodle/course:bulkmessaging', 1, 1323876844, 0),
(82, 1, 3, 'moodle/course:bulkmessaging', 1, 1323876844, 0),
(83, 1, 1, 'moodle/course:bulkmessaging', 1, 1323876844, 0),
(84, 1, 4, 'moodle/course:viewhiddenuserfields', 1, 1323876844, 0),
(85, 1, 3, 'moodle/course:viewhiddenuserfields', 1, 1323876844, 0),
(86, 1, 1, 'moodle/course:viewhiddenuserfields', 1, 1323876844, 0),
(87, 1, 2, 'moodle/course:viewhiddencourses', 1, 1323876844, 0),
(88, 1, 4, 'moodle/course:viewhiddencourses', 1, 1323876844, 0),
(89, 1, 3, 'moodle/course:viewhiddencourses', 1, 1323876844, 0),
(90, 1, 1, 'moodle/course:viewhiddencourses', 1, 1323876844, 0),
(91, 1, 3, 'moodle/course:visibility', 1, 1323876844, 0),
(92, 1, 1, 'moodle/course:visibility', 1, 1323876844, 0),
(93, 1, 3, 'moodle/course:managefiles', 1, 1323876844, 0),
(94, 1, 1, 'moodle/course:managefiles', 1, 1323876844, 0),
(95, 1, 3, 'moodle/course:manageactivities', 1, 1323876844, 0),
(96, 1, 1, 'moodle/course:manageactivities', 1, 1323876844, 0),
(97, 1, 3, 'moodle/course:managemetacourse', 1, 1323876844, 0),
(98, 1, 1, 'moodle/course:managemetacourse', 1, 1323876844, 0),
(99, 1, 3, 'moodle/course:activityvisibility', 1, 1323876844, 0),
(100, 1, 1, 'moodle/course:activityvisibility', 1, 1323876844, 0),
(101, 1, 4, 'moodle/course:viewhiddenactivities', 1, 1323876844, 0),
(102, 1, 3, 'moodle/course:viewhiddenactivities', 1, 1323876844, 0),
(103, 1, 1, 'moodle/course:viewhiddenactivities', 1, 1323876844, 0),
(104, 1, 5, 'moodle/course:viewparticipants', 1, 1323876844, 0),
(105, 1, 4, 'moodle/course:viewparticipants', 1, 1323876844, 0),
(106, 1, 3, 'moodle/course:viewparticipants', 1, 1323876844, 0),
(107, 1, 1, 'moodle/course:viewparticipants', 1, 1323876844, 0),
(108, 1, 3, 'moodle/course:changefullname', 1, 1323876844, 0),
(109, 1, 1, 'moodle/course:changefullname', 1, 1323876844, 0),
(110, 1, 3, 'moodle/course:changeshortname', 1, 1323876844, 0),
(111, 1, 1, 'moodle/course:changeshortname', 1, 1323876844, 0),
(112, 1, 3, 'moodle/course:changeidnumber', 1, 1323876844, 0),
(113, 1, 1, 'moodle/course:changeidnumber', 1, 1323876844, 0),
(114, 1, 3, 'moodle/course:changecategory', 1, 1323876844, 0),
(115, 1, 1, 'moodle/course:changecategory', 1, 1323876844, 0),
(116, 1, 3, 'moodle/course:changesummary', 1, 1323876844, 0),
(117, 1, 1, 'moodle/course:changesummary', 1, 1323876844, 0),
(118, 1, 1, 'moodle/site:viewparticipants', 1, 1323876844, 0),
(119, 1, 5, 'moodle/course:viewscales', 1, 1323876844, 0),
(120, 1, 4, 'moodle/course:viewscales', 1, 1323876844, 0),
(121, 1, 3, 'moodle/course:viewscales', 1, 1323876844, 0),
(122, 1, 1, 'moodle/course:viewscales', 1, 1323876844, 0),
(123, 1, 3, 'moodle/course:managescales', 1, 1323876844, 0),
(124, 1, 1, 'moodle/course:managescales', 1, 1323876844, 0),
(125, 1, 3, 'moodle/course:managegroups', 1, 1323876844, 0),
(126, 1, 1, 'moodle/course:managegroups', 1, 1323876844, 0),
(127, 1, 3, 'moodle/course:reset', 1, 1323876844, 0),
(128, 1, 1, 'moodle/course:reset', 1, 1323876844, 0),
(129, 1, 6, 'moodle/blog:view', 1, 1323876844, 0),
(130, 1, 7, 'moodle/blog:view', 1, 1323876844, 0),
(131, 1, 5, 'moodle/blog:view', 1, 1323876844, 0),
(132, 1, 4, 'moodle/blog:view', 1, 1323876844, 0),
(133, 1, 3, 'moodle/blog:view', 1, 1323876844, 0),
(134, 1, 1, 'moodle/blog:view', 1, 1323876844, 0),
(135, 1, 7, 'moodle/blog:create', 1, 1323876844, 0),
(136, 1, 1, 'moodle/blog:create', 1, 1323876844, 0),
(137, 1, 4, 'moodle/blog:manageentries', 1, 1323876844, 0),
(138, 1, 3, 'moodle/blog:manageentries', 1, 1323876844, 0),
(139, 1, 1, 'moodle/blog:manageentries', 1, 1323876844, 0),
(140, 1, 7, 'moodle/calendar:manageownentries', 1, 1323876844, 0),
(141, 1, 1, 'moodle/calendar:manageownentries', 1, 1323876844, 0),
(142, 1, 4, 'moodle/calendar:managegroupentries', 1, 1323876844, 0),
(143, 1, 3, 'moodle/calendar:managegroupentries', 1, 1323876844, 0),
(144, 1, 1, 'moodle/calendar:managegroupentries', 1, 1323876844, 0),
(145, 1, 4, 'moodle/calendar:manageentries', 1, 1323876844, 0),
(146, 1, 3, 'moodle/calendar:manageentries', 1, 1323876844, 0),
(147, 1, 1, 'moodle/calendar:manageentries', 1, 1323876844, 0),
(148, 1, 1, 'moodle/user:editprofile', 1, 1323876844, 0),
(149, 1, 6, 'moodle/user:editownprofile', -1000, 1323876844, 0),
(150, 1, 7, 'moodle/user:editownprofile', 1, 1323876844, 0),
(151, 1, 1, 'moodle/user:editownprofile', 1, 1323876844, 0),
(152, 1, 6, 'moodle/user:changeownpassword', -1000, 1323876844, 0),
(153, 1, 7, 'moodle/user:changeownpassword', 1, 1323876844, 0),
(154, 1, 1, 'moodle/user:changeownpassword', 1, 1323876844, 0),
(155, 1, 5, 'moodle/user:readuserposts', 1, 1323876844, 0),
(156, 1, 4, 'moodle/user:readuserposts', 1, 1323876844, 0),
(157, 1, 3, 'moodle/user:readuserposts', 1, 1323876844, 0),
(158, 1, 1, 'moodle/user:readuserposts', 1, 1323876844, 0),
(159, 1, 5, 'moodle/user:readuserblogs', 1, 1323876844, 0),
(160, 1, 4, 'moodle/user:readuserblogs', 1, 1323876844, 0),
(161, 1, 3, 'moodle/user:readuserblogs', 1, 1323876844, 0),
(162, 1, 1, 'moodle/user:readuserblogs', 1, 1323876844, 0),
(163, 1, 3, 'moodle/question:managecategory', 1, 1323876844, 0),
(164, 1, 1, 'moodle/question:managecategory', 1, 1323876844, 0),
(165, 1, 3, 'moodle/question:add', 1, 1323876844, 0),
(166, 1, 1, 'moodle/question:add', 1, 1323876844, 0),
(167, 1, 3, 'moodle/question:editmine', 1, 1323876844, 0),
(168, 1, 1, 'moodle/question:editmine', 1, 1323876844, 0),
(169, 1, 3, 'moodle/question:editall', 1, 1323876844, 0),
(170, 1, 1, 'moodle/question:editall', 1, 1323876844, 0),
(171, 1, 3, 'moodle/question:viewmine', 1, 1323876844, 0),
(172, 1, 1, 'moodle/question:viewmine', 1, 1323876844, 0),
(173, 1, 3, 'moodle/question:viewall', 1, 1323876844, 0),
(174, 1, 1, 'moodle/question:viewall', 1, 1323876844, 0),
(175, 1, 3, 'moodle/question:usemine', 1, 1323876844, 0),
(176, 1, 1, 'moodle/question:usemine', 1, 1323876844, 0),
(177, 1, 3, 'moodle/question:useall', 1, 1323876844, 0),
(178, 1, 1, 'moodle/question:useall', 1, 1323876844, 0),
(179, 1, 3, 'moodle/question:movemine', 1, 1323876844, 0),
(180, 1, 1, 'moodle/question:movemine', 1, 1323876844, 0),
(181, 1, 3, 'moodle/question:moveall', 1, 1323876844, 0),
(182, 1, 1, 'moodle/question:moveall', 1, 1323876845, 0),
(183, 1, 1, 'moodle/question:config', 1, 1323876845, 0),
(184, 1, 4, 'moodle/site:doclinks', 1, 1323876845, 0),
(185, 1, 3, 'moodle/site:doclinks', 1, 1323876845, 0),
(186, 1, 1, 'moodle/site:doclinks', 1, 1323876845, 0),
(187, 1, 3, 'moodle/course:sectionvisibility', 1, 1323876845, 0),
(188, 1, 1, 'moodle/course:sectionvisibility', 1, 1323876845, 0),
(189, 1, 3, 'moodle/course:useremail', 1, 1323876845, 0),
(190, 1, 1, 'moodle/course:useremail', 1, 1323876845, 0),
(191, 1, 3, 'moodle/course:viewhiddensections', 1, 1323876845, 0),
(192, 1, 1, 'moodle/course:viewhiddensections', 1, 1323876845, 0),
(193, 1, 3, 'moodle/course:setcurrentsection', 1, 1323876845, 0),
(194, 1, 1, 'moodle/course:setcurrentsection', 1, 1323876845, 0),
(195, 1, 1, 'moodle/site:mnetlogintoremote', 1, 1323876845, 0),
(196, 1, 4, 'moodle/grade:viewall', 1, 1323876845, 0),
(197, 1, 3, 'moodle/grade:viewall', 1, 1323876845, 0),
(198, 1, 1, 'moodle/grade:viewall', 1, 1323876845, 0),
(199, 1, 5, 'moodle/grade:view', 1, 1323876845, 0),
(200, 1, 4, 'moodle/grade:viewhidden', 1, 1323876845, 0),
(201, 1, 3, 'moodle/grade:viewhidden', 1, 1323876845, 0),
(202, 1, 1, 'moodle/grade:viewhidden', 1, 1323876845, 0),
(203, 1, 3, 'moodle/grade:import', 1, 1323876845, 0),
(204, 1, 1, 'moodle/grade:import', 1, 1323876845, 0),
(205, 1, 4, 'moodle/grade:export', 1, 1323876845, 0),
(206, 1, 3, 'moodle/grade:export', 1, 1323876845, 0),
(207, 1, 1, 'moodle/grade:export', 1, 1323876845, 0),
(208, 1, 3, 'moodle/grade:manage', 1, 1323876845, 0),
(209, 1, 1, 'moodle/grade:manage', 1, 1323876845, 0),
(210, 1, 3, 'moodle/grade:edit', 1, 1323876845, 0),
(211, 1, 1, 'moodle/grade:edit', 1, 1323876845, 0),
(212, 1, 3, 'moodle/grade:manageoutcomes', 1, 1323876845, 0),
(213, 1, 1, 'moodle/grade:manageoutcomes', 1, 1323876845, 0),
(214, 1, 3, 'moodle/grade:manageletters', 1, 1323876845, 0),
(215, 1, 1, 'moodle/grade:manageletters', 1, 1323876845, 0),
(216, 1, 3, 'moodle/grade:hide', 1, 1323876845, 0),
(217, 1, 1, 'moodle/grade:hide', 1, 1323876845, 0),
(218, 1, 3, 'moodle/grade:lock', 1, 1323876845, 0),
(219, 1, 1, 'moodle/grade:lock', 1, 1323876845, 0),
(220, 1, 3, 'moodle/grade:unlock', 1, 1323876845, 0),
(221, 1, 1, 'moodle/grade:unlock', 1, 1323876845, 0),
(222, 1, 7, 'moodle/my:manageblocks', 1, 1323876845, 0),
(223, 1, 4, 'moodle/notes:view', 1, 1323876845, 0),
(224, 1, 3, 'moodle/notes:view', 1, 1323876845, 0),
(225, 1, 1, 'moodle/notes:view', 1, 1323876845, 0),
(226, 1, 4, 'moodle/notes:manage', 1, 1323876845, 0),
(227, 1, 3, 'moodle/notes:manage', 1, 1323876845, 0),
(228, 1, 1, 'moodle/notes:manage', 1, 1323876845, 0),
(229, 1, 4, 'moodle/tag:manage', 1, 1323876845, 0),
(230, 1, 3, 'moodle/tag:manage', 1, 1323876845, 0),
(231, 1, 1, 'moodle/tag:manage', 1, 1323876845, 0),
(232, 1, 1, 'moodle/tag:create', 1, 1323876845, 0),
(233, 1, 7, 'moodle/tag:create', 1, 1323876845, 0),
(234, 1, 1, 'moodle/tag:edit', 1, 1323876845, 0),
(235, 1, 7, 'moodle/tag:edit', 1, 1323876845, 0),
(236, 1, 4, 'moodle/tag:editblocks', 1, 1323876845, 0),
(237, 1, 3, 'moodle/tag:editblocks', 1, 1323876845, 0),
(238, 1, 1, 'moodle/tag:editblocks', 1, 1323876845, 0),
(239, 1, 6, 'moodle/block:view', 1, 1323876845, 0),
(240, 1, 7, 'moodle/block:view', 1, 1323876845, 0),
(241, 1, 5, 'moodle/block:view', 1, 1323876845, 0),
(242, 1, 4, 'moodle/block:view', 1, 1323876845, 0),
(243, 1, 3, 'moodle/block:view', 1, 1323876845, 0),
(244, 1, 2, 'moodle/block:view', 1, 1323876845, 0),
(245, 1, 6, 'mod/assignment:view', 1, 1323876846, 0),
(246, 1, 5, 'mod/assignment:view', 1, 1323876846, 0),
(247, 1, 4, 'mod/assignment:view', 1, 1323876846, 0),
(248, 1, 3, 'mod/assignment:view', 1, 1323876846, 0),
(249, 1, 1, 'mod/assignment:view', 1, 1323876846, 0),
(250, 1, 5, 'mod/assignment:submit', 1, 1323876846, 0),
(251, 1, 4, 'mod/assignment:grade', 1, 1323876846, 0),
(252, 1, 3, 'mod/assignment:grade', 1, 1323876846, 0),
(253, 1, 1, 'mod/assignment:grade', 1, 1323876846, 0),
(254, 1, 5, 'mod/chat:chat', 1, 1323876847, 0),
(255, 1, 4, 'mod/chat:chat', 1, 1323876847, 0),
(256, 1, 3, 'mod/chat:chat', 1, 1323876847, 0),
(257, 1, 1, 'mod/chat:chat', 1, 1323876847, 0),
(258, 1, 5, 'mod/chat:readlog', 1, 1323876847, 0),
(259, 1, 4, 'mod/chat:readlog', 1, 1323876847, 0),
(260, 1, 3, 'mod/chat:readlog', 1, 1323876847, 0),
(261, 1, 1, 'mod/chat:readlog', 1, 1323876847, 0),
(262, 1, 4, 'mod/chat:deletelog', 1, 1323876847, 0),
(263, 1, 3, 'mod/chat:deletelog', 1, 1323876847, 0),
(264, 1, 1, 'mod/chat:deletelog', 1, 1323876847, 0),
(265, 1, 5, 'mod/choice:choose', 1, 1323876848, 0),
(266, 1, 4, 'mod/choice:choose', 1, 1323876848, 0),
(267, 1, 3, 'mod/choice:choose', 1, 1323876848, 0),
(268, 1, 1, 'mod/choice:choose', 1, 1323876848, 0),
(269, 1, 4, 'mod/choice:readresponses', 1, 1323876848, 0),
(270, 1, 3, 'mod/choice:readresponses', 1, 1323876848, 0),
(271, 1, 1, 'mod/choice:readresponses', 1, 1323876848, 0),
(272, 1, 4, 'mod/choice:deleteresponses', 1, 1323876848, 0),
(273, 1, 3, 'mod/choice:deleteresponses', 1, 1323876848, 0),
(274, 1, 1, 'mod/choice:deleteresponses', 1, 1323876848, 0),
(275, 1, 4, 'mod/choice:downloadresponses', 1, 1323876848, 0),
(276, 1, 3, 'mod/choice:downloadresponses', 1, 1323876848, 0),
(277, 1, 1, 'mod/choice:downloadresponses', 1, 1323876848, 0),
(278, 1, 6, 'mod/data:viewentry', 1, 1323876850, 0),
(279, 1, 5, 'mod/data:viewentry', 1, 1323876850, 0),
(280, 1, 4, 'mod/data:viewentry', 1, 1323876850, 0),
(281, 1, 3, 'mod/data:viewentry', 1, 1323876850, 0),
(282, 1, 1, 'mod/data:viewentry', 1, 1323876850, 0),
(283, 1, 5, 'mod/data:writeentry', 1, 1323876850, 0),
(284, 1, 4, 'mod/data:writeentry', 1, 1323876850, 0),
(285, 1, 3, 'mod/data:writeentry', 1, 1323876850, 0),
(286, 1, 1, 'mod/data:writeentry', 1, 1323876850, 0),
(287, 1, 5, 'mod/data:comment', 1, 1323876850, 0),
(288, 1, 4, 'mod/data:comment', 1, 1323876850, 0),
(289, 1, 3, 'mod/data:comment', 1, 1323876850, 0),
(290, 1, 1, 'mod/data:comment', 1, 1323876850, 0),
(291, 1, 4, 'mod/data:viewrating', 1, 1323876850, 0),
(292, 1, 3, 'mod/data:viewrating', 1, 1323876850, 0),
(293, 1, 1, 'mod/data:viewrating', 1, 1323876850, 0),
(294, 1, 4, 'mod/data:rate', 1, 1323876850, 0),
(295, 1, 3, 'mod/data:rate', 1, 1323876850, 0),
(296, 1, 1, 'mod/data:rate', 1, 1323876850, 0),
(297, 1, 4, 'mod/data:approve', 1, 1323876850, 0),
(298, 1, 3, 'mod/data:approve', 1, 1323876850, 0),
(299, 1, 1, 'mod/data:approve', 1, 1323876850, 0),
(300, 1, 4, 'mod/data:manageentries', 1, 1323876850, 0),
(301, 1, 3, 'mod/data:manageentries', 1, 1323876850, 0),
(302, 1, 1, 'mod/data:manageentries', 1, 1323876850, 0),
(303, 1, 4, 'mod/data:managecomments', 1, 1323876850, 0),
(304, 1, 3, 'mod/data:managecomments', 1, 1323876850, 0),
(305, 1, 1, 'mod/data:managecomments', 1, 1323876850, 0),
(306, 1, 3, 'mod/data:managetemplates', 1, 1323876850, 0),
(307, 1, 1, 'mod/data:managetemplates', 1, 1323876850, 0),
(308, 1, 4, 'mod/data:viewalluserpresets', 1, 1323876850, 0),
(309, 1, 3, 'mod/data:viewalluserpresets', 1, 1323876850, 0),
(310, 1, 1, 'mod/data:viewalluserpresets', 1, 1323876850, 0),
(311, 1, 1, 'mod/data:manageuserpresets', 1, 1323876850, 0),
(312, 1, 6, 'mod/forum:viewdiscussion', 1, 1323876853, 0),
(313, 1, 5, 'mod/forum:viewdiscussion', 1, 1323876853, 0),
(314, 1, 4, 'mod/forum:viewdiscussion', 1, 1323876853, 0),
(315, 1, 3, 'mod/forum:viewdiscussion', 1, 1323876853, 0),
(316, 1, 1, 'mod/forum:viewdiscussion', 1, 1323876853, 0),
(317, 1, 4, 'mod/forum:viewhiddentimedposts', 1, 1323876853, 0),
(318, 1, 3, 'mod/forum:viewhiddentimedposts', 1, 1323876853, 0),
(319, 1, 1, 'mod/forum:viewhiddentimedposts', 1, 1323876853, 0),
(320, 1, 5, 'mod/forum:startdiscussion', 1, 1323876853, 0),
(321, 1, 4, 'mod/forum:startdiscussion', 1, 1323876853, 0),
(322, 1, 3, 'mod/forum:startdiscussion', 1, 1323876853, 0),
(323, 1, 1, 'mod/forum:startdiscussion', 1, 1323876853, 0),
(324, 1, 5, 'mod/forum:replypost', 1, 1323876853, 0),
(325, 1, 4, 'mod/forum:replypost', 1, 1323876853, 0),
(326, 1, 3, 'mod/forum:replypost', 1, 1323876853, 0),
(327, 1, 1, 'mod/forum:replypost', 1, 1323876853, 0),
(328, 1, 4, 'mod/forum:addnews', 1, 1323876853, 0),
(329, 1, 3, 'mod/forum:addnews', 1, 1323876853, 0),
(330, 1, 1, 'mod/forum:addnews', 1, 1323876853, 0),
(331, 1, 4, 'mod/forum:replynews', 1, 1323876853, 0),
(332, 1, 3, 'mod/forum:replynews', 1, 1323876853, 0),
(333, 1, 1, 'mod/forum:replynews', 1, 1323876853, 0),
(334, 1, 5, 'mod/forum:viewrating', 1, 1323876853, 0),
(335, 1, 4, 'mod/forum:viewrating', 1, 1323876853, 0),
(336, 1, 3, 'mod/forum:viewrating', 1, 1323876853, 0),
(337, 1, 1, 'mod/forum:viewrating', 1, 1323876853, 0),
(338, 1, 4, 'mod/forum:viewanyrating', 1, 1323876853, 0),
(339, 1, 3, 'mod/forum:viewanyrating', 1, 1323876853, 0),
(340, 1, 1, 'mod/forum:viewanyrating', 1, 1323876853, 0),
(341, 1, 4, 'mod/forum:rate', 1, 1323876853, 0),
(342, 1, 3, 'mod/forum:rate', 1, 1323876853, 0),
(343, 1, 1, 'mod/forum:rate', 1, 1323876853, 0),
(344, 1, 5, 'mod/forum:createattachment', 1, 1323876853, 0),
(345, 1, 4, 'mod/forum:createattachment', 1, 1323876853, 0),
(346, 1, 3, 'mod/forum:createattachment', 1, 1323876853, 0),
(347, 1, 1, 'mod/forum:createattachment', 1, 1323876853, 0),
(348, 1, 5, 'mod/forum:deleteownpost', 1, 1323876853, 0),
(349, 1, 4, 'mod/forum:deleteownpost', 1, 1323876853, 0),
(350, 1, 3, 'mod/forum:deleteownpost', 1, 1323876853, 0),
(351, 1, 1, 'mod/forum:deleteownpost', 1, 1323876853, 0),
(352, 1, 4, 'mod/forum:deleteanypost', 1, 1323876853, 0),
(353, 1, 3, 'mod/forum:deleteanypost', 1, 1323876853, 0),
(354, 1, 1, 'mod/forum:deleteanypost', 1, 1323876853, 0),
(355, 1, 4, 'mod/forum:splitdiscussions', 1, 1323876853, 0),
(356, 1, 3, 'mod/forum:splitdiscussions', 1, 1323876853, 0),
(357, 1, 1, 'mod/forum:splitdiscussions', 1, 1323876853, 0),
(358, 1, 4, 'mod/forum:movediscussions', 1, 1323876853, 0),
(359, 1, 3, 'mod/forum:movediscussions', 1, 1323876853, 0),
(360, 1, 1, 'mod/forum:movediscussions', 1, 1323876853, 0),
(361, 1, 4, 'mod/forum:editanypost', 1, 1323876853, 0),
(362, 1, 3, 'mod/forum:editanypost', 1, 1323876853, 0),
(363, 1, 1, 'mod/forum:editanypost', 1, 1323876853, 0),
(364, 1, 4, 'mod/forum:viewqandawithoutposting', 1, 1323876853, 0),
(365, 1, 3, 'mod/forum:viewqandawithoutposting', 1, 1323876853, 0),
(366, 1, 1, 'mod/forum:viewqandawithoutposting', 1, 1323876853, 0),
(367, 1, 4, 'mod/forum:viewsubscribers', 1, 1323876853, 0),
(368, 1, 3, 'mod/forum:viewsubscribers', 1, 1323876853, 0),
(369, 1, 1, 'mod/forum:viewsubscribers', 1, 1323876853, 0),
(370, 1, 4, 'mod/forum:managesubscriptions', 1, 1323876853, 0),
(371, 1, 3, 'mod/forum:managesubscriptions', 1, 1323876853, 0),
(372, 1, 1, 'mod/forum:managesubscriptions', 1, 1323876853, 0),
(373, 1, 4, 'mod/forum:initialsubscriptions', 1, 1323876853, 0),
(374, 1, 3, 'mod/forum:initialsubscriptions', 1, 1323876853, 0),
(375, 1, 5, 'mod/forum:initialsubscriptions', 1, 1323876853, 0),
(376, 1, 5, 'mod/glossary:write', 1, 1323876855, 0),
(377, 1, 4, 'mod/glossary:write', 1, 1323876855, 0),
(378, 1, 3, 'mod/glossary:write', 1, 1323876855, 0),
(379, 1, 1, 'mod/glossary:write', 1, 1323876855, 0),
(380, 1, 4, 'mod/glossary:manageentries', 1, 1323876855, 0),
(381, 1, 3, 'mod/glossary:manageentries', 1, 1323876855, 0),
(382, 1, 1, 'mod/glossary:manageentries', 1, 1323876855, 0),
(383, 1, 4, 'mod/glossary:managecategories', 1, 1323876855, 0),
(384, 1, 3, 'mod/glossary:managecategories', 1, 1323876855, 0),
(385, 1, 1, 'mod/glossary:managecategories', 1, 1323876855, 0),
(386, 1, 5, 'mod/glossary:comment', 1, 1323876855, 0),
(387, 1, 4, 'mod/glossary:comment', 1, 1323876855, 0),
(388, 1, 3, 'mod/glossary:comment', 1, 1323876855, 0),
(389, 1, 1, 'mod/glossary:comment', 1, 1323876855, 0),
(390, 1, 4, 'mod/glossary:managecomments', 1, 1323876855, 0),
(391, 1, 3, 'mod/glossary:managecomments', 1, 1323876855, 0),
(392, 1, 1, 'mod/glossary:managecomments', 1, 1323876855, 0),
(393, 1, 4, 'mod/glossary:import', 1, 1323876855, 0),
(394, 1, 3, 'mod/glossary:import', 1, 1323876855, 0),
(395, 1, 1, 'mod/glossary:import', 1, 1323876855, 0),
(396, 1, 4, 'mod/glossary:export', 1, 1323876855, 0),
(397, 1, 3, 'mod/glossary:export', 1, 1323876855, 0),
(398, 1, 1, 'mod/glossary:export', 1, 1323876855, 0),
(399, 1, 4, 'mod/glossary:approve', 1, 1323876855, 0),
(400, 1, 3, 'mod/glossary:approve', 1, 1323876855, 0),
(401, 1, 1, 'mod/glossary:approve', 1, 1323876855, 0),
(402, 1, 4, 'mod/glossary:rate', 1, 1323876855, 0),
(403, 1, 3, 'mod/glossary:rate', 1, 1323876855, 0),
(404, 1, 1, 'mod/glossary:rate', 1, 1323876855, 0),
(405, 1, 4, 'mod/glossary:viewrating', 1, 1323876855, 0),
(406, 1, 3, 'mod/glossary:viewrating', 1, 1323876855, 0),
(407, 1, 1, 'mod/glossary:viewrating', 1, 1323876855, 0),
(408, 1, 5, 'mod/hotpot:attempt', 1, 1323876857, 0),
(409, 1, 4, 'mod/hotpot:attempt', 1, 1323876857, 0),
(410, 1, 3, 'mod/hotpot:attempt', 1, 1323876857, 0),
(411, 1, 1, 'mod/hotpot:attempt', 1, 1323876857, 0),
(412, 1, 4, 'mod/hotpot:viewreport', 1, 1323876857, 0),
(413, 1, 3, 'mod/hotpot:viewreport', 1, 1323876857, 0),
(414, 1, 1, 'mod/hotpot:viewreport', 1, 1323876857, 0),
(415, 1, 4, 'mod/hotpot:grade', 1, 1323876857, 0),
(416, 1, 3, 'mod/hotpot:grade', 1, 1323876857, 0),
(417, 1, 1, 'mod/hotpot:grade', 1, 1323876857, 0),
(418, 1, 3, 'mod/hotpot:deleteattempt', 1, 1323876857, 0),
(419, 1, 1, 'mod/hotpot:deleteattempt', 1, 1323876857, 0),
(420, 1, 5, 'mod/lams:participate', 1, 1323876859, 0),
(421, 1, 4, 'mod/lams:manage', 1, 1323876859, 0),
(422, 1, 3, 'mod/lams:manage', 1, 1323876859, 0),
(423, 1, 1, 'mod/lams:manage', 1, 1323876859, 0),
(424, 1, 3, 'mod/lesson:edit', 1, 1323876862, 0),
(425, 1, 1, 'mod/lesson:edit', 1, 1323876862, 0),
(426, 1, 4, 'mod/lesson:manage', 1, 1323876862, 0),
(427, 1, 3, 'mod/lesson:manage', 1, 1323876862, 0),
(428, 1, 1, 'mod/lesson:manage', 1, 1323876862, 0),
(429, 1, 6, 'mod/quiz:view', 1, 1323876867, 0),
(430, 1, 5, 'mod/quiz:view', 1, 1323876867, 0),
(431, 1, 4, 'mod/quiz:view', 1, 1323876867, 0),
(432, 1, 3, 'mod/quiz:view', 1, 1323876867, 0),
(433, 1, 1, 'mod/quiz:view', 1, 1323876867, 0),
(434, 1, 5, 'mod/quiz:attempt', 1, 1323876867, 0),
(435, 1, 5, 'mod/quiz:reviewmyattempts', 1, 1323876867, 0),
(436, 1, 3, 'mod/quiz:manage', 1, 1323876867, 0),
(437, 1, 1, 'mod/quiz:manage', 1, 1323876867, 0),
(438, 1, 4, 'mod/quiz:preview', 1, 1323876867, 0),
(439, 1, 3, 'mod/quiz:preview', 1, 1323876867, 0),
(440, 1, 1, 'mod/quiz:preview', 1, 1323876867, 0),
(441, 1, 4, 'mod/quiz:grade', 1, 1323876867, 0),
(442, 1, 3, 'mod/quiz:grade', 1, 1323876867, 0),
(443, 1, 1, 'mod/quiz:grade', 1, 1323876867, 0),
(444, 1, 4, 'mod/quiz:viewreports', 1, 1323876867, 0),
(445, 1, 3, 'mod/quiz:viewreports', 1, 1323876867, 0),
(446, 1, 1, 'mod/quiz:viewreports', 1, 1323876867, 0),
(447, 1, 3, 'mod/quiz:deleteattempts', 1, 1323876867, 0),
(448, 1, 1, 'mod/quiz:deleteattempts', 1, 1323876867, 0),
(449, 1, 4, 'mod/scorm:viewreport', 1, 1323876871, 0),
(450, 1, 3, 'mod/scorm:viewreport', 1, 1323876871, 0),
(451, 1, 1, 'mod/scorm:viewreport', 1, 1323876871, 0),
(452, 1, 5, 'mod/scorm:skipview', 1, 1323876871, 0),
(453, 1, 5, 'mod/scorm:savetrack', 1, 1323876871, 0),
(454, 1, 4, 'mod/scorm:savetrack', 1, 1323876871, 0),
(455, 1, 3, 'mod/scorm:savetrack', 1, 1323876871, 0),
(456, 1, 1, 'mod/scorm:savetrack', 1, 1323876871, 0),
(457, 1, 5, 'mod/scorm:viewscores', 1, 1323876871, 0),
(458, 1, 4, 'mod/scorm:viewscores', 1, 1323876871, 0),
(459, 1, 3, 'mod/scorm:viewscores', 1, 1323876871, 0),
(460, 1, 1, 'mod/scorm:viewscores', 1, 1323876871, 0),
(461, 1, 4, 'mod/scorm:deleteresponses', 1, 1323876871, 0),
(462, 1, 3, 'mod/scorm:deleteresponses', 1, 1323876871, 0),
(463, 1, 1, 'mod/scorm:deleteresponses', 1, 1323876871, 0),
(464, 1, 5, 'mod/survey:participate', 1, 1323876872, 0),
(465, 1, 4, 'mod/survey:participate', 1, 1323876872, 0),
(466, 1, 3, 'mod/survey:participate', 1, 1323876872, 0),
(467, 1, 1, 'mod/survey:participate', 1, 1323876872, 0),
(468, 1, 4, 'mod/survey:readresponses', 1, 1323876872, 0),
(469, 1, 3, 'mod/survey:readresponses', 1, 1323876872, 0),
(470, 1, 1, 'mod/survey:readresponses', 1, 1323876872, 0),
(471, 1, 4, 'mod/survey:download', 1, 1323876872, 0),
(472, 1, 3, 'mod/survey:download', 1, 1323876872, 0),
(473, 1, 1, 'mod/survey:download', 1, 1323876872, 0),
(474, 1, 5, 'mod/wiki:participate', 1, 1323876874, 0),
(475, 1, 4, 'mod/wiki:participate', 1, 1323876874, 0),
(476, 1, 3, 'mod/wiki:participate', 1, 1323876874, 0),
(477, 1, 1, 'mod/wiki:participate', 1, 1323876874, 0),
(478, 1, 4, 'mod/wiki:manage', 1, 1323876874, 0),
(479, 1, 3, 'mod/wiki:manage', 1, 1323876874, 0),
(480, 1, 1, 'mod/wiki:manage', 1, 1323876874, 0),
(481, 1, 4, 'mod/wiki:overridelock', 1, 1323876874, 0),
(482, 1, 3, 'mod/wiki:overridelock', 1, 1323876874, 0),
(483, 1, 1, 'mod/wiki:overridelock', 1, 1323876874, 0),
(484, 1, 5, 'mod/workshop:participate', 1, 1323876877, 0),
(485, 1, 4, 'mod/workshop:manage', 1, 1323876877, 0),
(486, 1, 3, 'mod/workshop:manage', 1, 1323876877, 0),
(487, 1, 1, 'mod/workshop:manage', 1, 1323876877, 0),
(488, 1, 7, 'block/online_users:viewlist', 1, 1323876924, 0),
(489, 1, 6, 'block/online_users:viewlist', 1, 1323876924, 0),
(490, 1, 5, 'block/online_users:viewlist', 1, 1323876924, 0),
(491, 1, 4, 'block/online_users:viewlist', 1, 1323876924, 0),
(492, 1, 3, 'block/online_users:viewlist', 1, 1323876924, 0),
(493, 1, 1, 'block/online_users:viewlist', 1, 1323876924, 0),
(494, 1, 4, 'block/rss_client:createprivatefeeds', 1, 1323876925, 0),
(495, 1, 3, 'block/rss_client:createprivatefeeds', 1, 1323876925, 0),
(496, 1, 1, 'block/rss_client:createprivatefeeds', 1, 1323876925, 0),
(497, 1, 3, 'block/rss_client:createsharedfeeds', 1, 1323876925, 0),
(498, 1, 1, 'block/rss_client:createsharedfeeds', 1, 1323876925, 0),
(499, 1, 4, 'block/rss_client:manageownfeeds', 1, 1323876925, 0),
(500, 1, 3, 'block/rss_client:manageownfeeds', 1, 1323876925, 0),
(501, 1, 1, 'block/rss_client:manageownfeeds', 1, 1323876925, 0),
(502, 1, 1, 'block/rss_client:manageanyfeeds', 1, 1323876925, 0),
(503, 1, 1, 'enrol/authorize:managepayments', 1, 1323876926, 0),
(504, 1, 1, 'enrol/authorize:uploadcsv', 1, 1323876926, 0),
(505, 1, 4, 'gradeexport/ods:view', 1, 1323876927, 0),
(506, 1, 3, 'gradeexport/ods:view', 1, 1323876927, 0),
(507, 1, 1, 'gradeexport/ods:view', 1, 1323876927, 0),
(508, 1, 1, 'gradeexport/ods:publish', 1, 1323876927, 0),
(509, 1, 4, 'gradeexport/txt:view', 1, 1323876927, 0),
(510, 1, 3, 'gradeexport/txt:view', 1, 1323876927, 0),
(511, 1, 1, 'gradeexport/txt:view', 1, 1323876927, 0),
(512, 1, 1, 'gradeexport/txt:publish', 1, 1323876927, 0),
(513, 1, 4, 'gradeexport/xls:view', 1, 1323876927, 0),
(514, 1, 3, 'gradeexport/xls:view', 1, 1323876927, 0),
(515, 1, 1, 'gradeexport/xls:view', 1, 1323876927, 0),
(516, 1, 1, 'gradeexport/xls:publish', 1, 1323876927, 0),
(517, 1, 4, 'gradeexport/xml:view', 1, 1323876927, 0),
(518, 1, 3, 'gradeexport/xml:view', 1, 1323876927, 0),
(519, 1, 1, 'gradeexport/xml:view', 1, 1323876927, 0),
(520, 1, 1, 'gradeexport/xml:publish', 1, 1323876927, 0),
(521, 1, 3, 'gradeimport/csv:view', 1, 1323876928, 0),
(522, 1, 1, 'gradeimport/csv:view', 1, 1323876928, 0),
(523, 1, 3, 'gradeimport/xml:view', 1, 1323876928, 0),
(524, 1, 1, 'gradeimport/xml:view', 1, 1323876928, 0),
(525, 1, 1, 'gradeimport/xml:publish', 1, 1323876928, 0),
(526, 1, 4, 'gradereport/grader:view', 1, 1323876928, 0),
(527, 1, 3, 'gradereport/grader:view', 1, 1323876928, 0),
(528, 1, 1, 'gradereport/grader:view', 1, 1323876928, 0),
(529, 1, 4, 'gradereport/outcomes:view', 1, 1323876928, 0),
(530, 1, 3, 'gradereport/outcomes:view', 1, 1323876928, 0),
(531, 1, 1, 'gradereport/outcomes:view', 1, 1323876928, 0),
(532, 1, 5, 'gradereport/overview:view', 1, 1323876928, 0),
(533, 1, 1, 'gradereport/overview:view', 1, 1323876928, 0),
(534, 1, 5, 'gradereport/user:view', 1, 1323876928, 0),
(535, 1, 4, 'gradereport/user:view', 1, 1323876928, 0),
(536, 1, 3, 'gradereport/user:view', 1, 1323876928, 0),
(537, 1, 1, 'gradereport/user:view', 1, 1323876928, 0),
(538, 1, 4, 'coursereport/log:view', 1, 1323876929, 0),
(539, 1, 3, 'coursereport/log:view', 1, 1323876929, 0),
(540, 1, 1, 'coursereport/log:view', 1, 1323876929, 0),
(541, 1, 4, 'coursereport/log:viewlive', 1, 1323876929, 0),
(542, 1, 3, 'coursereport/log:viewlive', 1, 1323876929, 0),
(543, 1, 1, 'coursereport/log:viewlive', 1, 1323876929, 0),
(544, 1, 4, 'coursereport/log:viewtoday', 1, 1323876929, 0),
(545, 1, 3, 'coursereport/log:viewtoday', 1, 1323876929, 0),
(546, 1, 1, 'coursereport/log:viewtoday', 1, 1323876929, 0),
(547, 1, 4, 'coursereport/outline:view', 1, 1323876929, 0),
(548, 1, 3, 'coursereport/outline:view', 1, 1323876929, 0),
(549, 1, 1, 'coursereport/outline:view', 1, 1323876929, 0),
(550, 1, 4, 'coursereport/participation:view', 1, 1323876929, 0),
(551, 1, 3, 'coursereport/participation:view', 1, 1323876929, 0),
(552, 1, 1, 'coursereport/participation:view', 1, 1323876929, 0),
(553, 1, 4, 'coursereport/stats:view', 1, 1323876929, 0),
(554, 1, 3, 'coursereport/stats:view', 1, 1323876929, 0),
(555, 1, 1, 'coursereport/stats:view', 1, 1323876929, 0),
(556, 1, 4, 'report/courseoverview:view', 1, 1323876930, 0),
(557, 1, 3, 'report/courseoverview:view', 1, 1323876930, 0),
(558, 1, 1, 'report/courseoverview:view', 1, 1323876930, 0),
(559, 1, 1, 'report/security:view', 1, 1323876930, 0),
(560, 1, 1, 'report/unittest:view', 1, 1323876930, 0),
(561, 1, 1, 'mod/launcher:access', 1, 1325601845, 2),
(563, 1, 9, 'block/online_users:viewlist', 1, 1329387996, 2),
(564, 1, 9, 'block/rss_client:createprivatefeeds', 1, 1329387996, 2),
(565, 1, 9, 'block/rss_client:manageownfeeds', 1, 1329387996, 2),
(566, 1, 9, 'coursereport/log:view', 1, 1329387996, 2),
(567, 1, 9, 'coursereport/log:viewlive', 1, 1329387996, 2),
(568, 1, 9, 'coursereport/log:viewtoday', 1, 1329387996, 2),
(569, 1, 9, 'coursereport/outline:view', 1, 1329387996, 2),
(570, 1, 9, 'coursereport/participation:view', 1, 1329387996, 2),
(571, 1, 9, 'coursereport/stats:view', 1, 1329387996, 2),
(572, 1, 9, 'gradeexport/ods:view', 1, 1329387996, 2),
(573, 1, 9, 'gradeexport/txt:view', 1, 1329387996, 2),
(574, 1, 9, 'gradeexport/xls:view', 1, 1329387996, 2),
(575, 1, 9, 'gradeexport/xml:view', 1, 1329387996, 2),
(576, 1, 9, 'gradereport/grader:view', 1, 1329387996, 2),
(577, 1, 9, 'gradereport/outcomes:view', 1, 1329387996, 2),
(578, 1, 9, 'gradereport/user:view', 1, 1329387996, 2),
(579, 1, 9, 'mod/assignment:grade', 1, 1329387996, 2),
(580, 1, 9, 'mod/assignment:view', 1, 1329387996, 2),
(581, 1, 9, 'mod/chat:chat', 1, 1329387996, 2),
(582, 1, 9, 'mod/chat:deletelog', 1, 1329387996, 2),
(583, 1, 9, 'mod/chat:readlog', 1, 1329387996, 2),
(584, 1, 9, 'mod/choice:choose', 1, 1329387996, 2),
(585, 1, 9, 'mod/choice:deleteresponses', 1, 1329387996, 2),
(586, 1, 9, 'mod/choice:downloadresponses', 1, 1329387996, 2),
(587, 1, 9, 'mod/choice:readresponses', 1, 1329387996, 2),
(588, 1, 9, 'mod/data:approve', 1, 1329387996, 2),
(589, 1, 9, 'mod/data:comment', 1, 1329387996, 2),
(590, 1, 9, 'mod/data:managecomments', 1, 1329387996, 2),
(591, 1, 9, 'mod/data:manageentries', 1, 1329387996, 2),
(592, 1, 9, 'mod/data:rate', 1, 1329387996, 2),
(593, 1, 9, 'mod/data:viewalluserpresets', 1, 1329387996, 2),
(594, 1, 9, 'mod/data:viewentry', 1, 1329387996, 2),
(595, 1, 9, 'mod/data:viewrating', 1, 1329387996, 2),
(596, 1, 9, 'mod/data:writeentry', 1, 1329387996, 2),
(597, 1, 9, 'mod/forum:addnews', 1, 1329387996, 2),
(598, 1, 9, 'mod/forum:createattachment', 1, 1329387996, 2),
(599, 1, 9, 'mod/forum:deleteanypost', 1, 1329387996, 2),
(600, 1, 9, 'mod/forum:deleteownpost', 1, 1329387996, 2),
(601, 1, 9, 'mod/forum:editanypost', 1, 1329387996, 2),
(602, 1, 9, 'mod/forum:initialsubscriptions', 1, 1329387996, 2),
(603, 1, 9, 'mod/forum:managesubscriptions', 1, 1329387996, 2),
(604, 1, 9, 'mod/forum:movediscussions', 1, 1329387996, 2),
(605, 1, 9, 'mod/forum:rate', 1, 1329387996, 2),
(606, 1, 9, 'mod/forum:replynews', 1, 1329387996, 2),
(607, 1, 9, 'mod/forum:replypost', 1, 1329387996, 2),
(608, 1, 9, 'mod/forum:splitdiscussions', 1, 1329387996, 2),
(609, 1, 9, 'mod/forum:startdiscussion', 1, 1329387996, 2),
(610, 1, 9, 'mod/forum:viewanyrating', 1, 1329387996, 2),
(611, 1, 9, 'mod/forum:viewdiscussion', 1, 1329387996, 2),
(612, 1, 9, 'mod/forum:viewhiddentimedposts', 1, 1329387996, 2),
(613, 1, 9, 'mod/forum:viewqandawithoutposting', 1, 1329387996, 2),
(614, 1, 9, 'mod/forum:viewrating', 1, 1329387996, 2),
(615, 1, 9, 'mod/forum:viewsubscribers', 1, 1329387996, 2),
(616, 1, 9, 'mod/glossary:approve', 1, 1329387996, 2),
(617, 1, 9, 'mod/glossary:comment', 1, 1329387996, 2),
(618, 1, 9, 'mod/glossary:export', 1, 1329387996, 2),
(619, 1, 9, 'mod/glossary:import', 1, 1329387996, 2),
(620, 1, 9, 'mod/glossary:managecategories', 1, 1329387996, 2),
(621, 1, 9, 'mod/glossary:managecomments', 1, 1329387996, 2),
(622, 1, 9, 'mod/glossary:manageentries', 1, 1329387996, 2),
(623, 1, 9, 'mod/glossary:rate', 1, 1329387996, 2),
(624, 1, 9, 'mod/glossary:viewrating', 1, 1329387996, 2),
(625, 1, 9, 'mod/glossary:write', 1, 1329387996, 2),
(626, 1, 9, 'mod/hotpot:attempt', 1, 1329387996, 2),
(627, 1, 9, 'mod/hotpot:grade', 1, 1329387996, 2),
(628, 1, 9, 'mod/hotpot:viewreport', 1, 1329387996, 2),
(629, 1, 9, 'mod/lams:manage', 1, 1329387996, 2),
(630, 1, 9, 'mod/lesson:manage', 1, 1329387996, 2),
(631, 1, 9, 'mod/quiz:grade', 1, 1329387996, 2),
(632, 1, 9, 'mod/quiz:preview', 1, 1329387996, 2),
(633, 1, 9, 'mod/quiz:view', 1, 1329387996, 2),
(634, 1, 9, 'mod/quiz:viewreports', 1, 1329387996, 2),
(635, 1, 9, 'mod/scorm:deleteresponses', 1, 1329387996, 2),
(636, 1, 9, 'mod/scorm:savetrack', 1, 1329387996, 2),
(637, 1, 9, 'mod/scorm:viewreport', 1, 1329387996, 2),
(638, 1, 9, 'mod/scorm:viewscores', 1, 1329387996, 2),
(639, 1, 9, 'mod/survey:download', 1, 1329387996, 2),
(640, 1, 9, 'mod/survey:participate', 1, 1329387996, 2),
(641, 1, 9, 'mod/survey:readresponses', 1, 1329387996, 2),
(642, 1, 9, 'mod/wiki:manage', 1, 1329387996, 2),
(643, 1, 9, 'mod/wiki:overridelock', 1, 1329387996, 2),
(644, 1, 9, 'mod/wiki:participate', 1, 1329387996, 2),
(645, 1, 9, 'mod/workshop:manage', 1, 1329387996, 2),
(646, 1, 9, 'moodle/block:view', 1, 1329387996, 2),
(647, 1, 9, 'moodle/blog:manageentries', 1, 1329387996, 2),
(648, 1, 9, 'moodle/blog:view', 1, 1329387996, 2),
(649, 1, 9, 'moodle/calendar:manageentries', 1, 1329387996, 2),
(650, 1, 9, 'moodle/calendar:managegroupentries', 1, 1329387996, 2),
(651, 1, 9, 'moodle/course:bulkmessaging', 1, 1329387996, 2),
(652, 1, 9, 'moodle/course:view', 1, 1329387996, 2),
(653, 1, 9, 'moodle/course:viewhiddenactivities', 1, 1329387996, 2),
(654, 1, 9, 'moodle/course:viewhiddencourses', 1, 1329387996, 2),
(655, 1, 9, 'moodle/course:viewhiddenuserfields', 1, 1329387996, 2),
(656, 1, 9, 'moodle/course:viewparticipants', 1, 1329387996, 2),
(657, 1, 9, 'moodle/course:viewscales', 1, 1329387996, 2),
(658, 1, 9, 'moodle/grade:export', 1, 1329387996, 2),
(659, 1, 9, 'moodle/grade:viewall', 1, 1329387996, 2),
(660, 1, 9, 'moodle/grade:viewhidden', 1, 1329387996, 2),
(661, 1, 9, 'moodle/legacy:teacher', 1, 1323876844, 0),
(662, 1, 9, 'moodle/notes:manage', 1, 1329387996, 2),
(663, 1, 9, 'moodle/notes:view', 1, 1329387996, 2),
(664, 1, 9, 'moodle/role:unassignself', 1, 1329387996, 2),
(665, 1, 9, 'moodle/role:viewhiddenassigns', 1, 1329387996, 2),
(666, 1, 9, 'moodle/site:accessallgroups', 1, 1329387996, 2),
(667, 1, 9, 'moodle/site:doclinks', 1, 1329387996, 2),
(668, 1, 9, 'moodle/site:viewfullnames', 1, 1329387996, 2),
(669, 1, 9, 'moodle/site:viewreports', 1, 1329387996, 2),
(670, 1, 9, 'moodle/tag:editblocks', 1, 1329387996, 2),
(671, 1, 9, 'moodle/tag:manage', 1, 1329387996, 2),
(672, 1, 9, 'moodle/user:readuserblogs', 1, 1329387996, 2),
(673, 1, 9, 'moodle/user:readuserposts', 1, 1329387996, 2),
(674, 1, 9, 'moodle/user:viewdetails', 1, 1329387996, 2),
(675, 1, 9, 'moodle/user:viewhiddendetails', 1, 1329387996, 2),
(676, 1, 9, 'report/courseoverview:view', 1, 1329387996, 2),
(997, 1, 11, 'report/courseoverview:view', 1, 1329389244, 2),
(996, 1, 11, 'moodle/user:viewhiddendetails', 1, 1329389244, 2),
(995, 1, 11, 'moodle/user:viewdetails', 1, 1329389244, 2),
(994, 1, 11, 'moodle/user:readuserposts', 1, 1329389244, 2),
(992, 1, 11, 'moodle/tag:manage', 1, 1329389244, 2),
(987, 1, 11, 'moodle/site:accessallgroups', 1, 1329389244, 2),
(985, 1, 11, 'moodle/role:unassignself', 1, 1329389244, 2),
(982, 1, 11, 'moodle/legacy:teacher', 1, 1323876844, 0),
(980, 1, 11, 'moodle/grade:viewall', 1, 1329389244, 2),
(979, 1, 11, 'moodle/grade:export', 1, 1329389244, 2),
(977, 1, 11, 'moodle/course:viewparticipants', 1, 1329389244, 2),
(976, 1, 11, 'moodle/course:viewhiddenuserfields', 1, 1329389244, 2),
(975, 1, 11, 'moodle/course:viewhiddencourses', 1, 1329389244, 2),
(972, 1, 11, 'moodle/course:bulkmessaging', 1, 1329389244, 2),
(971, 1, 11, 'moodle/calendar:managegroupentries', 1, 1329389244, 2),
(970, 1, 11, 'moodle/calendar:manageentries', 1, 1329389244, 2),
(969, 1, 11, 'moodle/blog:view', 1, 1329389244, 2),
(968, 1, 11, 'moodle/blog:manageentries', 1, 1329389244, 2),
(963, 1, 11, 'mod/wiki:manage', 1, 1329389244, 2),
(962, 1, 11, 'mod/survey:readresponses', 1, 1329389244, 2),
(961, 1, 11, 'mod/survey:participate', 1, 1329389244, 2),
(960, 1, 11, 'mod/survey:download', 1, 1329389244, 2),
(959, 1, 11, 'mod/scorm:viewscores', 1, 1329389244, 2),
(958, 1, 11, 'mod/scorm:viewreport', 1, 1329389244, 2),
(957, 1, 11, 'mod/scorm:savetrack', 1, 1329389244, 2),
(955, 1, 11, 'mod/quiz:viewreports', 1, 1329389244, 2),
(953, 1, 11, 'mod/quiz:preview', 1, 1329389244, 2),
(952, 1, 11, 'mod/quiz:grade', 1, 1329389244, 2),
(951, 1, 11, 'mod/lesson:manage', 1, 1329389244, 2),
(948, 1, 11, 'mod/hotpot:grade', 1, 1329389244, 2),
(945, 1, 11, 'mod/glossary:viewrating', 1, 1329389244, 2),
(944, 1, 11, 'mod/glossary:rate', 1, 1329389244, 2),
(943, 1, 11, 'mod/glossary:manageentries', 1, 1329389244, 2),
(941, 1, 11, 'mod/glossary:managecategories', 1, 1329389244, 2),
(935, 1, 11, 'mod/forum:viewrating', 1, 1329389244, 2),
(934, 1, 11, 'mod/forum:viewqandawithoutposting', 1, 1329389244, 2),
(932, 1, 11, 'mod/forum:viewdiscussion', 1, 1329389244, 2),
(931, 1, 11, 'mod/forum:viewanyrating', 1, 1329389244, 2),
(930, 1, 11, 'mod/forum:startdiscussion', 1, 1329389244, 2),
(929, 1, 11, 'mod/forum:splitdiscussions', 1, 1329389244, 2),
(927, 1, 11, 'mod/forum:replynews', 1, 1329389244, 2),
(926, 1, 11, 'mod/forum:rate', 1, 1329389244, 2),
(925, 1, 11, 'mod/forum:movediscussions', 1, 1329389244, 2),
(924, 1, 11, 'mod/forum:managesubscriptions', 1, 1329389244, 2),
(922, 1, 11, 'mod/forum:editanypost', 1, 1329389244, 2),
(921, 1, 11, 'mod/forum:deleteownpost', 1, 1329389244, 2),
(920, 1, 11, 'mod/forum:deleteanypost', 1, 1329389244, 2),
(919, 1, 11, 'mod/forum:createattachment', 1, 1329389244, 2),
(912, 1, 11, 'mod/data:manageentries', 1, 1329389244, 2),
(911, 1, 11, 'mod/data:managecomments', 1, 1329389244, 2),
(909, 1, 11, 'mod/data:approve', 1, 1329389244, 2),
(907, 1, 11, 'mod/choice:downloadresponses', 1, 1329389244, 2),
(906, 1, 11, 'mod/choice:deleteresponses', 1, 1329389244, 2),
(904, 1, 11, 'mod/chat:readlog', 1, 1329389244, 2),
(902, 1, 11, 'mod/chat:chat', 1, 1329389244, 2),
(899, 1, 11, 'gradereport/user:view', 1, 1329389244, 2),
(889, 1, 11, 'coursereport/log:viewtoday', 1, 1329389244, 2),
(887, 1, 11, 'coursereport/log:view', 1, 1329389244, 2),
(884, 1, 11, 'block/online_users:viewlist', 1, 1329389244, 2),
(908, 1, 11, 'mod/choice:readresponses', 1, 1329389244, 2),
(984, 1, 11, 'moodle/notes:view', 1, 1329389244, 2),
(983, 1, 11, 'moodle/notes:manage', 1, 1329389244, 2),
(981, 1, 11, 'moodle/grade:viewhidden', 1, 1329389244, 2),
(886, 1, 11, 'block/rss_client:manageownfeeds', 1, 1329389244, 2),
(885, 1, 11, 'block/rss_client:createprivatefeeds', 1, 1329389244, 2),
(893, 1, 11, 'gradeexport/ods:view', 1, 1329389244, 2),
(892, 1, 11, 'coursereport/stats:view', 1, 1329389244, 2),
(891, 1, 11, 'coursereport/participation:view', 1, 1329389244, 2),
(890, 1, 11, 'coursereport/outline:view', 1, 1329389244, 2),
(888, 1, 11, 'coursereport/log:viewlive', 1, 1329389244, 2),
(905, 1, 11, 'mod/choice:choose', 1, 1329389244, 2),
(903, 1, 11, 'mod/chat:deletelog', 1, 1329389244, 2),
(901, 1, 11, 'mod/assignment:view', 1, 1329389244, 2),
(900, 1, 11, 'mod/assignment:grade', 1, 1329389244, 2),
(898, 1, 11, 'gradereport/outcomes:view', 1, 1329389244, 2),
(897, 1, 11, 'gradereport/grader:view', 1, 1329389244, 2),
(896, 1, 11, 'gradeexport/xml:view', 1, 1329389244, 2),
(895, 1, 11, 'gradeexport/xls:view', 1, 1329389244, 2),
(894, 1, 11, 'gradeexport/txt:view', 1, 1329389244, 2),
(993, 1, 11, 'moodle/user:readuserblogs', 1, 1329389244, 2),
(990, 1, 11, 'moodle/site:viewreports', 1, 1329389244, 2),
(989, 1, 11, 'moodle/site:viewfullnames', 1, 1329389244, 2),
(991, 1, 11, 'moodle/tag:editblocks', 1, 1329389244, 2),
(988, 1, 11, 'moodle/site:doclinks', 1, 1329389244, 2),
(986, 1, 11, 'moodle/role:viewhiddenassigns', 1, 1329389244, 2),
(978, 1, 11, 'moodle/course:viewscales', 1, 1329389244, 2),
(974, 1, 11, 'moodle/course:viewhiddenactivities', 1, 1329389244, 2),
(973, 1, 11, 'moodle/course:view', 1, 1329389244, 2),
(967, 1, 11, 'moodle/block:view', 1, 1329389244, 2),
(966, 1, 11, 'mod/workshop:manage', 1, 1329389244, 2),
(964, 1, 11, 'mod/wiki:overridelock', 1, 1329389244, 2),
(965, 1, 11, 'mod/wiki:participate', 1, 1329389244, 2),
(956, 1, 11, 'mod/scorm:deleteresponses', 1, 1329389244, 2),
(954, 1, 11, 'mod/quiz:view', 1, 1329389244, 2),
(946, 1, 11, 'mod/glossary:write', 1, 1329389244, 2),
(947, 1, 11, 'mod/hotpot:attempt', 1, 1329389244, 2),
(950, 1, 11, 'mod/lams:manage', 1, 1329389244, 2),
(949, 1, 11, 'mod/hotpot:viewreport', 1, 1329389244, 2),
(939, 1, 11, 'mod/glossary:export', 1, 1329389244, 2),
(940, 1, 11, 'mod/glossary:import', 1, 1329389244, 2),
(942, 1, 11, 'mod/glossary:managecomments', 1, 1329389244, 2),
(938, 1, 11, 'mod/glossary:comment', 1, 1329389244, 2),
(937, 1, 11, 'mod/glossary:approve', 1, 1329389244, 2),
(936, 1, 11, 'mod/forum:viewsubscribers', 1, 1329389244, 2),
(933, 1, 11, 'mod/forum:viewhiddentimedposts', 1, 1329389244, 2),
(928, 1, 11, 'mod/forum:replypost', 1, 1329389244, 2),
(923, 1, 11, 'mod/forum:initialsubscriptions', 1, 1329389244, 2),
(918, 1, 11, 'mod/forum:addnews', 1, 1329389244, 2),
(917, 1, 11, 'mod/data:writeentry', 1, 1329389244, 2),
(916, 1, 11, 'mod/data:viewrating', 1, 1329389244, 2),
(915, 1, 11, 'mod/data:viewentry', 1, 1329389244, 2),
(914, 1, 11, 'mod/data:viewalluserpresets', 1, 1329389244, 2),
(913, 1, 11, 'mod/data:rate', 1, 1329389244, 2),
(910, 1, 11, 'mod/data:comment', 1, 1329389244, 2);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_role_names`
--

CREATE TABLE IF NOT EXISTS `mdl_role_names` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `roleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `contextid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_rolename_rolcon_uix` (`roleid`,`contextid`),
  KEY `mdl_rolename_rol_ix` (`roleid`),
  KEY `mdl_rolename_con_ix` (`contextid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='role names in native strings' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_role_names`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_role_sortorder`
--

CREATE TABLE IF NOT EXISTS `mdl_role_sortorder` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL,
  `roleid` bigint(10) unsigned NOT NULL,
  `contextid` bigint(10) unsigned NOT NULL,
  `sortoder` bigint(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_rolesort_userolcon_uix` (`userid`,`roleid`,`contextid`),
  KEY `mdl_rolesort_use_ix` (`userid`),
  KEY `mdl_rolesort_rol_ix` (`roleid`),
  KEY `mdl_rolesort_con_ix` (`contextid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='sort order of course managers in a course' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_role_sortorder`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_scale`
--

CREATE TABLE IF NOT EXISTS `mdl_scale` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `scale` text NOT NULL,
  `description` text NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_scal_cou_ix` (`courseid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Defines grading scales' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `mdl_scale`
--

INSERT INTO `mdl_scale` (`id`, `courseid`, `userid`, `name`, `scale`, `description`, `timemodified`) VALUES
(1, 0, 0, 'Separate and Connected ways of knowing', 'Mostly Separate Knowing,Separate and Connected,Mostly Connected Knowing', '<h1> Ratings </h1>\n\n<p>Individual posts can be rated using a scale based on the theory of <strong>separate and connected knowing</strong>.\n\nThis theory may help you to look at human interactions in a new way. It describes two different ways that we can evaluate and learn about the things we see and hear.\n\nAlthough each of us may use these two methods in different amounts at different times, it may be useful to imagine two people as examples, one who is a mostly separate knower (Jim) and the other a mostly connected knower (Mary).\n</p>\n\n<ul>\n\n  <li>Jim likes to remain as ''objective'' as possible without including his feelings and emotions. When in a discussion with other people who may have different ideas, he likes to defend his own ideas, using logic to find holes in his opponent''s ideas. He is critical of new ideas unless they are proven facts from reputable sources such as textbooks, respected teachers or his own direct experience. Jim is a very <strong>separate knower</strong>.\n\n  </li>\n\n  <li>Mary is more sensitive to other people. She is skilled at empathy and tends to listen and ask questions until she feels she can connect and &quot;understand things from their point of view&quot;. She learns by trying to share the experiences that led to the knowledge she finds in other people. When talking to others, she avoids confrontation and will often try to help the other person if she can see a way to do so, using logical suggestions. Mary is a very <strong>connected knower</strong>.</li>\n\n</ul>\n\n<p>Did you notice in these examples that the separate knower is male and the connected knower is female? Some studies have shown that statistically this tends to be the case, however individual people can be anywhere in the spectrum between these two extremes.\n\nFor a collaborative and effective group of learners it may be best if everyone were able to use BOTH ways of knowing.\n\nIn a particular situation like an online forum, a single post by a person may exhibit either of these characteristics, or even both. Someone who is generally very connected may post a very separate-sounding message, and vice versa. The purpose of rating each post using this scale is to:\n</p>\n\n<ol style="list-style:lower-alpha">\n\n  <li> help you think about these issues when reading other posts </li>\n\n  <li> provide feedback to each author on how they are being seen by others </li>\n\n</ol>\n\nThe results are not used towards student assessment in any way, they are just to help improve communication and learning.\n\n<hr />\n<p>\nIn case you''re interested, here are some references to papers by the authors who originally developed these ideas:\n</p>\n\n<ul>\n  <li>Belenky, M.F., Clinchy, B.M., Goldberger, N.R., &amp; Tarule, J.M. (1986). \n\n    Women''s ways of knowing: the development of self, voice, and mind. New York, \n\n    NY: Basic Books.</li>\n\n  <li>Clinchy, B.M. (1989a). The development of thoughtfulness in college women: \n\n    Integrating reason and care. American Behavioural Scientist, 32(6), 647-657.</li>\n\n  <li>Clinchy, B.M. (1989b). On critical thinking &amp; connected knowing. Liberal \n\n    education, 75(5), 14-19.</li>\n\n  <li>Clinchy, B.M. (1996). Connected and separate knowing; Toward a marriage \n\n    of two minds. In N.R. Goldberger, Tarule, J.M., Clinchy, B.M. &amp;</li>\n\n  <li>Belenky, M.F. (Eds.), Knowledge, Difference, and Power; Essays inspired \n\n    by &#8220;Women&#8217;s Ways of Knowing&#8221; (pp. 205-247). New York, NY: \n\n    Basic Books.</li>\n\n  <li>Galotti, K. M., Clinchy, B. M., Ainsworth, K., Lavin, B., &amp; Mansfield, \n\n    A. F. (1999). A New Way of Assessing Ways of Knowing: The Attitudes Towards \n\n    Thinking and Learning Survey (ATTLS). Sex Roles, 40(9/10), 745-766.</li>\n\n  <li>Galotti, K. M., Reimer, R. L., &amp; Drebus, D. W. (2001). Ways of knowing \n\n    as learning styles: Learning MAGIC with a partner. Sex Roles, 44(7/8), 419-436. \n\n  </li>\n\n</ul>\n\n', 1326115077);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_scale_history`
--

CREATE TABLE IF NOT EXISTS `mdl_scale_history` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `action` bigint(10) unsigned NOT NULL DEFAULT '0',
  `oldid` bigint(10) unsigned NOT NULL,
  `source` varchar(255) DEFAULT NULL,
  `timemodified` bigint(10) unsigned DEFAULT NULL,
  `loggeduser` bigint(10) unsigned DEFAULT NULL,
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `scale` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_scalhist_act_ix` (`action`),
  KEY `mdl_scalhist_old_ix` (`oldid`),
  KEY `mdl_scalhist_cou_ix` (`courseid`),
  KEY `mdl_scalhist_log_ix` (`loggeduser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='History table' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_scale_history`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_scorm`
--

CREATE TABLE IF NOT EXISTS `mdl_scorm` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `reference` varchar(255) NOT NULL DEFAULT '',
  `summary` text NOT NULL,
  `version` varchar(9) NOT NULL DEFAULT '',
  `maxgrade` double NOT NULL DEFAULT '0',
  `grademethod` tinyint(2) NOT NULL DEFAULT '0',
  `whatgrade` bigint(10) NOT NULL DEFAULT '0',
  `maxattempt` bigint(10) NOT NULL DEFAULT '1',
  `updatefreq` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `md5hash` varchar(32) NOT NULL DEFAULT '',
  `launch` bigint(10) unsigned NOT NULL DEFAULT '0',
  `skipview` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `hidebrowse` tinyint(1) NOT NULL DEFAULT '0',
  `hidetoc` tinyint(1) NOT NULL DEFAULT '0',
  `hidenav` tinyint(1) NOT NULL DEFAULT '0',
  `auto` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `popup` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `options` varchar(255) NOT NULL DEFAULT '',
  `width` bigint(10) unsigned NOT NULL DEFAULT '100',
  `height` bigint(10) unsigned NOT NULL DEFAULT '600',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_scor_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='each table is one SCORM module and its configuration' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_scorm`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_scorm_scoes`
--

CREATE TABLE IF NOT EXISTS `mdl_scorm_scoes` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `scorm` bigint(10) unsigned NOT NULL DEFAULT '0',
  `manifest` varchar(255) NOT NULL DEFAULT '',
  `organization` varchar(255) NOT NULL DEFAULT '',
  `parent` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `launch` varchar(255) NOT NULL DEFAULT '',
  `scormtype` varchar(5) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_scorscoe_sco_ix` (`scorm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='each SCO part of the SCORM module' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_scorm_scoes`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_scorm_scoes_data`
--

CREATE TABLE IF NOT EXISTS `mdl_scorm_scoes_data` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `scoid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_scorscoedata_sco_ix` (`scoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Contains variable data get from packages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_scorm_scoes_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_scorm_scoes_track`
--

CREATE TABLE IF NOT EXISTS `mdl_scorm_scoes_track` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `scormid` bigint(10) NOT NULL DEFAULT '0',
  `scoid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `attempt` bigint(10) unsigned NOT NULL DEFAULT '1',
  `element` varchar(255) NOT NULL DEFAULT '',
  `value` longtext NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_scorscoetrac_usescosco_uix` (`userid`,`scormid`,`scoid`,`attempt`,`element`),
  KEY `mdl_scorscoetrac_use_ix` (`userid`),
  KEY `mdl_scorscoetrac_ele_ix` (`element`),
  KEY `mdl_scorscoetrac_sco_ix` (`scormid`),
  KEY `mdl_scorscoetrac_sco2_ix` (`scoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to track SCOes' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_scorm_scoes_track`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_scorm_seq_mapinfo`
--

CREATE TABLE IF NOT EXISTS `mdl_scorm_seq_mapinfo` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `scoid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `objectiveid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `targetobjectiveid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `readsatisfiedstatus` tinyint(1) NOT NULL DEFAULT '1',
  `readnormalizedmeasure` tinyint(1) NOT NULL DEFAULT '1',
  `writesatisfiedstatus` tinyint(1) NOT NULL DEFAULT '0',
  `writenormalizedmeasure` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_scorseqmapi_scoidobj_uix` (`scoid`,`id`,`objectiveid`),
  KEY `mdl_scorseqmapi_sco_ix` (`scoid`),
  KEY `mdl_scorseqmapi_obj_ix` (`objectiveid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 objective mapinfo description' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_scorm_seq_mapinfo`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_scorm_seq_objective`
--

CREATE TABLE IF NOT EXISTS `mdl_scorm_seq_objective` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `scoid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `primaryobj` tinyint(1) NOT NULL DEFAULT '0',
  `objectiveid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `satisfiedbymeasure` tinyint(1) NOT NULL DEFAULT '1',
  `minnormalizedmeasure` float(11,4) unsigned NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_scorseqobje_scoid_uix` (`scoid`,`id`),
  KEY `mdl_scorseqobje_sco_ix` (`scoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 objective description' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_scorm_seq_objective`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_scorm_seq_rolluprule`
--

CREATE TABLE IF NOT EXISTS `mdl_scorm_seq_rolluprule` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `scoid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `childactivityset` varchar(15) NOT NULL DEFAULT '',
  `minimumcount` bigint(10) unsigned NOT NULL DEFAULT '0',
  `minimumpercent` float(11,4) unsigned NOT NULL DEFAULT '0.0000',
  `conditioncombination` varchar(3) NOT NULL DEFAULT 'all',
  `action` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_scorseqroll_scoid_uix` (`scoid`,`id`),
  KEY `mdl_scorseqroll_sco_ix` (`scoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 sequencing rule' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_scorm_seq_rolluprule`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_scorm_seq_rolluprulecond`
--

CREATE TABLE IF NOT EXISTS `mdl_scorm_seq_rolluprulecond` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `scoid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `rollupruleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `operator` varchar(5) NOT NULL DEFAULT 'noOp',
  `cond` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_scorseqroll_scorolid_uix` (`scoid`,`rollupruleid`,`id`),
  KEY `mdl_scorseqroll_sco2_ix` (`scoid`),
  KEY `mdl_scorseqroll_rol_ix` (`rollupruleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 sequencing rule' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_scorm_seq_rolluprulecond`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_scorm_seq_rulecond`
--

CREATE TABLE IF NOT EXISTS `mdl_scorm_seq_rulecond` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `scoid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `ruleconditionsid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `refrencedobjective` varchar(255) NOT NULL DEFAULT '',
  `measurethreshold` float(11,4) NOT NULL DEFAULT '0.0000',
  `operator` varchar(5) NOT NULL DEFAULT 'noOp',
  `cond` varchar(30) NOT NULL DEFAULT 'always',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_scorseqrule_idscorul_uix` (`id`,`scoid`,`ruleconditionsid`),
  KEY `mdl_scorseqrule_sco2_ix` (`scoid`),
  KEY `mdl_scorseqrule_rul_ix` (`ruleconditionsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 rule condition' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_scorm_seq_rulecond`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_scorm_seq_ruleconds`
--

CREATE TABLE IF NOT EXISTS `mdl_scorm_seq_ruleconds` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `scoid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `conditioncombination` varchar(3) NOT NULL DEFAULT 'all',
  `ruletype` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `action` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_scorseqrule_scoid_uix` (`scoid`,`id`),
  KEY `mdl_scorseqrule_sco_ix` (`scoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 rule conditions' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_scorm_seq_ruleconds`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_sessions2`
--

CREATE TABLE IF NOT EXISTS `mdl_sessions2` (
  `sesskey` varchar(64) NOT NULL DEFAULT '',
  `expiry` datetime NOT NULL,
  `expireref` varchar(250) DEFAULT '',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `sessdata` longtext,
  PRIMARY KEY (`sesskey`),
  KEY `mdl_sess_exp_ix` (`expiry`),
  KEY `mdl_sess_exp2_ix` (`expireref`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Optional database session storage in new format, not used by';

--
-- Dumping data for table `mdl_sessions2`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_soda`
--

CREATE TABLE IF NOT EXISTS `mdl_soda` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_soda_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Instances of mod soda' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_soda`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_stats_daily`
--

CREATE TABLE IF NOT EXISTS `mdl_stats_daily` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeend` bigint(10) unsigned NOT NULL DEFAULT '0',
  `roleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `stattype` enum('enrolments','activity','logins') NOT NULL DEFAULT 'activity',
  `stat1` bigint(10) unsigned NOT NULL DEFAULT '0',
  `stat2` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_statdail_cou_ix` (`courseid`),
  KEY `mdl_statdail_tim_ix` (`timeend`),
  KEY `mdl_statdail_rol_ix` (`roleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to accumulate daily stats' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_stats_daily`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_stats_monthly`
--

CREATE TABLE IF NOT EXISTS `mdl_stats_monthly` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeend` bigint(10) unsigned NOT NULL DEFAULT '0',
  `roleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `stattype` enum('enrolments','activity','logins') NOT NULL DEFAULT 'activity',
  `stat1` bigint(10) unsigned NOT NULL DEFAULT '0',
  `stat2` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_statmont_cou_ix` (`courseid`),
  KEY `mdl_statmont_tim_ix` (`timeend`),
  KEY `mdl_statmont_rol_ix` (`roleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To accumulate monthly stats' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_stats_monthly`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_stats_user_daily`
--

CREATE TABLE IF NOT EXISTS `mdl_stats_user_daily` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `roleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeend` bigint(10) unsigned NOT NULL DEFAULT '0',
  `statsreads` bigint(10) unsigned NOT NULL DEFAULT '0',
  `statswrites` bigint(10) unsigned NOT NULL DEFAULT '0',
  `stattype` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_statuserdail_cou_ix` (`courseid`),
  KEY `mdl_statuserdail_use_ix` (`userid`),
  KEY `mdl_statuserdail_rol_ix` (`roleid`),
  KEY `mdl_statuserdail_tim_ix` (`timeend`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To accumulate daily stats per course/user' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_stats_user_daily`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_stats_user_monthly`
--

CREATE TABLE IF NOT EXISTS `mdl_stats_user_monthly` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `roleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeend` bigint(10) unsigned NOT NULL DEFAULT '0',
  `statsreads` bigint(10) unsigned NOT NULL DEFAULT '0',
  `statswrites` bigint(10) unsigned NOT NULL DEFAULT '0',
  `stattype` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_statusermont_cou_ix` (`courseid`),
  KEY `mdl_statusermont_use_ix` (`userid`),
  KEY `mdl_statusermont_rol_ix` (`roleid`),
  KEY `mdl_statusermont_tim_ix` (`timeend`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To accumulate monthly stats per course/user' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_stats_user_monthly`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_stats_user_weekly`
--

CREATE TABLE IF NOT EXISTS `mdl_stats_user_weekly` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `roleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeend` bigint(10) unsigned NOT NULL DEFAULT '0',
  `statsreads` bigint(10) unsigned NOT NULL DEFAULT '0',
  `statswrites` bigint(10) unsigned NOT NULL DEFAULT '0',
  `stattype` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_statuserweek_cou_ix` (`courseid`),
  KEY `mdl_statuserweek_use_ix` (`userid`),
  KEY `mdl_statuserweek_rol_ix` (`roleid`),
  KEY `mdl_statuserweek_tim_ix` (`timeend`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To accumulate weekly stats per course/user' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_stats_user_weekly`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_stats_weekly`
--

CREATE TABLE IF NOT EXISTS `mdl_stats_weekly` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeend` bigint(10) unsigned NOT NULL DEFAULT '0',
  `roleid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `stattype` enum('enrolments','activity','logins') NOT NULL DEFAULT 'activity',
  `stat1` bigint(10) unsigned NOT NULL DEFAULT '0',
  `stat2` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_statweek_cou_ix` (`courseid`),
  KEY `mdl_statweek_tim_ix` (`timeend`),
  KEY `mdl_statweek_rol_ix` (`roleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To accumulate weekly stats' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_stats_weekly`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_survey`
--

CREATE TABLE IF NOT EXISTS `mdl_survey` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `template` bigint(10) unsigned NOT NULL DEFAULT '0',
  `days` mediumint(6) NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `intro` text NOT NULL,
  `questions` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_surv_cou_ix` (`course`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Each record is one SURVEY module with its configuration' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `mdl_survey`
--

INSERT INTO `mdl_survey` (`id`, `course`, `template`, `days`, `timecreated`, `timemodified`, `name`, `intro`, `questions`) VALUES
(1, 0, 0, 0, 985017600, 985017600, 'collesaname', 'collesaintro', '25,26,27,28,29,30,43,44'),
(2, 0, 0, 0, 985017600, 985017600, 'collespname', 'collespintro', '31,32,33,34,35,36,43,44'),
(3, 0, 0, 0, 985017600, 985017600, 'collesapname', 'collesapintro', '37,38,39,40,41,42,43,44'),
(4, 0, 0, 0, 985017600, 985017600, 'attlsname', 'attlsintro', '65,67,68'),
(5, 0, 0, 0, 985017600, 985017600, 'ciqname', 'ciqintro', '69,70,71,72,73');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_survey_analysis`
--

CREATE TABLE IF NOT EXISTS `mdl_survey_analysis` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `survey` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `notes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_survanal_use_ix` (`userid`),
  KEY `mdl_survanal_sur_ix` (`survey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='text about each survey submission' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_survey_analysis`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_survey_answers`
--

CREATE TABLE IF NOT EXISTS `mdl_survey_answers` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `survey` bigint(10) unsigned NOT NULL DEFAULT '0',
  `question` bigint(10) unsigned NOT NULL DEFAULT '0',
  `time` bigint(10) unsigned NOT NULL DEFAULT '0',
  `answer1` text NOT NULL,
  `answer2` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_survansw_use_ix` (`userid`),
  KEY `mdl_survansw_sur_ix` (`survey`),
  KEY `mdl_survansw_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='the answers to each questions filled by the users' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_survey_answers`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_survey_questions`
--

CREATE TABLE IF NOT EXISTS `mdl_survey_questions` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL DEFAULT '',
  `shorttext` varchar(30) NOT NULL DEFAULT '',
  `multi` varchar(100) NOT NULL DEFAULT '',
  `intro` varchar(50) NOT NULL DEFAULT '',
  `type` smallint(3) NOT NULL DEFAULT '0',
  `options` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='the questions conforming one survey' AUTO_INCREMENT=74 ;

--
-- Dumping data for table `mdl_survey_questions`
--

INSERT INTO `mdl_survey_questions` (`id`, `text`, `shorttext`, `multi`, `intro`, `type`, `options`) VALUES
(1, 'colles1', 'colles1short', '', '', 1, 'scaletimes5'),
(2, 'colles2', 'colles2short', '', '', 1, 'scaletimes5'),
(3, 'colles3', 'colles3short', '', '', 1, 'scaletimes5'),
(4, 'colles4', 'colles4short', '', '', 1, 'scaletimes5'),
(5, 'colles5', 'colles5short', '', '', 1, 'scaletimes5'),
(6, 'colles6', 'colles6short', '', '', 1, 'scaletimes5'),
(7, 'colles7', 'colles7short', '', '', 1, 'scaletimes5'),
(8, 'colles8', 'colles8short', '', '', 1, 'scaletimes5'),
(9, 'colles9', 'colles9short', '', '', 1, 'scaletimes5'),
(10, 'colles10', 'colles10short', '', '', 1, 'scaletimes5'),
(11, 'colles11', 'colles11short', '', '', 1, 'scaletimes5'),
(12, 'colles12', 'colles12short', '', '', 1, 'scaletimes5'),
(13, 'colles13', 'colles13short', '', '', 1, 'scaletimes5'),
(14, 'colles14', 'colles14short', '', '', 1, 'scaletimes5'),
(15, 'colles15', 'colles15short', '', '', 1, 'scaletimes5'),
(16, 'colles16', 'colles16short', '', '', 1, 'scaletimes5'),
(17, 'colles17', 'colles17short', '', '', 1, 'scaletimes5'),
(18, 'colles18', 'colles18short', '', '', 1, 'scaletimes5'),
(19, 'colles19', 'colles19short', '', '', 1, 'scaletimes5'),
(20, 'colles20', 'colles20short', '', '', 1, 'scaletimes5'),
(21, 'colles21', 'colles21short', '', '', 1, 'scaletimes5'),
(22, 'colles22', 'colles22short', '', '', 1, 'scaletimes5'),
(23, 'colles23', 'colles23short', '', '', 1, 'scaletimes5'),
(24, 'colles24', 'colles24short', '', '', 1, 'scaletimes5'),
(25, 'collesm1', 'collesm1short', '1,2,3,4', 'collesmintro', 1, 'scaletimes5'),
(26, 'collesm2', 'collesm2short', '5,6,7,8', 'collesmintro', 1, 'scaletimes5'),
(27, 'collesm3', 'collesm3short', '9,10,11,12', 'collesmintro', 1, 'scaletimes5'),
(28, 'collesm4', 'collesm4short', '13,14,15,16', 'collesmintro', 1, 'scaletimes5'),
(29, 'collesm5', 'collesm5short', '17,18,19,20', 'collesmintro', 1, 'scaletimes5'),
(30, 'collesm6', 'collesm6short', '21,22,23,24', 'collesmintro', 1, 'scaletimes5'),
(31, 'collesm1', 'collesm1short', '1,2,3,4', 'collesmintro', 2, 'scaletimes5'),
(32, 'collesm2', 'collesm2short', '5,6,7,8', 'collesmintro', 2, 'scaletimes5'),
(33, 'collesm3', 'collesm3short', '9,10,11,12', 'collesmintro', 2, 'scaletimes5'),
(34, 'collesm4', 'collesm4short', '13,14,15,16', 'collesmintro', 2, 'scaletimes5'),
(35, 'collesm5', 'collesm5short', '17,18,19,20', 'collesmintro', 2, 'scaletimes5'),
(36, 'collesm6', 'collesm6short', '21,22,23,24', 'collesmintro', 2, 'scaletimes5'),
(37, 'collesm1', 'collesm1short', '1,2,3,4', 'collesmintro', 3, 'scaletimes5'),
(38, 'collesm2', 'collesm2short', '5,6,7,8', 'collesmintro', 3, 'scaletimes5'),
(39, 'collesm3', 'collesm3short', '9,10,11,12', 'collesmintro', 3, 'scaletimes5'),
(40, 'collesm4', 'collesm4short', '13,14,15,16', 'collesmintro', 3, 'scaletimes5'),
(41, 'collesm5', 'collesm5short', '17,18,19,20', 'collesmintro', 3, 'scaletimes5'),
(42, 'collesm6', 'collesm6short', '21,22,23,24', 'collesmintro', 3, 'scaletimes5'),
(43, 'howlong', '', '', '', 1, 'howlongoptions'),
(44, 'othercomments', '', '', '', 0, NULL),
(45, 'attls1', 'attls1short', '', '', 1, 'scaleagree5'),
(46, 'attls2', 'attls2short', '', '', 1, 'scaleagree5'),
(47, 'attls3', 'attls3short', '', '', 1, 'scaleagree5'),
(48, 'attls4', 'attls4short', '', '', 1, 'scaleagree5'),
(49, 'attls5', 'attls5short', '', '', 1, 'scaleagree5'),
(50, 'attls6', 'attls6short', '', '', 1, 'scaleagree5'),
(51, 'attls7', 'attls7short', '', '', 1, 'scaleagree5'),
(52, 'attls8', 'attls8short', '', '', 1, 'scaleagree5'),
(53, 'attls9', 'attls9short', '', '', 1, 'scaleagree5'),
(54, 'attls10', 'attls10short', '', '', 1, 'scaleagree5'),
(55, 'attls11', 'attls11short', '', '', 1, 'scaleagree5'),
(56, 'attls12', 'attls12short', '', '', 1, 'scaleagree5'),
(57, 'attls13', 'attls13short', '', '', 1, 'scaleagree5'),
(58, 'attls14', 'attls14short', '', '', 1, 'scaleagree5'),
(59, 'attls15', 'attls15short', '', '', 1, 'scaleagree5'),
(60, 'attls16', 'attls16short', '', '', 1, 'scaleagree5'),
(61, 'attls17', 'attls17short', '', '', 1, 'scaleagree5'),
(62, 'attls18', 'attls18short', '', '', 1, 'scaleagree5'),
(63, 'attls19', 'attls19short', '', '', 1, 'scaleagree5'),
(64, 'attls20', 'attls20short', '', '', 1, 'scaleagree5'),
(65, 'attlsm1', 'attlsm1', '45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64', 'attlsmintro', 1, 'scaleagree5'),
(66, '-', '-', '-', '-', 0, '-'),
(67, 'attlsm2', 'attlsm2', '63,62,59,57,55,49,52,50,48,47', 'attlsmintro', -1, 'scaleagree5'),
(68, 'attlsm3', 'attlsm3', '46,54,45,51,60,53,56,58,61,64', 'attlsmintro', -1, 'scaleagree5'),
(69, 'ciq1', 'ciq1short', '', '', 0, NULL),
(70, 'ciq2', 'ciq2short', '', '', 0, NULL),
(71, 'ciq3', 'ciq3short', '', '', 0, NULL),
(72, 'ciq4', 'ciq4short', '', '', 0, NULL),
(73, 'ciq5', 'ciq5short', '', '', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_tag`
--

CREATE TABLE IF NOT EXISTS `mdl_tag` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `rawname` varchar(255) NOT NULL DEFAULT '',
  `tagtype` varchar(255) DEFAULT NULL,
  `description` text,
  `descriptionformat` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `flag` smallint(4) unsigned DEFAULT '0',
  `timemodified` bigint(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_tag_nam_uix` (`name`),
  KEY `mdl_tag_use_ix` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Tag table - this generic table will replace the old "tags" t' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_tag`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_tag_correlation`
--

CREATE TABLE IF NOT EXISTS `mdl_tag_correlation` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `tagid` bigint(10) unsigned NOT NULL,
  `correlatedtags` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_tagcorr_tag_ix` (`tagid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='The rationale for the ''tag_correlation'' table is performance' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_tag_correlation`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_tag_instance`
--

CREATE TABLE IF NOT EXISTS `mdl_tag_instance` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `tagid` bigint(10) unsigned NOT NULL,
  `itemtype` varchar(255) NOT NULL DEFAULT '',
  `itemid` bigint(10) unsigned NOT NULL,
  `ordering` bigint(10) unsigned DEFAULT NULL,
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_taginst_iteitetag_uix` (`itemtype`,`itemid`,`tagid`),
  KEY `mdl_taginst_tag_ix` (`tagid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='tag_instance table holds the information of associations bet' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_tag_instance`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_timezone`
--

CREATE TABLE IF NOT EXISTS `mdl_timezone` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `year` bigint(11) NOT NULL DEFAULT '0',
  `tzrule` varchar(20) NOT NULL DEFAULT '',
  `gmtoff` bigint(11) NOT NULL DEFAULT '0',
  `dstoff` bigint(11) NOT NULL DEFAULT '0',
  `dst_month` tinyint(2) NOT NULL DEFAULT '0',
  `dst_startday` smallint(3) NOT NULL DEFAULT '0',
  `dst_weekday` smallint(3) NOT NULL DEFAULT '0',
  `dst_skipweeks` smallint(3) NOT NULL DEFAULT '0',
  `dst_time` varchar(6) NOT NULL DEFAULT '00:00',
  `std_month` tinyint(2) NOT NULL DEFAULT '0',
  `std_startday` smallint(3) NOT NULL DEFAULT '0',
  `std_weekday` smallint(3) NOT NULL DEFAULT '0',
  `std_skipweeks` smallint(3) NOT NULL DEFAULT '0',
  `std_time` varchar(6) NOT NULL DEFAULT '00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Rules for calculating local wall clock time for users' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_timezone`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_user`
--

CREATE TABLE IF NOT EXISTS `mdl_user` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `auth` varchar(20) NOT NULL DEFAULT 'manual',
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `policyagreed` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `mnethostid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `idnumber` varchar(255) NOT NULL DEFAULT '',
  `firstname` varchar(100) NOT NULL DEFAULT '',
  `lastname` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `emailstop` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `icq` varchar(15) NOT NULL DEFAULT '',
  `skype` varchar(50) NOT NULL DEFAULT '',
  `yahoo` varchar(50) NOT NULL DEFAULT '',
  `aim` varchar(50) NOT NULL DEFAULT '',
  `msn` varchar(50) NOT NULL DEFAULT '',
  `phone1` varchar(20) NOT NULL DEFAULT '',
  `phone2` varchar(20) NOT NULL DEFAULT '',
  `institution` varchar(40) NOT NULL DEFAULT '',
  `department` varchar(30) NOT NULL DEFAULT '',
  `address` varchar(70) NOT NULL DEFAULT '',
  `city` varchar(20) NOT NULL DEFAULT '',
  `country` varchar(2) NOT NULL DEFAULT '',
  `lang` varchar(30) NOT NULL DEFAULT 'en_utf8',
  `theme` varchar(50) NOT NULL DEFAULT '',
  `timezone` varchar(100) NOT NULL DEFAULT '99',
  `firstaccess` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lastaccess` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lastlogin` bigint(10) unsigned NOT NULL DEFAULT '0',
  `currentlogin` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(15) NOT NULL DEFAULT '',
  `secret` varchar(15) NOT NULL DEFAULT '',
  `picture` tinyint(1) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `mailformat` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `maildigest` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `maildisplay` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `htmleditor` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ajax` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `autosubscribe` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `trackforums` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `trustbitmask` bigint(10) unsigned NOT NULL DEFAULT '0',
  `imagealt` varchar(255) DEFAULT NULL,
  `screenreader` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_user_mneuse_uix` (`mnethostid`,`username`),
  KEY `mdl_user_del_ix` (`deleted`),
  KEY `mdl_user_con_ix` (`confirmed`),
  KEY `mdl_user_fir_ix` (`firstname`),
  KEY `mdl_user_las_ix` (`lastname`),
  KEY `mdl_user_cit_ix` (`city`),
  KEY `mdl_user_cou_ix` (`country`),
  KEY `mdl_user_las2_ix` (`lastaccess`),
  KEY `mdl_user_ema_ix` (`email`),
  KEY `mdl_user_aut_ix` (`auth`),
  KEY `mdl_user_idn_ix` (`idnumber`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='One record for each person' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mdl_user`
--

INSERT INTO `mdl_user` (`id`, `auth`, `confirmed`, `policyagreed`, `deleted`, `mnethostid`, `username`, `password`, `idnumber`, `firstname`, `lastname`, `email`, `emailstop`, `icq`, `skype`, `yahoo`, `aim`, `msn`, `phone1`, `phone2`, `institution`, `department`, `address`, `city`, `country`, `lang`, `theme`, `timezone`, `firstaccess`, `lastaccess`, `lastlogin`, `currentlogin`, `lastip`, `secret`, `picture`, `url`, `description`, `mailformat`, `maildigest`, `maildisplay`, `htmleditor`, `ajax`, `autosubscribe`, `trackforums`, `timemodified`, `trustbitmask`, `imagealt`, `screenreader`) VALUES
(1, 'manual', 1, 0, 0, 1, 'guest', '084e0343a0486ff05530df6c705c8bb4', '', 'Guest User', ' ', 'root@localhost', 0, '', '', '', '', '', '', '', '', '', '', '', '', 'en_utf8', '', '99', 0, 0, 0, 0, '', '', 0, '', 'This user is a special user that allows read-only access to some courses.', 1, 0, 2, 1, 1, 1, 0, 1323876931, 0, NULL, 0),
(2, 'manual', 1, 0, 0, 1, 'admin', '098f6bcd4621d373cade4e832627b4f6', '', 'Admin', 'User', 'm.deridder@solin.nl', 0, '', '', '', '', '', '', '', '', '', '', 'Breda', 'NL', 'en_utf8', '', '99', 1323877094, 1332437989, 1332329599, 1332413911, '127.0.0.1', '', 0, '', '', 1, 0, 1, 1, 1, 1, 0, 1323877094, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_user_info_category`
--

CREATE TABLE IF NOT EXISTS `mdl_user_info_category` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `sortorder` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Customisable fields categories' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_user_info_category`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_user_info_data`
--

CREATE TABLE IF NOT EXISTS `mdl_user_info_data` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `fieldid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `data` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_userinfodata_usefie_ix` (`userid`,`fieldid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Data for the customisable user fields' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_user_info_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_user_info_field`
--

CREATE TABLE IF NOT EXISTS `mdl_user_info_field` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `shortname` varchar(255) NOT NULL DEFAULT 'shortname',
  `name` longtext NOT NULL,
  `datatype` varchar(255) NOT NULL DEFAULT '',
  `description` longtext,
  `categoryid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `sortorder` bigint(10) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `locked` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `visible` smallint(4) unsigned NOT NULL DEFAULT '0',
  `forceunique` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `signup` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `defaultdata` longtext,
  `param1` longtext,
  `param2` longtext,
  `param3` longtext,
  `param4` longtext,
  `param5` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Customisable user profile fields' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_user_info_field`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_user_lastaccess`
--

CREATE TABLE IF NOT EXISTS `mdl_user_lastaccess` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `courseid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeaccess` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_userlast_usecou_uix` (`userid`,`courseid`),
  KEY `mdl_userlast_use_ix` (`userid`),
  KEY `mdl_userlast_cou_ix` (`courseid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='To keep track of course page access times, used in online pa' AUTO_INCREMENT=10 ;

--
-- Dumping data for table `mdl_user_lastaccess`
--

INSERT INTO `mdl_user_lastaccess` (`id`, `userid`, `courseid`, `timeaccess`) VALUES
(1, 2, 2, 1331734611),
(2, 2, 3, 1326976868),
(3, 2, 4, 1331653643),
(4, 2, 5, 1331204965),
(5, 2, 6, 1332170604),
(6, 2, 7, 1331205195),
(7, 2, 8, 1325682236),
(8, 2, 9, 1325682227),
(9, 2, 10, 1329403410);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_user_preferences`
--

CREATE TABLE IF NOT EXISTS `mdl_user_preferences` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_userpref_usenam_uix` (`userid`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Allows modules to store arbitrary user preferences' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mdl_user_preferences`
--

INSERT INTO `mdl_user_preferences` (`id`, `userid`, `name`, `value`) VALUES
(1, 2, 'auth_forcepasswordchange', '0'),
(2, 2, 'email_bounce_count', '1'),
(3, 2, 'email_send_count', '1');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_user_private_key`
--

CREATE TABLE IF NOT EXISTS `mdl_user_private_key` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `script` varchar(128) NOT NULL DEFAULT '',
  `value` varchar(128) NOT NULL DEFAULT '',
  `userid` bigint(10) unsigned NOT NULL,
  `instance` bigint(10) unsigned DEFAULT NULL,
  `iprestriction` varchar(255) DEFAULT NULL,
  `validuntil` bigint(10) unsigned DEFAULT NULL,
  `timecreated` bigint(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_userprivkey_scrval_ix` (`script`,`value`),
  KEY `mdl_userprivkey_use_ix` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='access keys used in cookieless scripts - rss, etc.' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_user_private_key`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_webdav_locks`
--

CREATE TABLE IF NOT EXISTS `mdl_webdav_locks` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `expiry` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `recursive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `exclusivelock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `created` bigint(10) unsigned NOT NULL DEFAULT '0',
  `modified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `owner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_webdlock_tok_uix` (`token`),
  KEY `mdl_webdlock_pat_ix` (`path`),
  KEY `mdl_webdlock_exp_ix` (`expiry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Resource locks for WebDAV users' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_webdav_locks`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_wiki`
--

CREATE TABLE IF NOT EXISTS `mdl_wiki` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `summary` text NOT NULL,
  `pagename` varchar(255) NOT NULL DEFAULT '',
  `wtype` enum('teacher','group','student') NOT NULL DEFAULT 'group',
  `ewikiprinttitle` smallint(4) unsigned NOT NULL DEFAULT '1',
  `htmlmode` smallint(4) unsigned NOT NULL DEFAULT '0',
  `ewikiacceptbinary` smallint(4) unsigned NOT NULL DEFAULT '0',
  `disablecamelcase` smallint(4) unsigned NOT NULL DEFAULT '0',
  `setpageflags` smallint(4) unsigned NOT NULL DEFAULT '1',
  `strippages` smallint(4) unsigned NOT NULL DEFAULT '1',
  `removepages` smallint(4) unsigned NOT NULL DEFAULT '1',
  `revertchanges` smallint(4) unsigned NOT NULL DEFAULT '1',
  `initialcontent` varchar(255) NOT NULL DEFAULT '',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_wiki_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Main wik table' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_wiki`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_wiki_entries`
--

CREATE TABLE IF NOT EXISTS `mdl_wiki_entries` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `wikiid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `groupid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `pagename` varchar(255) NOT NULL DEFAULT '',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_wikientr_cou_ix` (`course`),
  KEY `mdl_wikientr_gro_ix` (`groupid`),
  KEY `mdl_wikientr_use_ix` (`userid`),
  KEY `mdl_wikientr_pag_ix` (`pagename`),
  KEY `mdl_wikientr_wik_ix` (`wikiid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Holds entries for each wiki start instance' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_wiki_entries`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_wiki_locks`
--

CREATE TABLE IF NOT EXISTS `mdl_wiki_locks` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `wikiid` bigint(10) unsigned NOT NULL,
  `pagename` varchar(160) NOT NULL DEFAULT '',
  `lockedby` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lockedsince` bigint(10) unsigned NOT NULL DEFAULT '0',
  `lockedseen` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_wikilock_wikpag_uix` (`wikiid`,`pagename`),
  KEY `mdl_wikilock_loc_ix` (`lockedseen`),
  KEY `mdl_wikilock_wik_ix` (`wikiid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores editing locks on Wiki pages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_wiki_locks`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_wiki_pages`
--

CREATE TABLE IF NOT EXISTS `mdl_wiki_pages` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `pagename` varchar(160) NOT NULL DEFAULT '',
  `version` bigint(10) unsigned NOT NULL DEFAULT '0',
  `flags` bigint(10) unsigned DEFAULT '0',
  `content` mediumtext,
  `author` varchar(100) DEFAULT 'ewiki',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `created` bigint(10) unsigned DEFAULT '0',
  `lastmodified` bigint(10) unsigned DEFAULT '0',
  `refs` mediumtext,
  `meta` mediumtext,
  `hits` bigint(10) unsigned DEFAULT '0',
  `wiki` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_wikipage_pagverwik_uix` (`pagename`,`version`,`wiki`),
  KEY `mdl_wikipage_wik_ix` (`wiki`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Holds the Wiki-Pages' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_wiki_pages`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_workshop`
--

CREATE TABLE IF NOT EXISTS `mdl_workshop` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `course` bigint(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `wtype` smallint(3) unsigned NOT NULL DEFAULT '0',
  `nelements` smallint(3) unsigned NOT NULL DEFAULT '1',
  `nattachments` smallint(3) unsigned NOT NULL DEFAULT '0',
  `phase` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `format` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `gradingstrategy` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `resubmit` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `agreeassessments` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `hidegrades` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `anonymous` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `includeself` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `maxbytes` bigint(10) unsigned NOT NULL DEFAULT '100000',
  `submissionstart` bigint(10) unsigned NOT NULL DEFAULT '0',
  `assessmentstart` bigint(10) unsigned NOT NULL DEFAULT '0',
  `submissionend` bigint(10) unsigned NOT NULL DEFAULT '0',
  `assessmentend` bigint(10) unsigned NOT NULL DEFAULT '0',
  `releasegrades` bigint(10) unsigned NOT NULL DEFAULT '0',
  `grade` smallint(3) NOT NULL DEFAULT '0',
  `gradinggrade` smallint(3) NOT NULL DEFAULT '0',
  `ntassessments` smallint(3) unsigned NOT NULL DEFAULT '0',
  `assessmentcomps` smallint(3) unsigned NOT NULL DEFAULT '2',
  `nsassessments` smallint(3) unsigned NOT NULL DEFAULT '0',
  `overallocation` smallint(3) unsigned NOT NULL DEFAULT '0',
  `timemodified` bigint(10) unsigned NOT NULL DEFAULT '0',
  `teacherweight` smallint(3) unsigned NOT NULL DEFAULT '1',
  `showleaguetable` smallint(3) unsigned NOT NULL DEFAULT '0',
  `usepassword` smallint(3) unsigned NOT NULL DEFAULT '0',
  `password` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `mdl_work_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines workshop' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_workshop`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_workshop_assessments`
--

CREATE TABLE IF NOT EXISTS `mdl_workshop_assessments` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `workshopid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `submissionid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timegraded` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timeagreed` bigint(10) unsigned NOT NULL DEFAULT '0',
  `grade` double NOT NULL DEFAULT '0',
  `gradinggrade` smallint(3) NOT NULL DEFAULT '0',
  `teachergraded` smallint(3) unsigned NOT NULL DEFAULT '0',
  `mailed` smallint(3) unsigned NOT NULL DEFAULT '0',
  `resubmission` smallint(3) unsigned NOT NULL DEFAULT '0',
  `donotuse` smallint(3) unsigned NOT NULL DEFAULT '0',
  `generalcomment` text,
  `teachercomment` text,
  PRIMARY KEY (`id`),
  KEY `mdl_workasse_use_ix` (`userid`),
  KEY `mdl_workasse_mai_ix` (`mailed`),
  KEY `mdl_workasse_wor_ix` (`workshopid`),
  KEY `mdl_workasse_sub_ix` (`submissionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about assessments by teacher and students' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_workshop_assessments`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_workshop_comments`
--

CREATE TABLE IF NOT EXISTS `mdl_workshop_comments` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `workshopid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `assessmentid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `mailed` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `comments` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_workcomm_use_ix` (`userid`),
  KEY `mdl_workcomm_mai_ix` (`mailed`),
  KEY `mdl_workcomm_wor_ix` (`workshopid`),
  KEY `mdl_workcomm_ass_ix` (`assessmentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines comments' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_workshop_comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_workshop_elements`
--

CREATE TABLE IF NOT EXISTS `mdl_workshop_elements` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `workshopid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `elementno` smallint(3) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `scale` smallint(3) unsigned NOT NULL DEFAULT '0',
  `maxscore` smallint(3) unsigned NOT NULL DEFAULT '1',
  `weight` smallint(3) unsigned NOT NULL DEFAULT '11',
  `stddev` double NOT NULL DEFAULT '0',
  `totalassessments` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_workelem_wor_ix` (`workshopid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about marking scheme of assignment' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_workshop_elements`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_workshop_grades`
--

CREATE TABLE IF NOT EXISTS `mdl_workshop_grades` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `workshopid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `assessmentid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `elementno` bigint(10) unsigned NOT NULL DEFAULT '0',
  `feedback` text NOT NULL,
  `grade` smallint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_workgrad_wor_ix` (`workshopid`),
  KEY `mdl_workgrad_ass_ix` (`assessmentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about individual grades given to each element' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_workshop_grades`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_workshop_rubrics`
--

CREATE TABLE IF NOT EXISTS `mdl_workshop_rubrics` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `workshopid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `elementno` bigint(10) unsigned NOT NULL DEFAULT '0',
  `rubricno` smallint(3) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_workrubr_wor_ix` (`workshopid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about the rubrics marking scheme' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_workshop_rubrics`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_workshop_stockcomments`
--

CREATE TABLE IF NOT EXISTS `mdl_workshop_stockcomments` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `workshopid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `elementno` bigint(10) unsigned NOT NULL DEFAULT '0',
  `comments` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_workstoc_wor_ix` (`workshopid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about the teacher comment bank' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_workshop_stockcomments`
--


-- --------------------------------------------------------

--
-- Table structure for table `mdl_workshop_submissions`
--

CREATE TABLE IF NOT EXISTS `mdl_workshop_submissions` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `workshopid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `userid` bigint(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL DEFAULT '',
  `timecreated` bigint(10) unsigned NOT NULL DEFAULT '0',
  `mailed` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `gradinggrade` smallint(3) unsigned NOT NULL DEFAULT '0',
  `finalgrade` smallint(3) unsigned NOT NULL DEFAULT '0',
  `late` smallint(3) unsigned NOT NULL DEFAULT '0',
  `nassessments` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_worksubm_use_ix` (`userid`),
  KEY `mdl_worksubm_mai_ix` (`mailed`),
  KEY `mdl_worksubm_wor_ix` (`workshopid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about submitted work from teacher and students' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mdl_workshop_submissions`
--

